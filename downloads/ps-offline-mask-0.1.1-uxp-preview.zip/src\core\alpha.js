const { LABELS } = require("./trimap");

const DIRECTIONS = [
  [-1, 0],
  [1, 0],
  [0, -1],
  [0, 1]
];

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function distanceFromLabel(width, height, data, label) {
  const size = width * height;
  const distances = new Int32Array(size);
  distances.fill(-1);
  const queue = new Int32Array(size);
  let head = 0;
  let tail = 0;

  for (let index = 0; index < size; index += 1) {
    if (data[index] === label) {
      distances[index] = 0;
      queue[tail] = index;
      tail += 1;
    }
  }

  while (head < tail) {
    const index = queue[head];
    head += 1;
    const x = index % width;
    const y = Math.floor(index / width);
    const nextDistance = distances[index] + 1;

    for (const [dx, dy] of DIRECTIONS) {
      const nx = x + dx;
      const ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
      const nextIndex = ny * width + nx;
      if (distances[nextIndex] === -1) {
        distances[nextIndex] = nextDistance;
        queue[tail] = nextIndex;
        tail += 1;
      }
    }
  }

  return distances;
}

function blur(input, width, height, radius) {
  if (radius < 1) return input;
  const output = new Uint8Array(input.length);
  const diameter = radius * 2 + 1;

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      let sum = 0;
      let count = 0;
      for (let oy = -radius; oy <= radius; oy += 1) {
        const py = y + oy;
        if (py < 0 || py >= height) continue;
        for (let ox = -radius; ox <= radius; ox += 1) {
          const px = x + ox;
          if (px < 0 || px >= width) continue;
          sum += input[py * width + px];
          count += 1;
        }
      }
      output[y * width + x] = Math.round(sum / Math.max(1, count));
    }
  }

  return output;
}

function computeFallbackAlpha({ width, height, trimap, options = {} }) {
  if (!Number.isInteger(width) || !Number.isInteger(height) || trimap.length !== width * height) {
    throw new RangeError("Alpha input dimensions are invalid");
  }

  const keepDistance = distanceFromLabel(width, height, trimap, LABELS.KEEP);
  const cutDistance = distanceFromLabel(width, height, trimap, LABELS.CUT);
  const alpha = new Uint8Array(width * height);
  const edgeShift = clamp(Number(options.edgeShift) || 0, -100, 100) * 2.55;

  for (let index = 0; index < alpha.length; index += 1) {
    const value = trimap[index];
    let result;
    if (value === LABELS.KEEP) {
      result = 255;
    } else if (value === LABELS.CUT) {
      result = 0;
    } else {
      const keep = keepDistance[index];
      const cut = cutDistance[index];
      if (keep < 0 && cut < 0) {
        result = 128;
      } else if (keep < 0) {
        result = 0;
      } else if (cut < 0) {
        result = 255;
      } else {
        result = Math.round((cut / Math.max(1, keep + cut)) * 255);
      }
    }
    alpha[index] = clamp(Math.round(result + edgeShift), 0, 255);
  }

  const feather = clamp(Number(options.feather) || 0, 0, 100);
  const featherRadius = Math.min(4, Math.round(feather / 25));
  let result = blur(alpha, width, height, featherRadius);

  const threshold = clamp(Number(options.hardThreshold) || 0, 0, 255);
  if (threshold > 0) {
    const binary = new Uint8Array(result.length);
    for (let index = 0; index < result.length; index += 1) {
      binary[index] = result[index] >= threshold ? 255 : 0;
    }
    result = binary;
  }

  if (options.invert) {
    for (let index = 0; index < result.length; index += 1) {
      result[index] = 255 - result[index];
    }
  }

  return result;
}

module.exports = { computeFallbackAlpha, distanceFromLabel };
