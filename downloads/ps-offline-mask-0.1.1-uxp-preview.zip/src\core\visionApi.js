const CONTRACT_VERSION = 1;
const DEFAULT_TIMEOUT_MS = 30_000;

const ERROR_CATEGORIES = Object.freeze({
  CONFIGURATION: "configuration",
  AUTHENTICATION: "authentication",
  RATE_LIMIT: "rate-limit",
  PERMISSION: "permission",
  TIMEOUT: "timeout",
  SERVER: "server",
  RESPONSE_FORMAT: "response-format",
  NETWORK: "network",
  CANCELED: "canceled"
});

function bytesToBase64(bytes) {
  if (!(bytes instanceof Uint8Array)) {
    throw new TypeError("Only Uint8Array values can be encoded");
  }
  if (typeof Buffer !== "undefined") {
    return Buffer.from(bytes).toString("base64");
  }
  if (typeof btoa !== "function") {
    throw new Error("No base64 encoder is available in this runtime");
  }
  let binary = "";
  for (let index = 0; index < bytes.length; index += 1) {
    binary += String.fromCharCode(bytes[index]);
  }
  return btoa(binary);
}

function base64ToBytes(value) {
  if (value instanceof Uint8Array) return new Uint8Array(value);
  if (typeof Uint8ClampedArray !== "undefined" && value instanceof Uint8ClampedArray) {
    return new Uint8Array(value);
  }
  if (Array.isArray(value)) {
    if (!value.every((byte) => Number.isInteger(byte) && byte >= 0 && byte <= 255)) {
      throw new TypeError("Vision API alpha byte arrays must contain values from 0 to 255");
    }
    return new Uint8Array(value);
  }
  if (typeof value !== "string") {
    throw new TypeError("Vision API alpha must be base64 or a byte array");
  }
  // Reject malformed Base64 instead of allowing Buffer.from to silently truncate it.
  const normalized = value.replace(/\s+/g, "");
  if (!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(normalized)) {
    throw new TypeError("Vision API alpha is not valid base64");
  }
  if (typeof Buffer !== "undefined") {
    return new Uint8Array(Buffer.from(normalized, "base64"));
  }
  if (typeof atob !== "function") {
    throw new Error("No base64 decoder is available in this runtime");
  }
  const binary = atob(normalized);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }
  return bytes;
}

function createRequestId() {
  try {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
  } catch (error) {
    // Some UXP runtimes expose a partial crypto object. Use the fallback below.
  }
  return `vision-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
}

function isPositiveInteger(value) {
  return Number.isInteger(value) && value > 0;
}

function serializeImage(request) {
  const image = request.image && typeof request.image === "object" ? request.image : null;
  const pixels = request.pixels instanceof Uint8Array
    ? request.pixels
    : image && (image.bytes instanceof Uint8Array || image.data instanceof Uint8Array)
      ? (image.bytes || image.data)
      : null;
  const width = request.width ?? (image && image.width);
  const height = request.height ?? (image && image.height);
  const components = request.components ?? (image && image.components);
  const hasBase64 = Boolean(image && typeof image.dataBase64 === "string");
  if (!pixels && !hasBase64) {
    throw new TypeError("Vision API requests require Uint8Array pixels");
  }
  if (!isPositiveInteger(width) || !isPositiveInteger(height)) {
    throw new TypeError("Vision API image width and height must be positive integers");
  }
  if (components !== 3 && components !== 4) {
    throw new TypeError("Vision API image components must be RGB (3) or RGBA (4)");
  }
  if (image && image.colorSpace && image.colorSpace !== "RGB") {
    throw new TypeError("Vision API image colorSpace must be RGB");
  }
  let dataBase64;
  let outputComponents = 3;
  if (hasBase64) {
    if (components !== 3) {
      throw new TypeError("Vision API base64 images must already be RGB");
    }
    if (base64ToBytes(image.dataBase64).length !== width * height * 3) {
      throw new TypeError("Vision API base64 image data length does not match dimensions");
    }
    dataBase64 = image.dataBase64;
  } else {
    const expectedLength = width * height * components;
    if (pixels.length !== expectedLength) {
      throw new TypeError("Vision API image pixel data length does not match dimensions");
    }
    if (components === 4) {
      const rgb = new Uint8Array(width * height * 3);
      for (let sourceIndex = 0, targetIndex = 0; sourceIndex < pixels.length; sourceIndex += 4, targetIndex += 3) {
        rgb[targetIndex] = pixels[sourceIndex];
        rgb[targetIndex + 1] = pixels[sourceIndex + 1];
        rgb[targetIndex + 2] = pixels[sourceIndex + 2];
      }
      dataBase64 = bytesToBase64(rgb);
    } else {
      dataBase64 = bytesToBase64(pixels);
    }
  }
  return {
    dataBase64,
    width,
    height,
    components: outputComponents,
    colorSpace: (image && image.colorSpace) || "RGB"
  };
}

function serializeTrimap(request, width, height) {
  const trimap = request.trimap;
  if (trimap instanceof Uint8Array) {
    return {
      dataBase64: bytesToBase64(trimap),
      width,
      height,
      encoding: "uint8-labels-unknown-keep-cut"
    };
  }
  if (trimap && typeof trimap === "object" && typeof trimap.dataBase64 === "string") {
    return {
      dataBase64: trimap.dataBase64,
      width: trimap.width ?? width,
      height: trimap.height ?? height,
      encoding: trimap.encoding || "uint8-labels-unknown-keep-cut"
    };
  }
  if (trimap && typeof trimap === "object" && (trimap.bytes instanceof Uint8Array || trimap.data instanceof Uint8Array)) {
    return {
      dataBase64: bytesToBase64(trimap.bytes || trimap.data),
      width: trimap.width ?? width,
      height: trimap.height ?? height,
      encoding: trimap.encoding || "uint8-labels-unknown-keep-cut"
    };
  }
  throw new TypeError("Vision API requests require a Uint8Array trimap");
}

function serializeVisionRequest(request = {}) {
  const contractVersion = request.contractVersion ?? CONTRACT_VERSION;
  if (!Number.isInteger(contractVersion) || contractVersion < 1) {
    throw new TypeError("Vision API contractVersion must be a positive integer");
  }
  const image = serializeImage(request);
  const trimap = serializeTrimap(request, image.width, image.height);
  if (trimap.width !== image.width || trimap.height !== image.height) {
    throw new TypeError("Vision API trimap dimensions must match the image");
  }
  const payload = {
    contractVersion,
    requestId: request.requestId || createRequestId(),
    image,
    trimap,
    options: request.options && typeof request.options === "object" ? request.options : {}
  };
  if (request.client && typeof request.client === "object") payload.client = request.client;
  return payload;
}

function makeDiagnostics(diagnostics) {
  if (!diagnostics || typeof diagnostics !== "object" || Array.isArray(diagnostics)) return { engine: "vision-api" };
  const normalized = { ...diagnostics, engine: "vision-api" };
  if (Object.prototype.hasOwnProperty.call(normalized, "confidence")) {
    const confidence = Number(normalized.confidence);
    if (!Number.isFinite(confidence) || confidence < 0 || confidence > 100) delete normalized.confidence;
    else normalized.confidence = confidence;
  }
  if (Object.prototype.hasOwnProperty.call(normalized, "processingMs")) {
    const processingMs = Number(normalized.processingMs);
    if (!Number.isFinite(processingMs) || processingMs < 0) delete normalized.processingMs;
    else normalized.processingMs = processingMs;
  }
  if (Object.prototype.hasOwnProperty.call(normalized, "warnings")) {
    if (!Array.isArray(normalized.warnings)) delete normalized.warnings;
    else normalized.warnings = normalized.warnings.filter((warning) => typeof warning === "string");
  }
  return normalized;
}

class VisionApiError extends Error {
  constructor(message, details = {}) {
    super(message);
    this.name = "VisionApiError";
    this.code = details.code || ERROR_CATEGORIES.NETWORK;
    this.category = details.category || this.code;
    this.kind = this.category;
    this.status = details.status;
    this.retryable = Boolean(details.retryable);
    this.requestId = details.requestId;
    this.accepted = Boolean(details.accepted);
    if (details.cause !== undefined) this.cause = details.cause;
  }
}

function errorForCategory(category, message, details = {}) {
  return new VisionApiError(message, {
    ...details,
    code: details.code || category,
    category
  });
}

function classifyHttpStatus(status) {
  if (status === 401) return { category: ERROR_CATEGORIES.AUTHENTICATION, retryable: false };
  if (status === 403) return { category: ERROR_CATEGORIES.PERMISSION, retryable: false };
  if (status === 408) return { category: ERROR_CATEGORIES.TIMEOUT, retryable: true };
  if (status === 429) return { category: ERROR_CATEGORIES.RATE_LIMIT, retryable: true };
  if (status >= 500 && status <= 599) return { category: ERROR_CATEGORIES.SERVER, retryable: true };
  if (status === 404 || status === 0) return { category: ERROR_CATEGORIES.CONFIGURATION, retryable: false };
  return { category: ERROR_CATEGORIES.RESPONSE_FORMAT, retryable: false };
}

function combineAbortSignal(signal, timeoutMs) {
  const hasTimeout = Number.isFinite(timeoutMs) && timeoutMs > 0;
  if (!signal && !hasTimeout) return { signal: undefined, timedOut: () => false, cleanup() {} };
  if (typeof AbortController !== "function") {
    return { signal, timedOut: () => false, cleanup() {} };
  }
  const controller = new AbortController();
  let timedOut = false;
  let timer;
  const abort = () => controller.abort();
  if (signal) {
    if (signal.aborted) controller.abort();
    else signal.addEventListener("abort", abort, { once: true });
  }
  if (hasTimeout) {
    timer = setTimeout(() => {
      timedOut = true;
      controller.abort();
    }, timeoutMs);
  }
  return {
    signal: controller.signal,
    timedOut: () => timedOut,
    cleanup() {
      if (timer) clearTimeout(timer);
      if (signal) signal.removeEventListener("abort", abort);
    }
  };
}

function endpointIsValid(endpoint) {
  if (typeof endpoint !== "string" || endpoint.trim() === "") return false;
  if (typeof URL !== "function") return /^https:\/\/[^\s]+$/i.test(endpoint) || /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?(?:\/|$)/i.test(endpoint);
  try {
    const url = new URL(endpoint);
    return url.protocol === "https:" || (url.protocol === "http:" && /^(localhost|127\.0\.0\.1)$/.test(url.hostname));
  } catch (error) {
    return false;
  }
}

function createVisionApiClient({
  endpoint,
  request,
  apiKeyProvider,
  headers = {},
  timeout,
  timeoutMs = timeout,
  logger
} = {}) {
  if (!endpoint) throw errorForCategory(ERROR_CATEGORIES.CONFIGURATION, "Vision API endpoint is required");
  if (!endpointIsValid(endpoint)) {
    throw errorForCategory(ERROR_CATEGORIES.CONFIGURATION, "Vision API endpoint must use HTTPS (localhost HTTP is allowed for development)");
  }
  const transport = request || (typeof fetch === "function" ? fetch : null);
  if (!transport) throw errorForCategory(ERROR_CATEGORIES.CONFIGURATION, "No HTTP transport is available in this runtime");
  if (typeof transport !== "function") {
    throw errorForCategory(ERROR_CATEGORIES.CONFIGURATION, "Vision API request transport must be a function");
  }
  const defaultTimeout = Number.isFinite(timeoutMs) && timeoutMs > 0 ? timeoutMs : DEFAULT_TIMEOUT_MS;

  return {
    kind: "vision-api",
    describe() {
      return "AI Vision API";
    },
    async compute(input = {}, computeOptions = {}) {
      computeOptions = computeOptions || {};
      const payload = serializeVisionRequest(input);
      const requestId = payload.requestId;
      const directSignal = computeOptions && typeof computeOptions.aborted === "boolean"
        ? computeOptions
        : null;
      const signal = (directSignal || computeOptions.signal || input.signal);
      if (signal && signal.aborted) {
        throw errorForCategory(ERROR_CATEGORIES.CANCELED, "Vision API request was canceled", {
          requestId,
          retryable: false
        });
      }
      const requestHeaders = {
        "content-type": "application/json",
        ...headers
      };
      if (apiKeyProvider) {
        let apiKey;
        try {
          apiKey = await apiKeyProvider();
        } catch (cause) {
          throw errorForCategory(ERROR_CATEGORIES.AUTHENTICATION, "Vision API authentication could not be provided", {
            requestId
          });
        }
        if (apiKey !== undefined && apiKey !== null && String(apiKey) !== "") {
          requestHeaders.authorization = `Bearer ${String(apiKey)}`;
        }
      }
      const requestedTimeout = computeOptions.timeoutMs ?? computeOptions.timeout ?? input.timeoutMs ?? input.timeout ?? defaultTimeout;
      const abort = combineAbortSignal(signal, requestedTimeout);
      const startedAt = Date.now();
      let response;
      try {
        response = await transport(endpoint, {
          method: "POST",
          headers: requestHeaders,
          body: JSON.stringify(payload),
          ...(abort.signal ? { signal: abort.signal } : {})
        });
      } catch (cause) {
        abort.cleanup();
        const timedOut = abort.timedOut();
        if (timedOut) {
          throw errorForCategory(ERROR_CATEGORIES.TIMEOUT, "Vision API request timed out", {
            requestId,
            retryable: true,
            cause
          });
        }
        if (signal && signal.aborted) {
          throw errorForCategory(ERROR_CATEGORIES.CANCELED, "Vision API request was canceled", {
            requestId,
            retryable: false,
            cause
          });
        }
        throw errorForCategory(ERROR_CATEGORIES.NETWORK, "Vision API network request failed", {
          requestId,
          retryable: true,
          cause
        });
      }
      abort.cleanup();
      const elapsedMs = Date.now() - startedAt;
      if (abort.timedOut()) {
        throw errorForCategory(ERROR_CATEGORIES.TIMEOUT, "Vision API request timed out", {
          requestId,
          retryable: true
        });
      }
      if (signal && signal.aborted) {
        throw errorForCategory(ERROR_CATEGORIES.CANCELED, "Vision API request was canceled", {
          requestId,
          retryable: false
        });
      }
      const status = response && Number.isInteger(response.status) ? response.status : undefined;
      if (!response || (typeof response.ok === "boolean" && !response.ok) || (status !== undefined && status >= 400)) {
        const classification = classifyHttpStatus(status || 0);
        const error = errorForCategory(
          classification.category,
          `Vision API request failed${status ? ` (${status})` : ""}`,
          { requestId, status, retryable: classification.retryable, accepted: Boolean(status && status >= 200 && status < 300) }
        );
        if (logger && typeof logger === "function") {
          try { logger({ status, requestId, elapsedMs, category: error.category }); } catch (ignored) { /* logging must not affect requests */ }
        }
        throw error;
      }
      let body;
      try {
        body = typeof response.json === "function" ? await response.json() : response;
      } catch (cause) {
        throw errorForCategory(ERROR_CATEGORIES.RESPONSE_FORMAT, "Vision API returned invalid JSON", {
          requestId,
          retryable: false,
          accepted: true,
          cause
        });
      }
      try {
        const result = normalizeVisionResponse(body, payload.image.width, payload.image.height);
        if (logger && typeof logger === "function") {
          try { logger({ status: response.status, requestId, elapsedMs, traceId: result.diagnostics.traceId }); } catch (ignored) { /* logging must not affect requests */ }
        }
        return result;
      } catch (cause) {
        if (cause instanceof VisionApiError) {
          cause.requestId = requestId;
          cause.accepted = true;
          throw cause;
        }
        throw errorForCategory(ERROR_CATEGORIES.RESPONSE_FORMAT, cause.message || "Vision API returned an invalid response", {
          requestId,
          retryable: false,
          accepted: true,
          cause
        });
      }
    }
  };
}

function normalizeVisionResponse(response, width, height) {
  const source = response && response.result && typeof response.result === "object"
    ? response.result
    : response;
  if (!source || typeof source !== "object" || !isPositiveInteger(width) || !isPositiveInteger(height)) {
    throw errorForCategory(ERROR_CATEGORIES.RESPONSE_FORMAT, "Vision API response is not a valid result");
  }
  let alpha;
  try {
    alpha = base64ToBytes(source.alphaBase64 !== undefined ? source.alphaBase64 : source.alpha);
  } catch (cause) {
    throw errorForCategory(ERROR_CATEGORIES.RESPONSE_FORMAT, "Vision API response alpha is invalid", { cause });
  }
  if (alpha.length !== width * height) {
    throw errorForCategory(ERROR_CATEGORIES.RESPONSE_FORMAT, "Vision API returned an alpha buffer with invalid dimensions");
  }
  return {
    alpha,
    diagnostics: makeDiagnostics(source.diagnostics)
  };
}

module.exports = {
  CONTRACT_VERSION,
  DEFAULT_TIMEOUT_MS,
  ERROR_CATEGORIES,
  VisionApiError,
  base64ToBytes,
  bytesToBase64,
  classifyHttpStatus,
  createRequestId,
  createVisionApiClient,
  normalizeVisionResponse,
  serializeVisionRequest
};
