const { LABELS, TrimapRaster } = require("./trimap");

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function median(values) {
  const sorted = values.slice().sort((left, right) => left - right);
  if (sorted.length === 0) return 0;
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0 ? (sorted[middle - 1] + sorted[middle]) / 2 : sorted[middle];
}

function borderIndices(width, height) {
  const indices = [];
  const step = Math.max(1, Math.floor(Math.max(width, height) / 64));
  for (let x = 0; x < width; x += step) {
    indices.push(x, (height - 1) * width + x);
  }
  for (let y = 0; y < height; y += step) {
    indices.push(y * width, y * width + width - 1);
  }
  return indices;
}

function colorDistance(pixels, components, index, background) {
  const offset = index * components;
  const red = pixels[offset] || 0;
  const green = pixels[offset + 1] || 0;
  const blue = pixels[offset + 2] || 0;
  const dr = red - background[0];
  const dg = green - background[1];
  const db = blue - background[2];
  return Math.sqrt(dr * dr + dg * dg + db * db);
}

function alphaAt(pixels, components, index) {
  return components >= 4 ? pixels[index * components + 3] : 255;
}

function mark(trimap, index, label) {
  trimap.data[index] = label;
  trimap.painted[index] = 1;
}

function connectedBorderBackground(width, height, distances, threshold) {
  const size = width * height;
  const cut = new Uint8Array(size);
  const queue = new Int32Array(size);
  let head = 0;
  let tail = 0;

  const enqueue = (index) => {
    if (cut[index] || distances[index] > threshold) return;
    cut[index] = 1;
    queue[tail] = index;
    tail += 1;
  };

  for (let x = 0; x < width; x += 1) {
    enqueue(x);
    enqueue((height - 1) * width + x);
  }
  for (let y = 0; y < height; y += 1) {
    enqueue(y * width);
    enqueue(y * width + width - 1);
  }

  while (head < tail) {
    const index = queue[head];
    head += 1;
    const x = index % width;
    const y = Math.floor(index / width);
    const neighbors = [];
    if (x > 0) neighbors.push(index - 1);
    if (x + 1 < width) neighbors.push(index + 1);
    if (y > 0) neighbors.push(index - width);
    if (y + 1 < height) neighbors.push(index + width);
    for (const neighbor of neighbors) enqueue(neighbor);
  }

  return cut;
}

function autoTrimap({ pixels, width, height, components = 3 }) {
  if (!(pixels instanceof Uint8Array) || pixels.length < width * height * components) {
    throw new TypeError("Auto trimap requires an RGB/RGBA Uint8Array");
  }
  const trimap = new TrimapRaster(width, height);
  const border = borderIndices(width, height);
  const transparentBorder = components >= 4 && median(border.map((index) => alphaAt(pixels, components, index))) < 32;

  if (transparentBorder) {
    let keepPixels = 0;
    let cutPixels = 0;
    for (let index = 0; index < width * height; index += 1) {
      const alpha = alphaAt(pixels, components, index);
      if (alpha <= 8) {
        mark(trimap, index, LABELS.CUT);
        cutPixels += 1;
      } else if (alpha >= 248) {
        mark(trimap, index, LABELS.KEEP);
        keepPixels += 1;
      }
    }
    return {
      trimap,
      diagnostics: {
        mode: "transparent-channel",
        confidence: keepPixels > 0 ? 0.95 : 0.35,
        keepPixels,
        cutPixels,
        unknownPixels: width * height - keepPixels - cutPixels
      }
    };
  }

  const background = [
    median(border.map((index) => pixels[index * components] || 0)),
    median(border.map((index) => pixels[index * components + 1] || 0)),
    median(border.map((index) => pixels[index * components + 2] || 0))
  ];
  const distances = new Float32Array(width * height);
  const borderDistances = [];
  for (let index = 0; index < distances.length; index += 1) {
    distances[index] = colorDistance(pixels, components, index, background);
  }
  for (const index of border) borderDistances.push(distances[index]);

  const spread = median(borderDistances.map((value) => Math.abs(value - median(borderDistances))));
  const cutThreshold = clamp(18 + spread * 2.5, 18, 92);
  const cut = connectedBorderBackground(width, height, distances, cutThreshold);
  const keepThreshold = cutThreshold * 1.65;
  let keepPixels = 0;
  let cutPixels = 0;

  for (let index = 0; index < distances.length; index += 1) {
    if (cut[index]) {
      mark(trimap, index, LABELS.CUT);
      cutPixels += 1;
    } else if (distances[index] >= keepThreshold) {
      mark(trimap, index, LABELS.KEEP);
      keepPixels += 1;
    }
  }

  if (keepPixels === 0) {
    let bestIndex = 0;
    let bestDistance = -1;
    for (let index = 0; index < distances.length; index += 1) {
      if (!cut[index] && distances[index] > bestDistance) {
        bestIndex = index;
        bestDistance = distances[index];
      }
    }
    const centerX = bestIndex % width;
    const centerY = Math.floor(bestIndex / width);
    const radius = Math.max(1, Math.round(Math.min(width, height) / 32));
    for (let y = Math.max(0, centerY - radius); y <= Math.min(height - 1, centerY + radius); y += 1) {
      for (let x = Math.max(0, centerX - radius); x <= Math.min(width - 1, centerX + radius); x += 1) {
        const index = y * width + x;
        if (!cut[index]) {
          mark(trimap, index, LABELS.KEEP);
          keepPixels += 1;
        }
      }
    }
  }

  const total = width * height;
  const keepRatio = keepPixels / total;
  const cutRatio = cutPixels / total;
  let confidence = keepPixels > 0 && cutPixels > 0 ? 0.62 : 0.3;
  if (keepRatio < 0.01 || keepRatio > 0.85) confidence -= 0.18;
  if (cutRatio < 0.05 || cutRatio > 0.95) confidence -= 0.12;

  return {
    trimap,
    diagnostics: {
      mode: "border-color",
      confidence: clamp(confidence, 0.05, 0.85),
      background,
      keepPixels,
      cutPixels,
      unknownPixels: total - keepPixels - cutPixels
    }
  };
}

module.exports = { autoTrimap, borderIndices, connectedBorderBackground };
