function toBounds(bounds) {
  if (!bounds) throw new Error("图层没有有效边界");
  const left = Math.round(Number(bounds.left) || 0);
  const top = Math.round(Number(bounds.top) || 0);
  const width = Math.max(1, Math.round(Number(bounds.width) || (Number(bounds.right) - left)));
  const height = Math.max(1, Math.round(Number(bounds.height) || (Number(bounds.bottom) - top)));
  return { left, top, width, height, right: left + width, bottom: top + height };
}

/**
 * Build the small Photoshop-facing adapter used by the panel.
 *
 * `action`/`batchPlay` are optional because older callers only injected the
 * four dependencies used by the first version of this adapter. They are used
 * solely for removing a mask that did not exist before a temporary preview.
 */
function createPhotoshopHost({ app, constants, imaging, core, action, batchPlay, photoshop } = {}) {
  const play = typeof batchPlay === "function"
    ? batchPlay
    : action && typeof action.batchPlay === "function"
      ? action.batchPlay.bind(action)
      : photoshop && photoshop.action && typeof photoshop.action.batchPlay === "function"
        ? photoshop.action.batchPlay.bind(photoshop.action)
        : null;
  const layerRefs = new Map();
  const maskSnapshots = new Map();
  let activePreviewKey = null;
  let activePreviewLayerInfo = null;

  function layerKey(layerInfo) {
    if (!layerInfo || !Number.isFinite(Number(layerInfo.documentID)) || !Number.isFinite(Number(layerInfo.layerID))) {
      throw new Error("图层信息不完整。");
    }
    return `${layerInfo.documentID}:${layerInfo.layerID}`;
  }

  function normalizedLayerInfo(layerInfo) {
    layerKey(layerInfo);
    const bounds = toBounds(layerInfo.bounds);
    return {
      ...layerInfo,
      bounds
    };
  }

  function copyAlpha(alpha, layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    const expectedLength = normalized.bounds.width * normalized.bounds.height;
    if (!(alpha instanceof Uint8Array) || alpha.length !== expectedLength) {
      throw new Error("蒙版尺寸与图层边界不一致。");
    }
    return new Uint8Array(alpha);
  }

  function layerReference(layerInfo) {
    return layerRefs.get(layerKey(layerInfo)) || layerInfo.layer || layerInfo.layerRef || null;
  }

  function assertDocumentIsActive(layerInfo) {
    const activeDocument = app && app.activeDocument;
    if (activeDocument && activeDocument.id !== undefined && Number(activeDocument.id) !== Number(layerInfo.documentID)) {
      throw new Error("当前 Photoshop 文档已切换，请重新读取图层。");
    }
  }

  function hasKnownMissingMask(layerInfo) {
    const candidate = layerReference(layerInfo);
    const values = [
      layerInfo && layerInfo.hasUserMask,
      layerInfo && layerInfo.hasMask,
      layerInfo && layerInfo.pixelMask && layerInfo.pixelMask.hasMask,
      layerInfo && layerInfo.userMask && layerInfo.userMask.hasMask,
      candidate && candidate.hasUserMask,
      candidate && candidate.hasMask,
      candidate && candidate.pixelMask && candidate.pixelMask.hasMask,
      candidate && candidate.userMask && candidate.userMask.hasMask
    ];
    return values.some((value) => value === false);
  }

  function isMissingMaskError(error) {
    const message = String(error && error.message || error || "").toLowerCase();
    return /mask|channel/.test(message) && /(not found|does not exist|doesn't exist|missing|absent|no .*mask|without .*mask|invalid)/.test(message);
  }

  function maskBounds(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    return {
      left: normalized.bounds.left,
      top: normalized.bounds.top,
      right: normalized.bounds.right,
      bottom: normalized.bounds.bottom
    };
  }

  function maskSnapshotCopy(snapshot) {
    return {
      documentID: snapshot.documentID,
      layerID: snapshot.layerID,
      width: snapshot.width,
      height: snapshot.height,
      bounds: { ...snapshot.bounds },
      present: snapshot.present === true,
      hasMask: snapshot.present === true,
      alpha: snapshot.alpha ? new Uint8Array(snapshot.alpha) : null,
      mask: snapshot.alpha ? new Uint8Array(snapshot.alpha) : null
    };
  }

  function canRemoveLayerMask(layerInfo) {
    if (play) return true;
    const layer = layerReference(layerInfo);
    if (!layer) return false;
    const masks = [layer.pixelMask, layer.userMask].filter(Boolean);
    return typeof layer.removeLayerMask === "function"
      || typeof layer.deleteLayerMask === "function"
      || masks.some((mask) => typeof mask.remove === "function" || typeof mask.delete === "function");
  }

  async function executeModal(work, commandName) {
    if (!core || typeof core.executeAsModal !== "function") {
      throw new Error("Photoshop executeAsModal API 不可用。");
    }
    return core.executeAsModal(work, { commandName });
  }

  async function removeLayerUserMask(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    assertDocumentIsActive(normalized);
    const layerID = normalized.layerID;
    await executeModal(async () => {
      if (play) {
        await play([{
          _obj: "delete",
          _target: [
            { _ref: "channel", _enum: "channel", _value: "mask" },
            { _ref: "layer", _id: layerID }
          ]
        }], {});
        return;
      }

      const layer = layerReference(normalized);
      const mask = layer && (layer.pixelMask || layer.userMask);
      const remove = layer && (layer.removeLayerMask || layer.deleteLayerMask);
      if (typeof remove === "function") {
        await remove.call(layer);
        return;
      }
      if (mask && typeof mask.remove === "function") {
        await mask.remove();
        return;
      }
      if (mask && typeof mask.delete === "function") {
        await mask.delete();
        return;
      }
      throw new Error("Photoshop 无法删除临时图层蒙版，请注入 action.batchPlay。");
    }, "取消离线抠图蒙版预览");
  }

  async function readLayerMask(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    const expectedWidth = normalized.bounds.width;
    const expectedHeight = normalized.bounds.height;
    const emptySnapshot = {
      documentID: normalized.documentID,
      layerID: normalized.layerID,
      width: expectedWidth,
      height: expectedHeight,
      bounds: { ...normalized.bounds },
      present: false,
      hasMask: false,
      alpha: null,
      mask: null
    };

    if (!imaging || typeof imaging.getLayerMask !== "function") {
      if (hasKnownMissingMask(normalized)) return emptySnapshot;
      throw new Error("Photoshop imaging.getLayerMask API 不可用。");
    }

    let result;
    try {
      result = await imaging.getLayerMask({
        documentID: normalized.documentID,
        layerID: normalized.layerID,
        kind: "user",
        sourceBounds: maskBounds(normalized)
      });
    } catch (error) {
      if (hasKnownMissingMask(normalized) || isMissingMaskError(error)) return emptySnapshot;
      throw error;
    }

    if (!result || !result.imageData) {
      throw new Error("Photoshop 返回了无效的图层蒙版数据。");
    }
    const imageData = result.imageData;
    try {
      const width = Number(imageData.width);
      const height = Number(imageData.height);
      const components = Number(imageData.components);
      if (components && components !== 1) {
        throw new Error("Photoshop 图层蒙版必须是单通道灰度数据。");
      }
      if (width !== expectedWidth || height !== expectedHeight) {
        throw new Error("Photoshop 图层蒙版尺寸与图层边界不一致。");
      }
      const data = await imageData.getData({ chunky: true });
      const alpha = new Uint8Array(data);
      if (alpha.length !== expectedWidth * expectedHeight) {
        throw new Error("Photoshop 图层蒙版数据长度不正确。");
      }
      const snapshot = {
        documentID: normalized.documentID,
        layerID: normalized.layerID,
        width: expectedWidth,
        height: expectedHeight,
        bounds: { ...normalized.bounds },
        present: true,
        hasMask: true,
        alpha,
        mask: new Uint8Array(alpha),
        sourceBounds: toBounds(result.sourceBounds || normalized.bounds)
      };
      return snapshot;
    } finally {
      if (typeof imageData.dispose === "function") imageData.dispose();
    }
  }

  async function saveLayerMask(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    const key = layerKey(normalized);
    if (maskSnapshots.has(key)) return maskSnapshotCopy(maskSnapshots.get(key));
    const snapshot = await readLayerMask(normalized);
    const copy = maskSnapshotCopy(snapshot);
    maskSnapshots.set(key, copy);
    return maskSnapshotCopy(copy);
  }

  async function writeLayerMask(layerInfo, alpha) {
    const normalized = normalizedLayerInfo(layerInfo);
    assertDocumentIsActive(normalized);
    const copy = copyAlpha(alpha, normalized);
    await executeModal(async () => {
      const maskData = await imaging.createImageDataFromBuffer(copy, {
        width: normalized.bounds.width,
        height: normalized.bounds.height,
        components: 1,
        chunky: false,
        colorProfile: "Gray Gamma 2.2",
        colorSpace: "Grayscale"
      });

      try {
        await imaging.putLayerMask({
          documentID: normalized.documentID,
          layerID: normalized.layerID,
          kind: "user",
          imageData: maskData,
          replace: true,
          targetBounds: {
            left: normalized.bounds.left,
            top: normalized.bounds.top
          },
          commandName: "应用离线抠图蒙版"
        });
      } finally {
        if (maskData && typeof maskData.dispose === "function") maskData.dispose();
      }
    }, "应用离线抠图蒙版");
    return copy;
  }

  async function restoreLayerMask(layerInfo, snapshot) {
    const normalized = normalizedLayerInfo(layerInfo);
    if (!snapshot || snapshot.present !== true) {
      await removeLayerUserMask(normalized);
      return;
    }
    await writeLayerMask(normalized, snapshot.alpha || snapshot.mask);
  }
  function getActivePixelLayer() {
    if (!app.documents || app.documents.length === 0) {
      throw new Error("请先打开一个 Photoshop 文档。");
    }

    const document = app.activeDocument;
    const layer = document.activeLayers && document.activeLayers[0];
    if (!layer) {
      throw new Error("请先选择一个图层。");
    }
    if (layer.kind !== constants.LayerKind.NORMAL) {
      throw new Error("第一版只支持像素图层。");
    }

    const layerInfo = {
      documentID: document.id,
      layerID: layer.id,
      name: layer.name,
      bounds: toBounds(layer.boundsNoEffects || layer.bounds)
    };
    layerRefs.set(layerKey(layerInfo), layer);
    return { ...layerInfo };
  }

  async function readLayerPixels(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    const result = await imaging.getPixels({
      documentID: normalized.documentID,
      layerID: normalized.layerID,
      sourceBounds: {
        left: normalized.bounds.left,
        top: normalized.bounds.top,
        right: normalized.bounds.right,
        bottom: normalized.bounds.bottom
      },
      colorSpace: "RGB",
      componentSize: 8,
      applyAlpha: false
    });
    try {
      const data = await result.imageData.getData({ chunky: true });
      const copy = new Uint8Array(data);
      const bounds = toBounds(result.sourceBounds || normalized.bounds);
      return {
        pixels: copy,
        width: result.imageData.width,
        height: result.imageData.height,
        components: result.imageData.components,
        bounds
      };
    } finally {
      if (typeof result.imageData.dispose === "function") result.imageData.dispose();
    }
  }

  async function legacyPutLayerMask(layerInfo, alpha) {
    const expectedLength = layerInfo.bounds.width * layerInfo.bounds.height;
    if (!(alpha instanceof Uint8Array) || alpha.length !== expectedLength) {
      throw new Error("蒙版尺寸与图层边界不一致。");
    }

    await core.executeAsModal(async () => {
      const maskData = await imaging.createImageDataFromBuffer(alpha, {
        width: layerInfo.bounds.width,
        height: layerInfo.bounds.height,
        components: 1,
        chunky: false,
        colorProfile: "Gray Gamma 2.2",
        colorSpace: "Grayscale"
      });

      try {
        await imaging.putLayerMask({
          documentID: layerInfo.documentID,
          layerID: layerInfo.layerID,
          kind: "user",
          imageData: maskData,
          replace: true,
          targetBounds: {
            left: layerInfo.bounds.left,
            top: layerInfo.bounds.top
          },
          commandName: "应用离线抠图蒙版"
        });
      } finally {
        maskData.dispose();
      }
    }, { commandName: "应用离线抠图蒙版" });
  }

  // Keep the original method name as a committed-write API while routing it
  // through the validated writer used by temporary previews.
  async function putLayerMask(layerInfo, alpha) {
    const normalized = normalizedLayerInfo(layerInfo);
    const copy = await writeLayerMask(normalized, alpha);
    const key = layerKey(normalized);
    maskSnapshots.delete(key);
    if (activePreviewKey === key) {
      activePreviewKey = null;
      activePreviewLayerInfo = null;
    }
    return copy;
  }

  async function previewLayerMask(layerInfo, alpha) {
    const normalized = normalizedLayerInfo(layerInfo);
    const copy = copyAlpha(alpha, normalized);
    const key = layerKey(normalized);
    let snapshot = maskSnapshots.get(key);
    let createdSnapshot = false;
    if (!snapshot) {
      snapshot = await readLayerMask(normalized);
      snapshot = maskSnapshotCopy(snapshot);
      maskSnapshots.set(key, snapshot);
      createdSnapshot = true;
    }
    // A layer without a mask needs a reversible remove operation after the
    // preview creates one. Refuse to write if no such operation was injected.
    if (!snapshot.present && !canRemoveLayerMask(normalized)) {
      if (createdSnapshot) maskSnapshots.delete(key);
      throw new Error("无法安全预览无原始图层蒙版的图层，请注入 action.batchPlay。");
    }

    try {
      await writeLayerMask(normalized, copy);
    } catch (error) {
      if (createdSnapshot) maskSnapshots.delete(key);
      throw error;
    }
    activePreviewKey = key;
    activePreviewLayerInfo = normalized;
    return {
      previewing: true,
      documentID: normalized.documentID,
      layerID: normalized.layerID,
      width: normalized.bounds.width,
      height: normalized.bounds.height,
      bounds: { ...normalized.bounds },
      alpha: new Uint8Array(copy),
      original: maskSnapshotCopy(snapshot)
    };
  }

  async function cancelMaskPreview(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo || activePreviewLayerInfo);
    const key = layerKey(normalized);
    const snapshot = maskSnapshots.get(key);
    if (!snapshot) {
      if (activePreviewKey === key) {
        activePreviewKey = null;
        activePreviewLayerInfo = null;
      }
      return {
        restored: false,
        previewing: false,
        documentID: normalized.documentID,
        layerID: normalized.layerID
      };
    }
    await restoreLayerMask(normalized, snapshot);
    maskSnapshots.delete(key);
    if (activePreviewKey === key) {
      activePreviewKey = null;
      activePreviewLayerInfo = null;
    }
    return { restored: true, previewing: false, original: maskSnapshotCopy(snapshot) };
  }

  async function applyLayerMask(layerInfo, alpha) {
    const normalized = normalizedLayerInfo(layerInfo);
    const copy = await writeLayerMask(normalized, alpha);
    const key = layerKey(normalized);
    maskSnapshots.delete(key);
    if (activePreviewKey === key) {
      activePreviewKey = null;
      activePreviewLayerInfo = null;
    }
    return {
      applied: true,
      documentID: normalized.documentID,
      layerID: normalized.layerID,
      width: normalized.bounds.width,
      height: normalized.bounds.height,
      bounds: { ...normalized.bounds },
      alpha: new Uint8Array(copy)
    };
  }

  return {
    getActivePixelLayer,
    readLayerPixels,
    putLayerMask,
    readLayerMask,
    saveLayerMask,
    previewLayerMask,
    cancelMaskPreview,
    applyLayerMask,
    readUserMask: readLayerMask,
    saveOriginalLayerMask: saveLayerMask,
    previewAlpha: previewLayerMask,
    cancelPreview: cancelMaskPreview,
    applyMask: applyLayerMask
  };
}

module.exports = { createPhotoshopHost, toBounds };
