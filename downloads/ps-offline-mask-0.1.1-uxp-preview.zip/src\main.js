const { entrypoints } = require("uxp");
const photoshop = require("photoshop");
const { app, constants, imaging, core, action } = photoshop;
const { TrimapRaster, LABELS } = require("./core/trimap");
const { createEngine } = require("./core/engine");
const { autoTrimap } = require("./core/autoTrimap");
const { createPhotoshopHost } = require("./host/photoshopHost");
const { createRequestId, VisionApiError } = require("./core/visionApi");

const runtimeVisionConfig = typeof globalThis !== "undefined" ? globalThis.__PS_MASK_VISION_API__ : null;
let visionConfigError = null;
let visionClientConfig = null;
if (runtimeVisionConfig && typeof runtimeVisionConfig === "object") {
  visionClientConfig = runtimeVisionConfig;
}

let engine;
try {
  engine = createEngine({
    visionApi: visionClientConfig || undefined,
    requireFn: require
  });
} catch (error) {
  visionConfigError = error;
  engine = createEngine({ requireFn: require });
}

const host = createPhotoshopHost({ app, constants, imaging, core, action });
const state = {
  mounted: false,
  drawing: false,
  tool: "unknown",
  brushSize: 32,
  viewMode: "mark",
  layer: null,
  source: null,
  trimap: null,
  alpha: null,
  lastPoint: null,
  engineMode: "algorithm",
  previewActive: false,
  requestId: null,
  requestController: null,
  previewPromise: null,
  previewCanceling: false,
  progressTimer: null,
  progressTimerToken: null,
  busy: false,
  busyOperation: null,
  lastOperation: null,
  lastError: null,
  operationToken: 0
};

function element(id) {
  return document.getElementById(id);
}

function clearErrorActions() {
  const actions = element("error-actions");
  if (actions) actions.hidden = true;
  const retry = element("retry-compute");
  if (retry) retry.hidden = false;
  state.lastError = null;
}

function showErrorActions(error) {
  const actions = element("error-actions");
  if (!actions || !(error instanceof VisionApiError)) return;
  const shouldShow = error.category !== "canceled";
  actions.hidden = !shouldShow;
  const retry = element("retry-compute");
  if (retry) retry.hidden = error.accepted === true;
  state.lastError = error;
}

function setMessage(message, isError = false) {
  const node = element("message");
  node.textContent = message;
  node.style.color = isError ? "#ef746f" : "";
  if (!isError) clearErrorActions();
}

function setBusy(isBusy, operation = null) {
  state.busy = isBusy;
  state.busyOperation = isBusy ? operation : null;
  element("load-layer").disabled = isBusy;
  element("auto-cutout").disabled = isBusy || !state.source;
  element("compute-mask").disabled = isBusy || !state.trimap;
  element("apply-mask").disabled = isBusy || !state.alpha || !state.previewActive;
  const mode = element("engine-mode");
  if (mode) mode.disabled = isBusy;
  const consent = element("vision-consent");
  if (consent) consent.disabled = isBusy || !engine.availableModes().visionApi;
  ["view-mode", "brush-size", "edge-shift", "feather", "hard-threshold", "invert-mask"]
    .map((id) => element(id))
    .filter(Boolean)
    .forEach((control) => { control.disabled = isBusy; });
  document.querySelectorAll(".tool-button").forEach((button) => { button.disabled = isBusy; });
  const reset = element("reset-mark");
  if (reset) reset.disabled = isBusy && !["compute", "auto"].includes(state.busyOperation);
}

function setResultState(text, isReady = false) {
  const node = document.querySelector("[data-result-state]");
  if (!node) return;
  node.textContent = text;
  node.classList.toggle("ready", isReady);
}

function getOptions() {
  return {
    edgeShift: Number(element("edge-shift").value),
    feather: Number(element("feather").value),
    hardThreshold: Number(element("hard-threshold").value),
    invert: element("invert-mask").checked
  };
}

function updateEngineUI() {
  const mode = element("engine-mode");
  const hint = element("engine-hint");
  const endpointStatus = element("vision-endpoint-status");
  const consent = element("vision-consent");
  const visionAvailable = engine.availableModes().visionApi;
  const visionOption = mode && mode.querySelector('option[value="vision-api"]');

  if (visionOption) visionOption.disabled = !visionAvailable;
  if (consent) consent.disabled = !visionAvailable || state.busy;
  if (mode) mode.value = state.engineMode;
  if (hint) hint.textContent = state.engineMode === "vision-api" ? "AI 视觉模型 · 会发送图层数据" : "本地算法 · 不上传图片";
  let endpointHost = "";
  if (visionClientConfig && visionClientConfig.endpoint) {
    try {
      endpointHost = new URL(visionClientConfig.endpoint).host;
    } catch (error) {
      endpointHost = String(visionClientConfig.endpoint).replace(/^https?:\/\//i, "").split("/")[0];
    }
  }
  if (endpointStatus) {
    endpointStatus.textContent = visionConfigError
      ? "AI 配置无效，已保持本地算法。"
      : visionAvailable
        ? `AI 服务已配置${endpointHost ? `：${endpointHost}` : ""}；图层数据会外发，留存策略未知，请确认服务商条款。`
        : "未配置 AI 视觉模型服务，当前仅使用本地算法。";
    endpointStatus.style.color = visionConfigError ? "#ef746f" : "";
  }
  const status = element("engine-status");
  if (status) status.textContent = engine.describe();
  const modeLabel = document.querySelector(".engine-mode");
  if (modeLabel) modeLabel.textContent = state.engineMode === "vision-api" ? "AI 视觉模型" : "本地算法";
}

function selectEngineMode(nextMode) {
  if (nextMode === "vision-api") {
    const consent = element("vision-consent");
    if (!engine.availableModes().visionApi) {
      setMessage("AI 视觉模型尚未配置，已保持本地算法。", true);
      updateEngineUI();
      return;
    }
    if (!consent || !consent.checked) {
      setMessage("请先确认图层数据会发送到已配置的 AI 服务。", true);
      updateEngineUI();
      return;
    }
  }

  try {
    engine.setMode(nextMode);
    state.engineMode = nextMode;
    setMessage(nextMode === "vision-api" ? "已切换到 AI 视觉模型，下一次计算会发送图层数据。" : "已切换到本地算法，不会上传图片。");
    updateEngineUI();
  } catch (error) {
    state.engineMode = "algorithm";
    setMessage(error.message || "切换计算引擎失败。", true);
    updateEngineUI();
  }
}

function getLabel() {
  if (state.tool === "keep") return LABELS.KEEP;
  if (state.tool === "cut") return LABELS.CUT;
  return LABELS.UNKNOWN;
}

function getCanvasPoint(event, canvas) {
  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / Math.max(1, rect.width);
  const scaleY = canvas.height / Math.max(1, rect.height);
  return {
    x: (event.clientX - rect.left) * scaleX,
    y: (event.clientY - rect.top) * scaleY
  };
}

function drawSource(context) {
  const { source } = state;
  const image = context.createImageData(source.width, source.height);
  const channels = source.components >= 4 ? 4 : 3;
  for (let index = 0; index < source.width * source.height; index += 1) {
    const sourceIndex = index * source.components;
    const targetIndex = index * 4;
    image.data[targetIndex] = source.pixels[sourceIndex] || 0;
    image.data[targetIndex + 1] = source.pixels[sourceIndex + 1] || 0;
    image.data[targetIndex + 2] = source.pixels[sourceIndex + 2] || 0;
    image.data[targetIndex + 3] = channels === 4 ? source.pixels[sourceIndex + 3] : 255;
  }
  context.putImageData(image, 0, 0);
}

function drawMask(context) {
  const image = context.createImageData(state.source.width, state.source.height);
  for (let index = 0; index < state.alpha.length; index += 1) {
    const value = state.alpha[index];
    const targetIndex = index * 4;
    image.data[targetIndex] = value;
    image.data[targetIndex + 1] = value;
    image.data[targetIndex + 2] = value;
    image.data[targetIndex + 3] = 255;
  }
  context.putImageData(image, 0, 0);
}

function drawTrimapOverlay(context) {
  if (!state.trimap) return;
  const overlay = context.createImageData(state.trimap.width, state.trimap.height);
  for (let index = 0; index < state.trimap.data.length; index += 1) {
    const label = state.trimap.data[index];
    const targetIndex = index * 4;
    if (label === LABELS.KEEP) {
      overlay.data[targetIndex] = 70;
      overlay.data[targetIndex + 1] = 225;
      overlay.data[targetIndex + 2] = 120;
      overlay.data[targetIndex + 3] = 110;
    } else if (label === LABELS.CUT) {
      overlay.data[targetIndex] = 240;
      overlay.data[targetIndex + 1] = 90;
      overlay.data[targetIndex + 2] = 90;
      overlay.data[targetIndex + 3] = 115;
    } else if (label === LABELS.UNKNOWN && state.trimap.painted[index]) {
      overlay.data[targetIndex] = 80;
      overlay.data[targetIndex + 1] = 155;
      overlay.data[targetIndex + 2] = 255;
      overlay.data[targetIndex + 3] = 70;
    }
  }
  context.putImageData(overlay, 0, 0);
}

function draw() {
  const canvas = element("preview-canvas");
  const placeholder = element("canvas-placeholder");
  if (!state.source) {
    placeholder.style.display = "block";
    return;
  }

  placeholder.style.display = "none";
  canvas.width = state.source.width;
  canvas.height = state.source.height;
  const context = canvas.getContext("2d");
  context.clearRect(0, 0, canvas.width, canvas.height);
  if (state.viewMode === "mask" && state.alpha) {
    drawMask(context);
  } else {
    drawSource(context);
    drawTrimapOverlay(context);
  }
}

async function loadLayer() {
  if (state.busy) return;
  setBusy(true, "load");
  try {
    if (state.previewActive && state.layer) await cancelCurrentPreview();
    const layer = host.getActivePixelLayer();
    const source = await host.readLayerPixels(layer);
    state.layer = { ...layer, bounds: source.bounds };
    state.source = source;
    state.trimap = new TrimapRaster(source.width, source.height);
    state.alpha = null;
    state.requestId = null;
    element("layer-status").textContent = `${layer.name} · ${source.width} × ${source.height}`;
    setMessage(`已读取图层。当前引擎：${engine.describe()}`);
    setResultState("还没有生成蒙版");
    draw();
  } catch (error) {
    setMessage(error.message || "读取图层失败。", true);
  } finally {
    setBusy(false);
  }
}

async function previewAlpha(alpha) {
  if (!state.layer || !(alpha instanceof Uint8Array)) return false;
  if (typeof host.previewLayerMask !== "function") return false;
  await host.previewLayerMask(state.layer, alpha);
  state.previewActive = true;
  return true;
}

async function runPreview(alpha) {
  const previewPromise = previewAlpha(alpha);
  state.previewPromise = previewPromise;
  try {
    return await previewPromise;
  } finally {
    if (state.previewPromise === previewPromise) state.previewPromise = null;
  }
}

async function cancelCurrentPreview() {
  if (!state.previewActive) return false;
  if (!state.layer || typeof host.cancelMaskPreview !== "function") {
    throw new Error("无法安全取消 Photoshop 临时蒙版预览。");
  }
  const cancelPromise = host.cancelMaskPreview(state.layer);
  state.previewPromise = cancelPromise;
  try {
    await cancelPromise;
    state.previewActive = false;
    return true;
  } finally {
    if (state.previewPromise === cancelPromise) state.previewPromise = null;
  }
}

function describeEngineError(error) {
  if (error instanceof VisionApiError) {
    if (error.category === "canceled") return "AI 视觉模型请求已取消。";
    if (error.category === "timeout") return "AI 视觉模型请求超时，可重试或切换到本地算法。";
    if (error.category === "authentication") return "AI 视觉模型认证失败，请检查运行时配置。";
    if (error.category === "permission") return "AI 视觉模型服务拒绝了当前权限，请检查项目授权或模型访问范围。";
    if (error.category === "rate-limit") return "AI 视觉模型服务限流，请稍后重试。";
    if (error.category === "response-format") return "AI 视觉模型返回了无法识别的蒙版。";
    if (error.category === "server") return "AI 视觉模型服务暂时不可用，可重试或切换到本地算法。";
    if (error.category === "configuration") return "AI 视觉模型配置无效，已保持本地算法。";
    if (error.accepted) return "AI 服务可能已接受本次请求，但返回结果无法识别；请先确认服务端记录，再决定是否重试。";
    return "AI 视觉模型请求失败，可重试或切换到本地算法。";
  }
  return error && error.message ? error.message : "蒙版计算失败。";
}

function describeDiagnostics(diagnostics) {
  if (!diagnostics || typeof diagnostics !== "object") return "";
  const parts = [];
  if (diagnostics.model) parts.push(`模型 ${diagnostics.model}`);
  if (diagnostics.modelVersion) parts.push(`版本 ${diagnostics.modelVersion}`);
  if (Number.isFinite(Number(diagnostics.confidence))) {
    parts.push(`置信度 ${Math.round(Number(diagnostics.confidence))}%`);
  }
  if (Number.isFinite(Number(diagnostics.processingMs))) {
    parts.push(`${Math.round(Number(diagnostics.processingMs))} ms`);
  }
  if (diagnostics.traceId) parts.push(`追踪 ${diagnostics.traceId}`);
  const warnings = Array.isArray(diagnostics.warnings) ? [...diagnostics.warnings] : [];
  if (diagnostics.warning) warnings.push(diagnostics.warning);
  if (warnings.length) parts.push(`提示：${warnings.join("；")}`);
  return parts.join(" · ");
}

function clearProgressTimer(token) {
  if (token !== undefined && state.progressTimerToken !== token) return;
  if (state.progressTimer) clearTimeout(state.progressTimer);
  state.progressTimer = null;
  state.progressTimerToken = null;
}

function startVisionProgress(token, prepareMessage) {
  clearProgressTimer();
  setMessage(prepareMessage);
  state.progressTimerToken = token;
  state.progressTimer = setTimeout(() => {
    if (!state.busy || state.operationToken !== token) return;
    setMessage("正在上传图层数据……");
    state.progressTimer = setTimeout(() => {
      if (state.busy && state.operationToken === token) setMessage("图层数据已发送，AI 服务处理中……");
    }, 500);
  }, 100);
}

function beginRequest() {
  const token = state.operationToken + 1;
  state.operationToken = token;
  state.requestController = typeof AbortController === "function" ? new AbortController() : null;
  return { controller: state.requestController, token };
}

function endRequest(request) {
  if (state.requestController === request.controller) state.requestController = null;
}

async function computeMask() {
  if (!state.source || !state.trimap || state.busy) return;
  setBusy(true, "compute");
  state.lastOperation = "compute";
  const request = beginRequest();
  const requestController = request.controller;
  try {
    state.requestId = createRequestId();
    if (state.engineMode === "vision-api") startVisionProgress(request.token, "准备发送图层数据……");
    else setMessage("正在计算蒙版，请稍候……");
    if (state.previewActive) await cancelCurrentPreview();
    if (request.token !== state.operationToken) return;
    const response = await engine.compute({
      pixels: state.source.pixels,
      width: state.source.width,
      height: state.source.height,
      components: state.source.components,
      trimap: state.trimap.data,
      requestId: state.requestId,
      ...(requestController ? { signal: requestController.signal } : {}),
      options: getOptions()
    });
    if (request.token !== state.operationToken) return;
    state.alpha = response.alpha;
    let previewed = false;
    try {
      previewed = await runPreview(state.alpha);
    } catch (previewError) {
      if (request.token !== state.operationToken) return;
      state.previewActive = false;
      setResultState("预览失败，不能应用蒙版");
      setMessage(`蒙版已计算，但无法在 Photoshop 画布预览：${previewError.message || "宿主接口不可用。"}`, true);
      return;
    }
    if (request.token !== state.operationToken) return;
    element("view-mode").value = "mask";
    state.viewMode = "mask";
    setResultState(previewed ? "正在预览临时蒙版" : "预览失败，不能应用蒙版", previewed);
    draw();
    const diagnostics = describeDiagnostics(response.diagnostics);
    if (previewed) setMessage(`蒙版已生成，结果正在 Photoshop 画布中预览。${diagnostics ? ` ${diagnostics}` : ""}`);
    else setMessage("蒙版已计算，但 Photoshop 画布预览不可用，因此不能应用。", true);
  } catch (error) {
    if (request.token !== state.operationToken) return;
    setMessage(describeEngineError(error), true);
    showErrorActions(error);
  } finally {
    clearProgressTimer(request.token);
    endRequest(request);
    if (request.token === state.operationToken) {
      setBusy(false);
      updateEngineUI();
    }
  }
}

async function autoCutout() {
  if (!state.source || state.busy) return;
  setBusy(true, "auto");
  state.lastOperation = "auto";
  const request = beginRequest();
  const requestController = request.controller;
  try {
    state.requestId = createRequestId();
    if (state.engineMode === "vision-api") startVisionProgress(request.token, "准备 Trimap 并发送图层数据……");
    else setMessage("正在根据边界和透明通道自动推测前景……");
    if (state.previewActive) await cancelCurrentPreview();
    if (request.token !== state.operationToken) return;
    const generated = autoTrimap({
      pixels: state.source.pixels,
      width: state.source.width,
      height: state.source.height,
      components: state.source.components
    });
    state.trimap = generated.trimap;
    state.alpha = null;
    const response = await engine.compute({
      pixels: state.source.pixels,
      width: state.source.width,
      height: state.source.height,
      components: state.source.components,
      trimap: state.trimap.data,
      requestId: state.requestId,
      ...(requestController ? { signal: requestController.signal } : {}),
      options: getOptions()
    });
    if (request.token !== state.operationToken) return;
    state.alpha = response.alpha;
    let previewed = false;
    try {
      previewed = await runPreview(state.alpha);
    } catch (previewError) {
      if (request.token !== state.operationToken) return;
      state.previewActive = false;
      setResultState("预览失败，不能应用蒙版");
      setMessage(`蒙版已计算，但无法在 Photoshop 画布预览：${previewError.message || "宿主接口不可用。"}`, true);
      return;
    }
    if (request.token !== state.operationToken) return;
    state.viewMode = "mask";
    element("view-mode").value = "mask";
    setResultState(previewed ? "正在预览临时蒙版" : "预览失败，不能应用蒙版", previewed);
    draw();
    if (previewed) {
      const diagnostics = state.engineMode === "vision-api"
        ? describeDiagnostics(response.diagnostics)
        : `算法置信度约 ${Math.round(generated.diagnostics.confidence * 100)}%`;
      const warning = state.engineMode === "algorithm" && generated.diagnostics.confidence < 0.55
        ? "建议用保留/删除笔刷修正后重新计算。"
        : "请检查 Photoshop 画布中的蒙版后再应用。";
      setMessage(`一键抠图完成，${diagnostics || "结果已生成"}。${warning}`, state.engineMode === "algorithm" && generated.diagnostics.confidence < 0.55);
    } else {
      setMessage("一键抠图已计算，但 Photoshop 画布预览不可用，因此不能应用。", true);
    }
  } catch (error) {
    if (request.token !== state.operationToken) return;
    setMessage(describeEngineError(error), true);
    showErrorActions(error);
  } finally {
    clearProgressTimer(request.token);
    endRequest(request);
    if (request.token === state.operationToken) {
      setBusy(false);
      updateEngineUI();
    }
  }
}

async function applyMask() {
  if (!state.layer || !state.alpha || !state.previewActive || state.busy) {
    if (state.alpha && !state.previewActive) setMessage("请先在 Photoshop 画布中成功预览蒙版，再应用。", true);
    return;
  }
  setBusy(true, "apply");
  try {
    if (typeof host.applyLayerMask === "function") await host.applyLayerMask(state.layer, state.alpha);
    else await host.putLayerMask(state.layer, state.alpha);
    state.previewActive = false;
    setResultState("蒙版已应用", true);
    setMessage("图层蒙版已应用，可以在 Photoshop 中继续编辑。", false);
  } catch (error) {
    setMessage(error.message || "应用蒙版失败。", true);
  } finally {
    setBusy(false);
  }
}

async function resetMark() {
  if (!state.trimap || (state.busy && !["compute", "auto"].includes(state.busyOperation))) return;
  state.operationToken += 1;
  if (state.requestController) {
    state.requestController.abort();
    state.requestController = null;
  }
  clearProgressTimer();
  setBusy(true, "reset");
  try {
    if (state.previewPromise) await state.previewPromise;
    if (state.previewActive) await cancelCurrentPreview();
  } catch (error) {
    setMessage(error.message || "取消蒙版预览失败。", true);
    setBusy(false);
    return;
  }
  state.trimap.clear();
  state.alpha = null;
  state.requestId = null;
  element("view-mode").value = "mark";
  state.viewMode = "mark";
  setResultState("还没有生成蒙版");
  setMessage("预览已取消，标记和计算结果已重置。");
  draw();
  setBusy(false);
}

async function cancelPreviewForEditing() {
  if (!state.previewActive || !state.layer || typeof host.cancelMaskPreview !== "function" || state.previewCanceling) return false;
  state.previewCanceling = true;
  try {
    await cancelCurrentPreview();
    setResultState("标记已修改，等待重新计算");
    return true;
  } catch (error) {
    setMessage(error.message || "取消旧蒙版预览失败。", true);
    return false;
  } finally {
    state.previewCanceling = false;
  }
}

function beginPaint(event) {
  if (!state.trimap || state.busy || state.previewCanceling) return;
  if (state.previewActive) {
    void cancelPreviewForEditing();
    return;
  }
  const canvas = element("preview-canvas");
  state.drawing = true;
  state.lastPoint = getCanvasPoint(event, canvas);
  state.trimap.paintCircle(state.lastPoint.x, state.lastPoint.y, state.brushSize, getLabel());
  state.alpha = null;
  draw();
  if (typeof canvas.setPointerCapture === "function") canvas.setPointerCapture(event.pointerId);
}

function continuePaint(event) {
  if (state.busy || !state.drawing || !state.trimap) return;
  const canvas = element("preview-canvas");
  const point = getCanvasPoint(event, canvas);
  state.trimap.paintLine(state.lastPoint.x, state.lastPoint.y, point.x, point.y, state.brushSize, getLabel());
  state.lastPoint = point;
  state.alpha = null;
  draw();
}

function endPaint() {
  state.drawing = false;
  state.lastPoint = null;
}

function retryLastOperation() {
  if (state.busy) return;
  clearErrorActions();
  if (state.lastOperation === "auto") void autoCutout();
  else if (state.lastOperation === "compute") void computeMask();
}

function switchToLocalEngine() {
  clearErrorActions();
  const mode = element("engine-mode");
  if (mode) mode.value = "algorithm";
  selectEngineMode("algorithm");
}

function mount() {
  if (state.mounted || !element("preview-canvas")) return;
  state.mounted = true;
  element("engine-status").textContent = engine.describe();
  updateEngineUI();
  element("load-layer").addEventListener("click", loadLayer);
  element("auto-cutout").addEventListener("click", autoCutout);
  element("compute-mask").addEventListener("click", computeMask);
  element("apply-mask").addEventListener("click", applyMask);
  element("reset-mark").addEventListener("click", resetMark);
  element("view-mode").addEventListener("change", (event) => {
    if (state.busy) return;
    state.viewMode = event.target.value;
    draw();
  });
  element("brush-size").addEventListener("input", (event) => {
    if (state.busy) return;
    state.brushSize = Number(event.target.value);
    element("brush-size-value").textContent = String(state.brushSize);
  });
  const engineMode = element("engine-mode");
  if (engineMode) engineMode.addEventListener("change", (event) => selectEngineMode(event.target.value));
  const consent = element("vision-consent");
  if (consent) consent.addEventListener("change", () => {
    if (consent.checked && engineMode && engineMode.value === "vision-api") selectEngineMode("vision-api");
    if (!consent.checked && state.engineMode === "vision-api") {
      if (engineMode) engineMode.value = "algorithm";
      selectEngineMode("algorithm");
    }
    updateEngineUI();
  });
  const retry = element("retry-compute");
  if (retry) retry.addEventListener("click", retryLastOperation);
  const useLocal = element("use-local-engine");
  if (useLocal) useLocal.addEventListener("click", switchToLocalEngine);
  document.querySelectorAll(".tool-button").forEach((button) => {
    button.addEventListener("click", () => {
      if (state.busy) return;
      state.tool = button.dataset.tool;
      document.querySelectorAll(".tool-button").forEach((item) => item.classList.toggle("active", item === button));
    });
  });
  element("preview-canvas").addEventListener("pointerdown", beginPaint);
  element("preview-canvas").addEventListener("pointermove", continuePaint);
  element("preview-canvas").addEventListener("pointerup", endPaint);
  element("preview-canvas").addEventListener("pointerleave", endPaint);
  draw();
  setBusy(false);
}

entrypoints.setup({
  panels: {
    maskPanel: {
      create() {
        mount();
      },
      destroy() {
        state.mounted = false;
      }
    }
  }
});

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", mount);
} else {
  mount();
}
