function isCanceled(signal, error) {
  return Boolean(signal && signal.aborted)
    || Boolean(error && (error.name === "AbortError" || error.code === "canceled"));
}

function assertFunction(value, name) {
  if (typeof value !== "function") throw new TypeError(`${name} must be a function`);
}

async function runBatchCutout({
  layers,
  processLayer,
  saveOriginalMask,
  applyMask,
  restoreOriginalMask,
  signal,
  onProgress
} = {}) {
  if (!Array.isArray(layers) || layers.length === 0) throw new Error("请至少选择一个像素图层。");
  assertFunction(processLayer, "processLayer");
  assertFunction(saveOriginalMask, "saveOriginalMask");
  assertFunction(applyMask, "applyMask");
  assertFunction(restoreOriginalMask, "restoreOriginalMask");

  const result = { succeeded: [], failed: [], canceled: false, total: layers.length };
  const report = (event) => {
    if (typeof onProgress === "function") onProgress({ total: layers.length, ...event });
  };

  for (let index = 0; index < layers.length; index += 1) {
    if (signal && signal.aborted) {
      result.canceled = true;
      break;
    }
    const layer = layers[index];
    report({ phase: "processing", index, completed: index, layer });
    let snapshot = null;
    try {
      const processed = await processLayer(layer, { signal, index, total: layers.length });
      if (signal && signal.aborted) {
        result.canceled = true;
        break;
      }
      if (!processed || !(processed.alpha instanceof Uint8Array)) {
        throw new Error("批量算法没有返回有效蒙版。");
      }
      snapshot = await saveOriginalMask(layer);
      // Once the reversible snapshot exists, finish the current layer write.
      // Cancellation takes effect before the next layer.
      report({ phase: "applying", index, completed: index, layer });
      await applyMask(layer, processed.alpha);
      result.succeeded.push({ layer, diagnostics: processed.diagnostics || null });
    } catch (error) {
      if (isCanceled(signal, error)) {
        result.canceled = true;
        break;
      }
      if (snapshot) {
        try {
          await restoreOriginalMask(layer, snapshot);
        } catch (restoreError) {
          error.restoreError = restoreError;
        }
      }
      result.failed.push({ layer, error });
    }
    report({ phase: "completed", index, completed: index + 1, layer });
  }

  return result;
}

module.exports = { runBatchCutout };
