const { entrypoints } = require("uxp");
const photoshop = require("photoshop");
const { app, constants, imaging, core, action } = photoshop;
const { TrimapRaster, LABELS } = require("./core/trimap");
const { createEngine } = require("./core/engine");
const { autoTrimapAsync } = require("./core/autoTrimap");
const { createPhotoshopHost } = require("./host/photoshopHost");
const { createRequestId, DEFAULT_TIMEOUT_MS, VisionApiError } = require("./core/visionApi");
const { createFrameScheduler } = require("./ui/frameScheduler");
const { createListenerRegistry } = require("./ui/listenerRegistry");
const { createCanvasView } = require("./ui/canvasView");

const runtimeVisionConfig = typeof globalThis !== "undefined" ? globalThis.__PS_MASK_VISION_API__ : null;
let visionConfigError = null;
let visionClientConfig = null;
if (runtimeVisionConfig && typeof runtimeVisionConfig === "object") {
  visionClientConfig = runtimeVisionConfig;
}

let engine;
try {
  engine = createEngine({
    visionApi: visionClientConfig || undefined,
    requireFn: require
  });
} catch (error) {
  visionConfigError = error;
  engine = createEngine({ requireFn: require });
}

const host = createPhotoshopHost({ app, constants, imaging, core, action });
const VISION_STATES = Object.freeze({
  NOT_CONFIGURED: "not-configured",
  PENDING_CONSENT: "pending-consent",
  READY: "ready",
  PREPARING: "preparing",
  UPLOADING: "uploading",
  PROCESSING: "processing",
  PREVIEW: "preview",
  CANCELED: "canceled",
  RETRYABLE_ERROR: "retryable-error",
  NONRETRYABLE_ERROR: "nonretryable-error",
  APPLIED: "applied"
});
const VISION_STATE_LABELS = Object.freeze({
  [VISION_STATES.NOT_CONFIGURED]: "未配置",
  [VISION_STATES.PENDING_CONSENT]: "等待外发确认",
  [VISION_STATES.READY]: "已就绪",
  [VISION_STATES.PREPARING]: "准备请求",
  [VISION_STATES.UPLOADING]: "请求已发起",
  [VISION_STATES.PROCESSING]: "校验服务结果",
  [VISION_STATES.PREVIEW]: "结果可预览",
  [VISION_STATES.CANCELED]: "已取消",
  [VISION_STATES.RETRYABLE_ERROR]: "失败，可重试",
  [VISION_STATES.NONRETRYABLE_ERROR]: "失败，不可重试",
  [VISION_STATES.APPLIED]: "已应用"
});
const ALGORITHM_PHASE_LABELS = Object.freeze({
  distance: "分析标记",
  infer: "生成蒙版",
  blur: "处理边缘",
  edge: "调整轮廓",
  postprocess: "整理结果"
});
const state = {
  mounted: false,
  drawing: false,
  tool: "unknown",
  brushSize: 32,
  zoom: 1,
  zoomMode: "manual",
  viewMode: "mark",
  layer: null,
  source: null,
  trimap: null,
  alpha: null,
  lastPoint: null,
  engineMode: "algorithm",
  previewActive: false,
  requestId: null,
  requestController: null,
  previewPromise: null,
  previewCanceling: false,
  cancelRequested: false,
  busy: false,
  busyOperation: null,
  lastOperation: null,
  lastError: null,
  retryPendingConfirmation: false,
  resultEngine: null,
  optionsDirty: false,
  visionState: VISION_STATES.NOT_CONFIGURED,
  visionDataExported: false,
  operationToken: 0,
  panelGeneration: 0,
  listenerRegistry: null,
  paintScheduler: null,
  resizeObserver: null,
  sourceImageData: null,
  trimapRenderVersion: 0,
  trimapImageData: null
};

function element(id) {
  return document.getElementById(id);
}

const canvasView = createCanvasView({ element, state, labels: LABELS });
const {
  draw,
  drawLiveStroke,
  fitZoom: fitZoomToWindow,
  getPoint: getCanvasPoint,
  handleWheel: handlePreviewWheel,
  setZoom,
  updateZoomUI
} = canvasView;

function isCurrentPanel(generation) {
  return state.mounted && state.panelGeneration === generation;
}

function listen(target, type, handler, options) {
  if (state.listenerRegistry) state.listenerRegistry.add(target, type, handler, options);
}

function cleanupPanel() {
  state.mounted = false;
  state.panelGeneration += 1;
  state.operationToken += 1;
  state.drawing = false;
  state.lastPoint = null;
  if (state.paintScheduler) state.paintScheduler.cancel();
  state.paintScheduler = null;
  if (state.resizeObserver) state.resizeObserver.disconnect();
  state.resizeObserver = null;
  if (state.requestController) {
    state.requestController.abort();
    state.requestController = null;
  }
  const previewLayer = (state.previewActive || state.previewPromise) && state.layer ? state.layer : null;
  const previewPromise = state.previewPromise;
  if (previewLayer && typeof host.cancelMaskPreview === "function") {
    state.previewCanceling = true;
    const cancellation = Promise.resolve(previewPromise)
      .catch(() => {})
      .then(() => host.cancelMaskPreview(previewLayer))
      .then(() => {
        if (state.layer === previewLayer) state.previewActive = false;
      })
      .catch(() => {
        // Preserve the active flag so a remounted panel can retry restoration.
        if (state.layer === previewLayer) state.previewActive = true;
      })
      .finally(() => {
        if (state.previewPromise === cancellation) state.previewPromise = null;
        state.previewCanceling = false;
      });
    state.previewPromise = cancellation;
  } else {
    state.previewActive = false;
    state.previewPromise = null;
    state.previewCanceling = false;
  }
  if (state.listenerRegistry) state.listenerRegistry.clear();
  state.listenerRegistry = null;
}

function clearErrorActions() {
  const actions = element("error-actions");
  if (actions) actions.hidden = true;
  const retry = element("retry-compute");
  if (retry) {
    retry.hidden = false;
    retry.textContent = "重试";
  }
  state.lastError = null;
  state.retryPendingConfirmation = false;
}

function showErrorActions(error) {
  const actions = element("error-actions");
  if (!actions || !(error instanceof VisionApiError)) return;
  const shouldShow = error.category !== "canceled";
  actions.hidden = !shouldShow;
  const retry = element("retry-compute");
  if (retry) retry.hidden = false;
  state.lastError = error;
}

function setMessage(message, isError = false) {
  const node = element("message");
  node.textContent = message;
  node.style.color = isError ? "#ef746f" : "";
  if (!isError) clearErrorActions();
}

function setVisionState(nextState, dataExported = state.visionDataExported) {
  state.visionState = nextState;
  state.visionDataExported = Boolean(dataExported);
  const settings = document.querySelector(".engine-settings");
  if (settings) {
    settings.dataset.visionState = nextState;
    settings.dataset.dataExported = state.visionDataExported ? "true" : "false";
  }
  const runtimeStatus = element("vision-runtime-status");
  if (runtimeStatus) {
    runtimeStatus.textContent = `AI 状态：${VISION_STATE_LABELS[nextState] || nextState} · ${state.visionDataExported ? "已发起图层数据外发" : "未外发图层数据"}`;
  }
}

function clearLoadedLayerState() {
  state.layer = null;
  state.source = null;
  state.sourceImageData = null;
  state.trimap = null;
  state.trimapImageData = null;
  state.trimapRenderVersion += 1;
  state.alpha = null;
  state.resultEngine = null;
  state.previewActive = false;
  state.requestId = null;
  const status = element("layer-status");
  if (status) status.textContent = "未读取图层";
  setResultState("还没有生成蒙版");
  draw();
}

function setBusy(isBusy, operation = null) {
  state.busy = isBusy;
  state.busyOperation = isBusy ? operation : null;
  if (!isBusy) state.cancelRequested = false;
  element("load-layer").disabled = isBusy;
  element("auto-cutout").disabled = isBusy || !state.source;
  element("compute-mask").disabled = isBusy || !state.trimap;
  element("apply-mask").disabled = isBusy || !state.alpha || !state.previewActive || state.optionsDirty;
  const mode = element("engine-mode");
  if (mode) mode.disabled = isBusy;
  const consent = element("vision-consent");
  if (consent) consent.disabled = isBusy || !engine.availableModes().visionApi;
  ["view-mode", "brush-size", "edge-shift", "feather", "hard-threshold", "invert-mask", "zoom-range"]
    .map((id) => element(id))
    .filter(Boolean)
    .forEach((control) => { control.disabled = isBusy; });
  document.querySelectorAll(".tool-button").forEach((button) => { button.disabled = isBusy; });
  const reset = element("reset-mark");
  if (reset) {
    const cancelable = isBusy && ["compute", "auto"].includes(state.busyOperation);
    reset.disabled = (isBusy && !cancelable) || state.cancelRequested;
    reset.textContent = cancelable
      ? state.cancelRequested ? "正在取消" : "取消计算"
      : state.previewActive ? "取消并重置" : "重置标记";
  }
  const resetOptions = element("reset-options");
  if (resetOptions) resetOptions.disabled = isBusy;
  updateZoomUI();
}

function setResultState(text, isReady = false) {
  const node = document.querySelector("[data-result-state]");
  if (!node) return;
  node.textContent = text;
  node.classList.toggle("ready", isReady);
}

function getOptions() {
  const options = {
    edgeShift: Number(element("edge-shift").value),
    feather: Number(element("feather").value),
    hardThreshold: Number(element("hard-threshold").value),
    invert: element("invert-mask").checked
  };
  if (state.engineMode === "vision-api" && typeof visionClientConfig?.model === "string" && visionClientConfig.model.trim()) {
    options.model = visionClientConfig.model.trim();
  }
  return options;
}

function updateEngineUI() {
  const mode = element("engine-mode");
  const hint = element("engine-hint");
  const endpointStatus = element("vision-endpoint-status");
  const consent = element("vision-consent");
  const visionAvailable = engine.availableModes().visionApi;
  const visionOption = mode && mode.querySelector('option[value="vision-api"]');

  if (visionOption) visionOption.disabled = !visionAvailable;
  if (consent) consent.disabled = !visionAvailable || state.busy;
  if (mode) mode.value = state.engineMode;
  const autoLabel = element("auto-cutout") && element("auto-cutout").querySelector("strong");
  if (autoLabel) autoLabel.textContent = state.engineMode === "vision-api" ? "AI 一键抠图" : "本地一键抠图";
  if (hint) hint.textContent = state.engineMode === "vision-api" ? "AI 视觉模型 · 会发送图层数据" : "本地算法 · 不上传图片";
  let endpointHost = "";
  if (visionClientConfig && visionClientConfig.endpoint) {
    try {
      endpointHost = new URL(visionClientConfig.endpoint).host;
    } catch (error) {
      endpointHost = String(visionClientConfig.endpoint).replace(/^https?:\/\//i, "").split("/")[0];
    }
  }
  if (endpointStatus) {
    const configuredTimeout = Number(visionClientConfig?.timeoutMs ?? visionClientConfig?.timeout);
    const timeoutMs = Number.isFinite(configuredTimeout) && configuredTimeout > 0 ? configuredTimeout : DEFAULT_TIMEOUT_MS;
    const model = typeof visionClientConfig?.model === "string" && visionClientConfig.model.trim()
      ? `；模型 ${visionClientConfig.model.trim()}`
      : "";
    endpointStatus.textContent = visionConfigError
      ? "AI 配置无效，已保持本地算法。"
      : visionAvailable
        ? `AI 服务已配置${endpointHost ? `：${endpointHost}` : ""}${model}；请求超时 ${Math.round(timeoutMs / 1000)} 秒；图层数据会外发，留存策略未知，请确认服务商条款。`
        : "未配置 AI 视觉模型服务，当前仅使用本地算法。";
    endpointStatus.style.color = visionConfigError ? "#ef746f" : "";
  }
  const status = element("engine-status");
  if (status) status.textContent = engine.describe();
  const modeLabel = document.querySelector(".engine-mode");
  if (modeLabel) modeLabel.textContent = state.engineMode === "vision-api" ? "AI 视觉模型" : "本地算法";
  if (!visionAvailable) setVisionState(VISION_STATES.NOT_CONFIGURED, false);
  else if ((!consent || !consent.checked) && !state.visionDataExported) {
    setVisionState(VISION_STATES.PENDING_CONSENT, false);
  }
  else if ([VISION_STATES.NOT_CONFIGURED, VISION_STATES.PENDING_CONSENT].includes(state.visionState)) {
    setVisionState(VISION_STATES.READY, false);
  }
}

function resetVisionCycleForLayer() {
  if (!engine.availableModes().visionApi) {
    setVisionState(VISION_STATES.NOT_CONFIGURED, false);
    return;
  }
  const consent = element("vision-consent");
  setVisionState(consent && consent.checked ? VISION_STATES.READY : VISION_STATES.PENDING_CONSENT, false);
}

function selectEngineMode(nextMode) {
  if (nextMode === "vision-api") {
    const consent = element("vision-consent");
    if (!engine.availableModes().visionApi) {
      setVisionState(VISION_STATES.NOT_CONFIGURED, false);
      setMessage("AI 视觉模型尚未配置，已保持本地算法。", true);
      updateEngineUI();
      return;
    }
    if (!consent || !consent.checked) {
      setVisionState(VISION_STATES.PENDING_CONSENT, false);
      setMessage("请先确认图层数据会发送到已配置的 AI 服务。", true);
      updateEngineUI();
      return;
    }
  }

  try {
    engine.setMode(nextMode);
    state.engineMode = nextMode;
    if (nextMode === "vision-api") setVisionState(VISION_STATES.READY, false);
    setMessage(nextMode === "vision-api" ? "已切换到 AI 视觉模型，下一次计算会发送图层数据。" : "已切换到本地算法，不会上传图片。");
    updateEngineUI();
  } catch (error) {
    state.engineMode = "algorithm";
    setMessage(error.message || "切换计算引擎失败。", true);
    updateEngineUI();
  }
}

function getLabel() {
  if (state.tool === "keep") return LABELS.KEEP;
  if (state.tool === "cut") return LABELS.CUT;
  return LABELS.UNKNOWN;
}

async function loadLayer() {
  if (state.busy) return;
  const generation = state.panelGeneration;
  setBusy(true, "load");
  try {
    if (state.previewActive && state.layer) await cancelCurrentPreview();
    if (!isCurrentPanel(generation)) return;
    const layer = host.getActivePixelLayer();
    const source = await host.readLayerPixels(layer);
    if (!isCurrentPanel(generation)) return;
    state.layer = { ...layer, bounds: source.bounds };
    state.source = source;
    state.sourceImageData = null;
    state.trimap = new TrimapRaster(source.width, source.height);
    state.trimapRenderVersion += 1;
    state.trimapImageData = null;
    state.alpha = null;
    state.optionsDirty = false;
    state.zoom = 1;
    state.zoomMode = "manual";
    state.requestId = null;
    resetVisionCycleForLayer();
    element("layer-status").textContent = `${layer.name} · ${source.width} × ${source.height}`;
    setMessage(`已读取图层。当前引擎：${engine.describe()}`);
    setResultState("还没有生成蒙版");
    draw();
  } catch (error) {
    if (!isCurrentPanel(generation)) return;
    // If no temporary preview remains to protect, discard the old source so
    // a failed reload cannot leave controls operating on stale pixels.
    if (!state.previewActive) clearLoadedLayerState();
    setMessage(error.message || "读取图层失败。", true);
  } finally {
    if (isCurrentPanel(generation)) setBusy(false);
  }
}

async function previewAlpha(alpha) {
  if (!state.layer || !(alpha instanceof Uint8Array)) return false;
  if (typeof host.previewLayerMask !== "function") return false;
  const generation = state.panelGeneration;
  const layer = state.layer;
  await host.previewLayerMask(layer, alpha);
  if (!isCurrentPanel(generation) || state.layer !== layer) return false;
  state.previewActive = true;
  return true;
}

async function runPreview(alpha) {
  const previewPromise = previewAlpha(alpha);
  state.previewPromise = previewPromise;
  try {
    return await previewPromise;
  } finally {
    if (state.previewPromise === previewPromise) state.previewPromise = null;
  }
}

async function cancelCurrentPreview() {
  if (!state.previewActive) return false;
  if (!state.layer || typeof host.cancelMaskPreview !== "function") {
    throw new Error("无法安全取消 Photoshop 临时蒙版预览。");
  }
  const generation = state.panelGeneration;
  const layer = state.layer;
  const cancelPromise = host.cancelMaskPreview(layer);
  state.previewPromise = cancelPromise;
  try {
    await cancelPromise;
    if (isCurrentPanel(generation) && state.layer === layer) state.previewActive = false;
    return true;
  } finally {
    if (state.previewPromise === cancelPromise) state.previewPromise = null;
  }
}

function describeEngineError(error) {
  if (error && (error.name === "AbortError" || error.code === "canceled")) {
    return "计算已取消；当前 Trimap 和参数已保留。";
  }
  if (error instanceof VisionApiError) {
    if (error.category === "canceled") return "AI 视觉模型请求已取消。";
    if (error.category === "timeout") return "AI 视觉模型请求超时，可重试或切换到本地算法。";
    if (error.category === "authentication") return "AI 视觉模型认证失败，请检查运行时配置。";
    if (error.category === "permission") return "AI 视觉模型服务拒绝了当前权限，请检查项目授权或模型访问范围。";
    if (error.category === "rate-limit") return "AI 视觉模型服务限流，请稍后重试。";
    if (error.category === "response-format") return "AI 视觉模型返回了无法识别的蒙版。";
    if (error.category === "server") return "AI 视觉模型服务暂时不可用，可重试或切换到本地算法。";
    if (error.category === "configuration") return "AI 视觉模型配置无效，已保持本地算法。";
    if (error.accepted) return "AI 服务可能已接受本次请求，但返回结果无法识别；请先确认服务端记录，再决定是否重试。";
    return "AI 视觉模型请求失败，可重试或切换到本地算法。";
  }
  return error && error.message ? error.message : "蒙版计算失败。";
}

function describeDiagnostics(diagnostics) {
  if (!diagnostics || typeof diagnostics !== "object") return "";
  const parts = [];
  if (diagnostics.model) parts.push(`模型 ${diagnostics.model}`);
  if (diagnostics.modelVersion) parts.push(`版本 ${diagnostics.modelVersion}`);
  if (Number.isFinite(Number(diagnostics.confidence))) {
    parts.push(`置信度 ${Math.round(Number(diagnostics.confidence))}%`);
  }
  if (Number.isFinite(Number(diagnostics.processingMs))) {
    parts.push(`${Math.round(Number(diagnostics.processingMs))} ms`);
  }
  if (diagnostics.traceId) parts.push(`追踪 ${diagnostics.traceId}`);
  const warnings = Array.isArray(diagnostics.warnings) ? [...diagnostics.warnings] : [];
  if (diagnostics.warning) warnings.push(diagnostics.warning);
  if (warnings.length) parts.push(`提示：${warnings.join("；")}`);
  return parts.join(" · ");
}

function startVisionProgress(prepareMessage) {
  setVisionState(VISION_STATES.PREPARING, false);
  setMessage(prepareMessage);
}

function reportVisionStatus(token, status) {
  if (!status || token !== state.operationToken || !state.busy || state.cancelRequested) return;
  if (status.state === "uploading") {
    setVisionState(VISION_STATES.UPLOADING, true);
    setMessage("AI 请求已发起，正在等待服务响应……");
  } else if (status.state === "processing") {
    setVisionState(VISION_STATES.PROCESSING, true);
    setMessage("已收到 AI 服务响应，正在校验结果……");
  }
}

function beginRequest() {
  const token = state.operationToken + 1;
  state.operationToken = token;
  state.cancelRequested = false;
  state.requestController = typeof AbortController === "function" ? new AbortController() : null;
  return { controller: state.requestController, token };
}

function reportAlgorithmProgress(token, progress) {
  if (!progress || !state.busy || state.cancelRequested || state.operationToken !== token) return;
  const total = Number(progress.total);
  const completed = Number(progress.completed);
  if (!Number.isFinite(total) || total < 1 || !Number.isFinite(completed)) return;
  const percent = Math.max(0, Math.min(100, Math.round((completed / total) * 100)));
  const phaseKey = String(progress.phase || "");
  const phase = phaseKey.startsWith("auto-")
    ? "分析前景"
    : ALGORITHM_PHASE_LABELS[phaseKey] || "整理结果";
  setMessage(`正在${phase}……${percent}%`);
}

function endRequest(request) {
  if (state.requestController === request.controller) state.requestController = null;
}

function requestWasCanceled(request) {
  return request.token !== state.operationToken
    || state.cancelRequested
    || Boolean(request.controller && request.controller.signal.aborted);
}

function recordVisionFailure(error) {
  const canceled = error && (error.category === "canceled" || error.code === "canceled" || error.name === "AbortError");
  setVisionState(canceled
    ? VISION_STATES.CANCELED
    : error && error.retryable
      ? VISION_STATES.RETRYABLE_ERROR
      : VISION_STATES.NONRETRYABLE_ERROR);
}

async function runMaskOperation(operation) {
  const isAuto = operation === "auto";
  if (!state.source || (!isAuto && !state.trimap) || state.busy) return;
  setBusy(true, operation);
  state.lastOperation = operation;
  const request = beginRequest();
  const operationEngine = state.engineMode;
  let generated = null;
  try {
    state.requestId = createRequestId();
    if (operationEngine === "vision-api") {
      startVisionProgress(isAuto ? "准备 Trimap 并发送图层数据……" : "准备发送图层数据……");
    } else {
      setMessage(isAuto ? "正在根据边界和透明通道自动推测前景……" : "正在计算蒙版，请稍候……");
    }
    if (state.previewActive) await cancelCurrentPreview();
    if (requestWasCanceled(request)) return;

    if (isAuto) {
      generated = await autoTrimapAsync({
        pixels: state.source.pixels,
        width: state.source.width,
        height: state.source.height,
        components: state.source.components,
        ...(request.controller ? { signal: request.controller.signal } : {}),
        onProgress: (progress) => reportAlgorithmProgress(request.token, progress)
      });
      if (requestWasCanceled(request)) return;
      state.trimap = generated.trimap;
      state.trimapRenderVersion += 1;
      state.trimapImageData = null;
      state.alpha = null;
    }

    const response = await engine.compute({
      pixels: state.source.pixels,
      width: state.source.width,
      height: state.source.height,
      components: state.source.components,
      trimap: state.trimap.data,
      requestId: state.requestId,
      ...(request.controller ? { signal: request.controller.signal } : {}),
      onProgress: (progress) => reportAlgorithmProgress(request.token, progress),
      onStatus: (status) => reportVisionStatus(request.token, status),
      options: getOptions()
    });
    if (requestWasCanceled(request)) {
      if (state.previewActive) await cancelCurrentPreview();
      return;
    }
    state.alpha = response.alpha;
    state.resultEngine = operationEngine;
    state.optionsDirty = false;

    let previewed = false;
    try {
      previewed = await runPreview(state.alpha);
    } catch (previewError) {
      if (requestWasCanceled(request)) return;
      state.previewActive = false;
      if (operationEngine === "vision-api") setVisionState(VISION_STATES.NONRETRYABLE_ERROR, true);
      setResultState("预览失败，不能应用蒙版");
      setMessage(`蒙版已计算，但无法在 Photoshop 画布预览：${previewError.message || "宿主接口不可用。"}`, true);
      return;
    }
    if (requestWasCanceled(request)) {
      if (state.previewActive) await cancelCurrentPreview();
      return;
    }

    state.viewMode = "mask";
    element("view-mode").value = "mask";
    setResultState(previewed ? "正在预览临时蒙版" : "预览失败，不能应用蒙版", previewed);
    draw();
    if (!previewed) {
      if (operationEngine === "vision-api") setVisionState(VISION_STATES.NONRETRYABLE_ERROR, true);
      setMessage("蒙版已计算，但 Photoshop 画布预览不可用，因此不能应用。", true);
      return;
    }

    if (operationEngine === "vision-api") setVisionState(VISION_STATES.PREVIEW, true);
    if (!isAuto) {
      const diagnostics = describeDiagnostics(response.diagnostics);
      setMessage(`蒙版已生成，结果正在 Photoshop 画布中预览。${diagnostics ? ` ${diagnostics}` : ""}`);
      return;
    }
    const diagnostics = operationEngine === "vision-api"
      ? describeDiagnostics(response.diagnostics)
      : `算法置信度约 ${Math.round(generated.diagnostics.confidence * 100)}%`;
    const lowConfidence = operationEngine === "algorithm" && generated.diagnostics.confidence < 0.55;
    const warning = lowConfidence ? "建议用保留/删除笔刷修正后重新计算。" : "请检查 Photoshop 画布中的蒙版后再应用。";
    setMessage(`一键抠图完成，${diagnostics || "结果已生成"}。${warning}`, lowConfidence);
  } catch (error) {
    if (request.token !== state.operationToken) return;
    if (operationEngine === "vision-api") recordVisionFailure(error);
    setMessage(describeEngineError(error), true);
    showErrorActions(error);
  } finally {
    endRequest(request);
    if (request.token === state.operationToken) {
      setBusy(false);
      updateEngineUI();
    }
  }
}

function computeMask() {
  return runMaskOperation("compute");
}

function autoCutout() {
  return runMaskOperation("auto");
}

async function applyMask() {
  if (!state.layer || !state.alpha || !state.previewActive || state.optionsDirty || state.busy) {
    if (state.optionsDirty) setMessage("边缘参数已修改，请重新计算后再应用蒙版。", true);
    if (state.alpha && !state.previewActive) setMessage("请先在 Photoshop 画布中成功预览蒙版，再应用。", true);
    return;
  }
  setBusy(true, "apply");
  const generation = state.panelGeneration;
  const layer = state.layer;
  try {
    if (typeof host.applyLayerMask === "function") await host.applyLayerMask(layer, state.alpha);
    else await host.putLayerMask(layer, state.alpha);
    if (!isCurrentPanel(generation)) return;
    state.previewActive = false;
    if (state.resultEngine === "vision-api") setVisionState(VISION_STATES.APPLIED, true);
    setResultState("蒙版已应用", true);
    setMessage("图层蒙版已应用，可以在 Photoshop 中继续编辑。", false);
  } catch (error) {
    if (!isCurrentPanel(generation)) return;
    setMessage(error.message || "应用蒙版失败。", true);
  } finally {
    if (isCurrentPanel(generation)) setBusy(false);
  }
}

async function resetMark() {
  if (!state.trimap || (state.busy && !["compute", "auto"].includes(state.busyOperation))) return;
  const generation = state.panelGeneration;
  state.operationToken += 1;
  if (state.requestController) {
    state.requestController.abort();
    state.requestController = null;
  }
  setBusy(true, "reset");
  try {
    if (state.previewPromise) await state.previewPromise;
    if (state.previewActive) await cancelCurrentPreview();
    if (!isCurrentPanel(generation)) return;
  } catch (error) {
    if (!isCurrentPanel(generation)) return;
    setMessage(error.message || "取消蒙版预览失败。", true);
    setBusy(false);
    return;
  }
  state.trimap.clear();
  state.trimapRenderVersion += 1;
  state.trimapImageData = null;
  state.alpha = null;
  state.optionsDirty = false;
  if (state.resultEngine === "vision-api") setVisionState(VISION_STATES.CANCELED, state.visionDataExported);
  state.resultEngine = null;
  state.requestId = null;
  element("view-mode").value = "mark";
  state.viewMode = "mark";
  setResultState("还没有生成蒙版");
  setMessage("预览已取消，标记和计算结果已重置。");
  draw();
  if (isCurrentPanel(generation)) setBusy(false);
}

function cancelComputation() {
  if (!state.busy || state.cancelRequested || !["compute", "auto"].includes(state.busyOperation)) return;
  state.cancelRequested = true;
  if (state.requestController) state.requestController.abort();
  if (state.engineMode === "vision-api") {
    setVisionState(VISION_STATES.CANCELED, state.visionDataExported);
  }
  setBusy(true, state.busyOperation);
  setMessage("正在取消计算；完成当前 Photoshop 操作后会保留 Trimap 和参数。", false);
}

function handleResetAction() {
  if (state.busy) cancelComputation();
  else void resetMark();
}

function markOptionsDirty() {
  if (state.busy) return;
  state.optionsDirty = Boolean(state.alpha || state.previewActive);
  if (!state.optionsDirty) return;
  const apply = element("apply-mask");
  if (apply) apply.disabled = true;
  setResultState("边缘参数已修改，等待重新计算");
  setMessage("边缘参数已修改；点击一键抠图或根据标记重新计算后生效。", false);
}

function resetOptions() {
  if (state.busy) return;
  element("edge-shift").value = "0";
  element("feather").value = "0";
  element("hard-threshold").value = "0";
  element("invert-mask").checked = false;
  markOptionsDirty();
  if (!state.optionsDirty) setMessage("边缘参数已恢复默认值。", false);
}

async function cancelPreviewForEditing() {
  if (!state.previewActive || !state.layer || typeof host.cancelMaskPreview !== "function" || state.previewCanceling) return false;
  const generation = state.panelGeneration;
  state.previewCanceling = true;
  try {
    await cancelCurrentPreview();
    if (!isCurrentPanel(generation)) return false;
    setResultState("标记已修改，等待重新计算");
    return true;
  } catch (error) {
    if (!isCurrentPanel(generation)) return false;
    setMessage(error.message || "取消旧蒙版预览失败。", true);
    return false;
  } finally {
    if (isCurrentPanel(generation)) state.previewCanceling = false;
  }
}

function beginPaint(event) {
  if (!state.trimap || state.busy || state.previewCanceling) return;
  if (state.previewActive) {
    void cancelPreviewForEditing();
    return;
  }
  const canvas = element("preview-canvas");
  state.drawing = true;
  state.lastPoint = getCanvasPoint(event, canvas);
  state.trimap.paintCircle(state.lastPoint.x, state.lastPoint.y, state.brushSize, getLabel());
  state.alpha = null;
  state.trimapRenderVersion += 1;
  draw();
  if (typeof canvas.setPointerCapture === "function") canvas.setPointerCapture(event.pointerId);
}

function continuePaint(event) {
  if (state.busy || !state.drawing || !state.trimap) return;
  const canvas = element("preview-canvas");
  const point = getCanvasPoint(event, canvas);
  const previousPoint = state.lastPoint;
  state.trimap.paintLine(previousPoint.x, previousPoint.y, point.x, point.y, state.brushSize, getLabel());
  state.lastPoint = point;
  state.alpha = null;
  state.trimapRenderVersion += 1;
  drawLiveStroke(previousPoint, point);
}

function endPaint() {
  state.drawing = false;
  state.lastPoint = null;
  if (state.paintScheduler) state.paintScheduler.schedule();
}

function retryLastOperation() {
  if (state.busy) return;
  const retry = element("retry-compute");
  if (!state.retryPendingConfirmation) {
    state.retryPendingConfirmation = true;
    if (retry) retry.textContent = "确认重试（可能计费）";
    const acceptedWarning = state.lastError && state.lastError.accepted
      ? "服务可能已接受上一次请求。"
      : "重试会提交一个新的 AI 请求。";
    setMessage(`${acceptedWarning} 再次点击确认重试，可能产生重复费用。`, true);
    return;
  }
  clearErrorActions();
  if (state.lastOperation === "auto") void autoCutout();
  else if (state.lastOperation === "compute") void computeMask();
}

function switchToLocalEngine() {
  clearErrorActions();
  const mode = element("engine-mode");
  if (mode) mode.value = "algorithm";
  selectEngineMode("algorithm");
}

function mount() {
  if (state.mounted || !element("preview-canvas")) return;
  state.mounted = true;
  state.panelGeneration += 1;
  state.sourceImageData = null;
  state.trimapImageData = null;
  state.listenerRegistry = createListenerRegistry();
  state.paintScheduler = createFrameScheduler(() => {
    if (state.mounted) draw();
  });
  if (typeof ResizeObserver === "function") {
    state.resizeObserver = new ResizeObserver(() => {
      if (state.mounted && state.zoomMode === "fit") fitZoomToWindow();
    });
    const frame = element("canvas-frame");
    if (frame) state.resizeObserver.observe(frame);
  }
  element("engine-status").textContent = engine.describe();
  updateEngineUI();
  listen(element("load-layer"), "click", loadLayer);
  listen(element("auto-cutout"), "click", autoCutout);
  listen(element("compute-mask"), "click", computeMask);
  listen(element("apply-mask"), "click", applyMask);
  listen(element("reset-mark"), "click", handleResetAction);
  listen(element("reset-options"), "click", resetOptions);
  listen(element("view-mode"), "change", (event) => {
    if (state.busy) return;
    state.viewMode = event.target.value;
    draw();
  });
  listen(element("brush-size"), "input", (event) => {
    if (state.busy) return;
    state.brushSize = Number(event.target.value);
    element("brush-size-value").textContent = String(state.brushSize);
  });
  ["edge-shift", "feather", "hard-threshold"].forEach((id) => {
    listen(element(id), "input", markOptionsDirty);
  });
  listen(element("invert-mask"), "change", markOptionsDirty);
  listen(element("zoom-range"), "input", (event) => {
    setZoom(Number(event.target.value) / 100);
  });
  listen(element("zoom-out"), "click", () => setZoom(state.zoom * 0.8));
  listen(element("zoom-in"), "click", () => setZoom(state.zoom * 1.25));
  listen(element("zoom-fit"), "click", fitZoomToWindow);
  const engineMode = element("engine-mode");
  if (engineMode) listen(engineMode, "change", (event) => selectEngineMode(event.target.value));
  const consent = element("vision-consent");
  if (consent) listen(consent, "change", () => {
    if (consent.checked && engineMode && engineMode.value === "vision-api") selectEngineMode("vision-api");
    if (!consent.checked && state.engineMode === "vision-api") {
      if (engineMode) engineMode.value = "algorithm";
      selectEngineMode("algorithm");
    }
    updateEngineUI();
  });
  const retry = element("retry-compute");
  if (retry) listen(retry, "click", retryLastOperation);
  const useLocal = element("use-local-engine");
  if (useLocal) listen(useLocal, "click", switchToLocalEngine);
  document.querySelectorAll(".tool-button").forEach((button) => {
    listen(button, "click", () => {
      if (state.busy) return;
      state.tool = button.dataset.tool;
      document.querySelectorAll(".tool-button").forEach((item) => item.classList.toggle("active", item === button));
    });
  });
  listen(element("preview-canvas"), "pointerdown", beginPaint);
  listen(element("preview-canvas"), "pointermove", continuePaint);
  listen(element("preview-canvas"), "pointerup", endPaint);
  listen(element("preview-canvas"), "pointerleave", endPaint);
  listen(element("preview-canvas"), "wheel", handlePreviewWheel, { passive: false });
  draw();
  setBusy(false);
}

entrypoints.setup({
  panels: {
    maskPanel: {
      create() {
        mount();
      },
      destroy() {
        cleanupPanel();
      }
    }
  }
});

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", mount);
} else {
  mount();
}
