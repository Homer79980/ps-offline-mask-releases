const { LABELS } = require("./trimap");
const { runStepsAsync, runStepsSync, throwIfAborted } = require("./stepRunner");

const DIRECTIONS = [
  [-1, 0],
  [1, 0],
  [0, -1],
  [0, 1]
];
const YIELD_INTERVAL = 4096;

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function* distanceSteps(width, height, data, label) {
  const size = width * height;
  const distances = new Int32Array(size);
  distances.fill(-1);
  const queue = new Int32Array(size);
  let head = 0;
  let tail = 0;

  for (let index = 0; index < size; index += 1) {
    if (data[index] === label) {
      distances[index] = 0;
      queue[tail] = index;
      tail += 1;
    }
    if ((index + 1) % YIELD_INTERVAL === 0) {
      yield { phase: "distance", completed: index + 1, total: size };
    }
  }

  while (head < tail) {
    const index = queue[head];
    head += 1;
    const x = index % width;
    const y = Math.floor(index / width);
    const nextDistance = distances[index] + 1;
    for (const [dx, dy] of DIRECTIONS) {
      const nx = x + dx;
      const ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
      const nextIndex = ny * width + nx;
      if (distances[nextIndex] === -1) {
        distances[nextIndex] = nextDistance;
        queue[tail] = nextIndex;
        tail += 1;
      }
    }
    if (head % YIELD_INTERVAL === 0) {
      yield { phase: "distance", completed: head, total: size };
    }
  }
  return distances;
}

function* blurSteps(input, width, height, radius) {
  if (radius < 1) return new Uint8Array(input);
  const output = new Uint8Array(input.length);
  let completed = 0;
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      let sum = 0;
      let count = 0;
      for (let oy = -radius; oy <= radius; oy += 1) {
        const py = y + oy;
        if (py < 0 || py >= height) continue;
        for (let ox = -radius; ox <= radius; ox += 1) {
          const px = x + ox;
          if (px < 0 || px >= width) continue;
          sum += input[py * width + px];
          count += 1;
        }
      }
      output[y * width + x] = Math.round(sum / Math.max(1, count));
      completed += 1;
      if (completed % YIELD_INTERVAL === 0) {
        yield { phase: "blur", completed, total: width * height };
      }
    }
  }
  return output;
}

function pushExtremum(deque, values, head, tail, index, useMaximum) {
  while (tail > head) {
    const previous = deque[tail - 1];
    if (useMaximum ? values[previous] > values[index] : values[previous] < values[index]) break;
    tail -= 1;
  }
  deque[tail] = index;
  return tail + 1;
}

function* morphologySteps(input, width, height, radius, useMaximum) {
  if (radius < 1) return new Uint8Array(input);
  const horizontal = new Uint8Array(input.length);
  const output = new Uint8Array(input.length);
  const rowDeque = new Int32Array(width);
  const columnDeque = new Int32Array(height);
  let completed = 0;

  for (let y = 0; y < height; y += 1) {
    const rowStart = y * width;
    let head = 0;
    let tail = 0;
    let next = 0;
    for (let x = 0; x < width; x += 1) {
      const right = Math.min(width - 1, x + radius);
      while (next <= right) {
        tail = pushExtremum(rowDeque, input, head, tail, rowStart + next, useMaximum);
        next += 1;
      }
      const left = rowStart + Math.max(0, x - radius);
      while (head < tail && rowDeque[head] < left) head += 1;
      horizontal[rowStart + x] = input[rowDeque[head]];
      completed += 1;
      if (completed % YIELD_INTERVAL === 0) yield { phase: "edge", completed, total: input.length * 2 };
    }
  }

  for (let x = 0; x < width; x += 1) {
    let head = 0;
    let tail = 0;
    let next = 0;
    for (let y = 0; y < height; y += 1) {
      const bottom = Math.min(height - 1, y + radius);
      while (next <= bottom) {
        const sourceIndex = next * width + x;
        while (tail > head) {
          const previousIndex = columnDeque[tail - 1] * width + x;
          if (useMaximum ? horizontal[previousIndex] > horizontal[sourceIndex] : horizontal[previousIndex] < horizontal[sourceIndex]) break;
          tail -= 1;
        }
        columnDeque[tail] = next;
        tail += 1;
        next += 1;
      }
      const top = Math.max(0, y - radius);
      while (head < tail && columnDeque[head] < top) head += 1;
      output[y * width + x] = horizontal[columnDeque[head] * width + x];
      completed += 1;
      if (completed % YIELD_INTERVAL === 0) yield { phase: "edge", completed, total: input.length * 2 };
    }
  }
  return output;
}

function* rawAlphaSteps(width, height, trimap, keepDistance, cutDistance) {
  const size = width * height;
  const alpha = new Uint8Array(size);
  for (let index = 0; index < size; index += 1) {
    const value = trimap[index];
    let result;
    if (value === LABELS.KEEP) result = 255;
    else if (value === LABELS.CUT) result = 0;
    else {
      const keep = keepDistance[index];
      const cut = cutDistance[index];
      if (keep < 0 && cut < 0) result = 128;
      else if (keep < 0) result = 0;
      else if (cut < 0) result = 255;
      else result = Math.round((cut / Math.max(1, keep + cut)) * 255);
    }
    alpha[index] = result;
    if ((index + 1) % YIELD_INTERVAL === 0) {
      yield { phase: "infer", completed: index + 1, total: size };
    }
  }
  return alpha;
}

function* postProcessingSteps(alpha, width, height, options = {}) {
  let result = new Uint8Array(alpha);
  const edgeShift = clamp(Number(options.edgeShift) || 0, -100, 100);
  const edgeRadius = Math.round(Math.abs(edgeShift) / 10);
  result = yield* morphologySteps(result, width, height, edgeRadius, edgeShift > 0);

  const feather = clamp(Number(options.feather) || 0, 0, 100);
  result = yield* blurSteps(result, width, height, Math.min(4, Math.round(feather / 25)));
  const threshold = clamp(Number(options.hardThreshold) || 0, 0, 255);
  for (let index = 0; index < result.length; index += 1) {
    if (threshold > 0) result[index] = result[index] >= threshold ? 255 : 0;
    if (options.invert) result[index] = 255 - result[index];
    if ((index + 1) % YIELD_INTERVAL === 0) {
      yield { phase: "postprocess", completed: index + 1, total: result.length };
    }
  }
  return result;
}

function assertTrimap(width, height, trimap) {
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1 || !trimap || trimap.length !== width * height) {
    throw new RangeError("Alpha input dimensions are invalid");
  }
  for (let index = 0; index < trimap.length; index += 1) {
    if (trimap[index] !== LABELS.UNKNOWN && trimap[index] !== LABELS.KEEP && trimap[index] !== LABELS.CUT) {
      throw new RangeError("Trimap labels must be unknown (0), keep (1), or cut (2)");
    }
  }
}

function assertAlpha(alpha, width, height) {
  if (!(alpha instanceof Uint8Array) || !Number.isInteger(width) || !Number.isInteger(height) || alpha.length !== width * height) {
    throw new RangeError("Alpha output dimensions are invalid");
  }
}

function distanceFromLabel(width, height, data, label) {
  return runStepsSync(distanceSteps(width, height, data, label));
}

function applyAlphaPostProcessing(alpha, width, height, options = {}) {
  assertAlpha(alpha, width, height);
  return runStepsSync(postProcessingSteps(alpha, width, height, options));
}

async function applyAlphaPostProcessingAsync(alpha, width, height, options = {}, signal, onProgress) {
  assertAlpha(alpha, width, height);
  return runStepsAsync(postProcessingSteps(alpha, width, height, options), signal, onProgress);
}

function computeFallbackAlpha({ width, height, trimap, options = {} }) {
  assertTrimap(width, height, trimap);
  const keepDistance = runStepsSync(distanceSteps(width, height, trimap, LABELS.KEEP));
  const cutDistance = runStepsSync(distanceSteps(width, height, trimap, LABELS.CUT));
  const rawAlpha = runStepsSync(rawAlphaSteps(width, height, trimap, keepDistance, cutDistance));
  return applyAlphaPostProcessing(rawAlpha, width, height, options);
}

async function computeFallbackAlphaAsync({ width, height, trimap, options = {}, signal, onProgress }) {
  assertTrimap(width, height, trimap);
  const keepDistance = await runStepsAsync(distanceSteps(width, height, trimap, LABELS.KEEP), signal, onProgress);
  const cutDistance = await runStepsAsync(distanceSteps(width, height, trimap, LABELS.CUT), signal, onProgress);
  const rawAlpha = await runStepsAsync(rawAlphaSteps(width, height, trimap, keepDistance, cutDistance), signal, onProgress);
  return applyAlphaPostProcessingAsync(rawAlpha, width, height, options, signal, onProgress);
}

module.exports = {
  applyAlphaPostProcessing,
  applyAlphaPostProcessingAsync,
  computeFallbackAlpha,
  computeFallbackAlphaAsync,
  distanceFromLabel,
  throwIfAborted
};
