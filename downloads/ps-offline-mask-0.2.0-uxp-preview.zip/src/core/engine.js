const { applyAlphaPostProcessingAsync, computeFallbackAlphaAsync } = require("./alpha");
const { createVisionApiClient, ERROR_CATEGORIES, VisionApiError } = require("./visionApi");

function loadNativeAddon(requireFn = require) {
  try {
    return requireFn("ps-mask-engine.uxpaddon");
  } catch (error) {
    return null;
  }
}

function validateResponse(response, width, height) {
  if (!response || !(response.alpha instanceof Uint8Array) || response.alpha.length !== width * height) {
    throw new Error("Native mask engine returned an invalid alpha buffer");
  }
  return response;
}

function inferenceRequest(request) {
  return {
    ...request,
    options: {
      ...(request && request.options && typeof request.options === "object" ? request.options : {}),
      postProcessLocally: true
    }
  };
}

function createEngine(options = {}) {
  const nativeAddon = options.nativeAddon || loadNativeAddon(options.requireFn);
  const algorithmEngine = nativeAddon && typeof nativeAddon.compute === "function"
    ? {
      kind: "native",
      describe() {
        return "原生算法引擎";
      },
      async compute(request) {
        const response = await nativeAddon.compute(inferenceRequest(request));
        const validated = validateResponse(response, request.width, request.height);
        return {
          ...validated,
          alpha: await applyAlphaPostProcessingAsync(
            validated.alpha,
            request.width,
            request.height,
            request.options,
            request.signal,
            request.onProgress
          )
        };
      }
    }
    : {
      kind: "fallback",
      describe() {
        return "降级预览引擎";
      },
      async compute(request) {
        return {
          alpha: await computeFallbackAlphaAsync(request),
          diagnostics: {
            engine: "fallback",
            warning: "Native algorithm addon is not installed; this result is only for integration testing."
          }
        };
      }
    };
  let visionClient = options.visionClient || null;
  // Accept either a ready client or runtime-only API configuration. No endpoint
  // is inferred here, which keeps the algorithm mode strictly offline by default.
  if (!visionClient && options.visionApi && typeof options.visionApi === "object") {
    visionClient = createVisionApiClient(options.visionApi);
  }
  const requestedMode = options.mode || "algorithm";
  if (requestedMode !== "algorithm" && requestedMode !== "vision-api") {
    throw new Error(`Unknown mask engine mode: ${requestedMode}`);
  }
  if (requestedMode === "vision-api" && !visionClient) {
    throw new VisionApiError("Vision API is not configured", {
      code: ERROR_CATEGORIES.CONFIGURATION,
      category: ERROR_CATEGORIES.CONFIGURATION,
      retryable: false
    });
  }
  let mode = requestedMode;

  return {
    get kind() {
      return mode === "vision-api" ? "vision-api" : algorithmEngine.kind;
    },
    describe() {
      return mode === "vision-api" ? visionClient.describe() : algorithmEngine.describe();
    },
    availableModes() {
      return {
        algorithm: true,
        visionApi: Boolean(visionClient)
      };
    },
    setMode(nextMode) {
      if (nextMode !== "algorithm" && nextMode !== "vision-api") {
        throw new Error(`Unknown mask engine mode: ${nextMode}`);
      }
      if (nextMode === "vision-api" && !visionClient) {
        throw new VisionApiError("Vision API is not configured", {
          code: ERROR_CATEGORIES.CONFIGURATION,
          category: ERROR_CATEGORIES.CONFIGURATION,
          retryable: false
        });
      }
      mode = nextMode;
    },
    async compute(request) {
      if (mode === "vision-api") {
        const response = await visionClient.compute(inferenceRequest(request), { signal: request && request.signal });
        const validated = validateResponse(response, request.width, request.height);
        return {
          ...validated,
          alpha: await applyAlphaPostProcessingAsync(
            validated.alpha,
            request.width,
            request.height,
            request.options,
            request.signal,
            request.onProgress
          )
        };
      }
      return algorithmEngine.compute(request);
    }
  };
}

module.exports = { createEngine, inferenceRequest, loadNativeAddon, validateResponse };
