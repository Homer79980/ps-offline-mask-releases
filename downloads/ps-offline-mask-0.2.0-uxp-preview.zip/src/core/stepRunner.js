function throwIfAborted(signal) {
  if (!signal || !signal.aborted) return;
  const error = new Error("Mask computation was canceled");
  error.name = "AbortError";
  error.code = "canceled";
  throw error;
}

function yieldToHost() {
  return new Promise((resolve) => setTimeout(resolve, 0));
}

function now() {
  return typeof performance !== "undefined" && typeof performance.now === "function"
    ? performance.now()
    : Date.now();
}

function runStepsSync(iterator) {
  let step = iterator.next();
  while (!step.done) step = iterator.next();
  return step.value;
}

async function runStepsAsync(iterator, signal, onProgress) {
  const timeBudgetMs = 8;
  const progressIntervalMs = 32;
  let pendingProgress;
  let lastProgressAt = -Infinity;
  while (true) {
    const batchStartedAt = now();
    do {
      throwIfAborted(signal);
      const step = iterator.next();
      if (step.done) {
        if (typeof onProgress === "function" && pendingProgress !== undefined) {
          onProgress(pendingProgress);
        }
        return step.value;
      }
      if (step.value !== undefined) pendingProgress = step.value;
    } while (now() - batchStartedAt < timeBudgetMs);

    const currentTime = now();
    if (
      typeof onProgress === "function"
      && pendingProgress !== undefined
      && currentTime - lastProgressAt >= progressIntervalMs
    ) {
      onProgress(pendingProgress);
      pendingProgress = undefined;
      lastProgressAt = currentTime;
    }
    await yieldToHost();
  }
}

module.exports = { runStepsAsync, runStepsSync, throwIfAborted };
