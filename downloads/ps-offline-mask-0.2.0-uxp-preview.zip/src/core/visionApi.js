const { runStepsAsync, throwIfAborted } = require("./stepRunner");

const CONTRACT_VERSION = 1;
const DEFAULT_TIMEOUT_MS = 30_000;
// Keep serialized requests bounded: a 16 MP RGB layer is about 48 MiB before
// Base64/JSON overhead, which is large enough for the supported UI workflow
// without allowing an accidental multi-hundred-megapixel allocation.
const MAX_IMAGE_PIXELS = 16_777_216;
const MAX_BINARY_BYTES = 64 * 1024 * 1024;
const MAX_BASE64_CHARS = Math.ceil(MAX_BINARY_BYTES / 3) * 4;

const ERROR_CATEGORIES = Object.freeze({
  CONFIGURATION: "configuration",
  AUTHENTICATION: "authentication",
  RATE_LIMIT: "rate-limit",
  PERMISSION: "permission",
  TIMEOUT: "timeout",
  SERVER: "server",
  RESPONSE_FORMAT: "response-format",
  NETWORK: "network",
  CANCELED: "canceled"
});

function bytesToBase64(bytes) {
  if (!(bytes instanceof Uint8Array)) {
    throw new TypeError("Only Uint8Array values can be encoded");
  }
  if (bytes.length > MAX_BINARY_BYTES) {
    throw new RangeError("Vision API binary payload exceeds the 64 MiB limit");
  }
  if (typeof Buffer !== "undefined") {
    return Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength).toString("base64");
  }
  if (typeof btoa !== "function") {
    throw new Error("No base64 encoder is available in this runtime");
  }
  let encoded = "";
  // Chunk btoa input so UXP does not build a second enormous binary string.
  // Every non-final chunk must contain a multiple of three bytes; otherwise
  // its padding would appear in the middle of the concatenated Base64 value.
  const chunkSize = 0x6000;
  for (let offset = 0; offset < bytes.length; offset += chunkSize) {
    const end = Math.min(bytes.length, offset + chunkSize);
    let binary = "";
    for (let index = offset; index < end; index += 1) binary += String.fromCharCode(bytes[index]);
    encoded += btoa(binary);
  }
  return encoded;
}

function* bytesToBase64Steps(bytes) {
  if (!(bytes instanceof Uint8Array)) {
    throw new TypeError("Only Uint8Array values can be encoded");
  }
  if (bytes.length > MAX_BINARY_BYTES) {
    throw new RangeError("Vision API binary payload exceeds the 64 MiB limit");
  }
  const chunks = [];
  const chunkSize = 0x6000;
  for (let offset = 0; offset < bytes.length; offset += chunkSize) {
    const end = Math.min(bytes.length, offset + chunkSize);
    if (typeof Buffer !== "undefined") {
      chunks.push(Buffer.from(bytes.buffer, bytes.byteOffset + offset, end - offset).toString("base64"));
    } else {
      if (typeof btoa !== "function") throw new Error("No base64 encoder is available in this runtime");
      let binary = "";
      for (let index = offset; index < end; index += 1) binary += String.fromCharCode(bytes[index]);
      chunks.push(btoa(binary));
    }
    yield;
  }
  return chunks.join("");
}

async function bytesToBase64Async(bytes, signal) {
  return runStepsAsync(bytesToBase64Steps(bytes), signal);
}

function normalizeBase64(value, name = "Vision API value") {
  if (typeof value !== "string") throw new TypeError(`${name} must be base64`);
  if (value.length > MAX_BASE64_CHARS) {
    throw new RangeError(`${name} exceeds the 64 MiB limit`);
  }
  const normalized = value.replace(/\s+/g, "");
  if (!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(normalized)) {
    throw new TypeError(`${name} is not valid base64`);
  }
  const padding = normalized.endsWith("==") ? 2 : normalized.endsWith("=") ? 1 : 0;
  const byteLength = Math.max(0, (normalized.length / 4) * 3 - padding);
  if (byteLength > MAX_BINARY_BYTES) {
    throw new RangeError(`${name} exceeds the 64 MiB limit`);
  }
  return { value: normalized, byteLength };
}

function* normalizeBase64Steps(value, name) {
  if (typeof value !== "string") throw new TypeError(`${name} must be base64`);
  if (value.length > MAX_BASE64_CHARS) throw new RangeError(`${name} exceeds the 64 MiB limit`);
  const parts = [];
  let padding = 0;
  const chunkSize = 0x10000;
  for (let offset = 0; offset < value.length; offset += chunkSize) {
    const cleaned = value.slice(offset, offset + chunkSize).replace(/\s+/g, "");
    if (!/^[A-Za-z0-9+/=]*$/.test(cleaned)) throw new TypeError(`${name} is not valid base64`);
    for (let index = 0; index < cleaned.length; index += 1) {
      if (cleaned[index] === "=") padding += 1;
      else if (padding > 0) throw new TypeError(`${name} is not valid base64`);
      if (padding > 2) throw new TypeError(`${name} is not valid base64`);
    }
    parts.push(cleaned);
    yield;
  }
  const normalized = parts.join("");
  if (normalized.length % 4 !== 0) throw new TypeError(`${name} is not valid base64`);
  const byteLength = Math.max(0, (normalized.length / 4) * 3 - padding);
  if (byteLength > MAX_BINARY_BYTES) throw new RangeError(`${name} exceeds the 64 MiB limit`);
  return { value: normalized, byteLength };
}

async function normalizeBase64Async(value, name = "Vision API value", signal) {
  return runStepsAsync(normalizeBase64Steps(value, name), signal);
}

function base64ToBytes(value) {
  if (value instanceof Uint8Array) {
    if (value.length > MAX_BINARY_BYTES) throw new RangeError("Vision API binary payload exceeds the 64 MiB limit");
    return new Uint8Array(value);
  }
  if (typeof Uint8ClampedArray !== "undefined" && value instanceof Uint8ClampedArray) {
    if (value.length > MAX_BINARY_BYTES) throw new RangeError("Vision API binary payload exceeds the 64 MiB limit");
    return new Uint8Array(value);
  }
  if (Array.isArray(value)) {
    if (value.length > MAX_BINARY_BYTES) throw new RangeError("Vision API binary payload exceeds the 64 MiB limit");
    if (!value.every((byte) => Number.isInteger(byte) && byte >= 0 && byte <= 255)) {
      throw new TypeError("Vision API alpha byte arrays must contain values from 0 to 255");
    }
    return new Uint8Array(value);
  }
  if (typeof value !== "string") {
    throw new TypeError("Vision API alpha must be base64 or a byte array");
  }
  // Reject malformed Base64 instead of allowing Buffer.from to silently truncate it.
  const normalized = normalizeBase64(value, "Vision API alpha").value;
  if (typeof Buffer !== "undefined") {
    return new Uint8Array(Buffer.from(normalized, "base64"));
  }
  if (typeof atob !== "function") {
    throw new Error("No base64 decoder is available in this runtime");
  }
  const binary = atob(normalized);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }
  return bytes;
}

function* copyBytesSteps(value) {
  const bytes = new Uint8Array(value.length);
  const chunkSize = 0x10000;
  for (let offset = 0; offset < value.length; offset += chunkSize) {
    const end = Math.min(value.length, offset + chunkSize);
    if (Array.isArray(value)) {
      for (let index = offset; index < end; index += 1) {
        const byte = value[index];
        if (!Number.isInteger(byte) || byte < 0 || byte > 255) {
          throw new TypeError("Vision API alpha byte arrays must contain values from 0 to 255");
        }
        bytes[index] = byte;
      }
    } else {
      bytes.set(value.subarray(offset, end), offset);
    }
    yield;
  }
  return bytes;
}

function* decodeBase64Steps(normalized, byteLength) {
  const bytes = new Uint8Array(byteLength);
  const chunkSize = 0x8000;
  let targetOffset = 0;
  for (let offset = 0; offset < normalized.length; offset += chunkSize) {
    const chunk = normalized.slice(offset, Math.min(normalized.length, offset + chunkSize));
    let decoded;
    if (typeof Buffer !== "undefined") decoded = Buffer.from(chunk, "base64");
    else {
      if (typeof atob !== "function") throw new Error("No base64 decoder is available in this runtime");
      const binary = atob(chunk);
      decoded = new Uint8Array(binary.length);
      for (let index = 0; index < binary.length; index += 1) decoded[index] = binary.charCodeAt(index);
    }
    bytes.set(decoded, targetOffset);
    targetOffset += decoded.length;
    yield;
  }
  return bytes;
}

async function base64ToBytesAsync(value, signal, name = "Vision API alpha") {
  if (value instanceof Uint8Array || (typeof Uint8ClampedArray !== "undefined" && value instanceof Uint8ClampedArray)) {
    if (value.length > MAX_BINARY_BYTES) throw new RangeError("Vision API binary payload exceeds the 64 MiB limit");
    return runStepsAsync(copyBytesSteps(value), signal);
  }
  if (Array.isArray(value)) {
    if (value.length > MAX_BINARY_BYTES) throw new RangeError("Vision API binary payload exceeds the 64 MiB limit");
    return runStepsAsync(copyBytesSteps(value), signal);
  }
  if (typeof value !== "string") throw new TypeError("Vision API alpha must be base64 or a byte array");
  const normalized = await normalizeBase64Async(value, name, signal);
  return runStepsAsync(decodeBase64Steps(normalized.value, normalized.byteLength), signal);
}

function createRequestId() {
  try {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
  } catch (error) {
    // Some UXP runtimes expose a partial crypto object. Use the fallback below.
  }
  return `vision-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
}

function isPositiveInteger(value) {
  return Number.isInteger(value) && value > 0;
}

function assertImageDimensions(width, height) {
  if (!isPositiveInteger(width) || !isPositiveInteger(height)) {
    throw new TypeError("Vision API image width and height must be positive integers");
  }
  const pixels = width * height;
  if (!Number.isSafeInteger(pixels) || pixels > MAX_IMAGE_PIXELS) {
    throw new RangeError(`Vision API image exceeds the ${MAX_IMAGE_PIXELS.toLocaleString()} pixel limit`);
  }
  return pixels;
}

function validateTrimapBytes(bytes, expectedLength) {
  if (!(bytes instanceof Uint8Array)) throw new TypeError("Vision API trimap must be a byte array");
  if (bytes.length !== expectedLength) {
    throw new TypeError("Vision API trimap data length does not match dimensions");
  }
  for (let index = 0; index < bytes.length; index += 1) {
    if (bytes[index] !== 0 && bytes[index] !== 1 && bytes[index] !== 2) {
      throw new TypeError("Vision API trimap labels must be unknown (0), keep (1), or cut (2)");
    }
  }
  return bytes;
}

function* validateTrimapSteps(bytes, expectedLength) {
  if (!(bytes instanceof Uint8Array)) throw new TypeError("Vision API trimap must be a byte array");
  if (bytes.length !== expectedLength) throw new TypeError("Vision API trimap data length does not match dimensions");
  const chunkSize = 0x10000;
  for (let offset = 0; offset < bytes.length; offset += chunkSize) {
    const end = Math.min(bytes.length, offset + chunkSize);
    for (let index = offset; index < end; index += 1) {
      if (bytes[index] !== 0 && bytes[index] !== 1 && bytes[index] !== 2) {
        throw new TypeError("Vision API trimap labels must be unknown (0), keep (1), or cut (2)");
      }
    }
    yield;
  }
  return bytes;
}

async function validateTrimapBytesAsync(bytes, expectedLength, signal) {
  return runStepsAsync(validateTrimapSteps(bytes, expectedLength), signal);
}

function serializeImage(request) {
  const image = request.image && typeof request.image === "object" ? request.image : null;
  const pixels = request.pixels instanceof Uint8Array
    ? request.pixels
    : image && (image.bytes instanceof Uint8Array || image.data instanceof Uint8Array)
      ? (image.bytes || image.data)
      : null;
  const width = request.width ?? (image && image.width);
  const height = request.height ?? (image && image.height);
  const components = request.components ?? (image && image.components);
  const hasBase64 = Boolean(image && typeof image.dataBase64 === "string");
  if (!pixels && !hasBase64) {
    throw new TypeError("Vision API requests require Uint8Array pixels");
  }
  const pixelCount = assertImageDimensions(width, height);
  if (components !== 3 && components !== 4) {
    throw new TypeError("Vision API image components must be RGB (3) or RGBA (4)");
  }
  if (image && image.colorSpace && image.colorSpace !== "RGB") {
    throw new TypeError("Vision API image colorSpace must be RGB");
  }
  let dataBase64;
  let outputComponents = 3;
  if (hasBase64) {
    if (components !== 3) {
      throw new TypeError("Vision API base64 images must already be RGB");
    }
    const encoded = normalizeBase64(image.dataBase64, "Vision API image data");
    const expectedBytes = pixelCount * 3;
    if (expectedBytes > MAX_BINARY_BYTES || encoded.byteLength !== expectedBytes) {
      throw new TypeError("Vision API base64 image data length does not match dimensions");
    }
    dataBase64 = encoded.value;
  } else {
    const expectedLength = pixelCount * components;
    if (expectedLength > MAX_BINARY_BYTES) {
      throw new RangeError("Vision API image data exceeds the 64 MiB limit");
    }
    if (pixels.length !== expectedLength) {
      throw new TypeError("Vision API image pixel data length does not match dimensions");
    }
    if (components === 4) {
      const rgb = new Uint8Array(width * height * 3);
      for (let sourceIndex = 0, targetIndex = 0; sourceIndex < pixels.length; sourceIndex += 4, targetIndex += 3) {
        rgb[targetIndex] = pixels[sourceIndex];
        rgb[targetIndex + 1] = pixels[sourceIndex + 1];
        rgb[targetIndex + 2] = pixels[sourceIndex + 2];
      }
      dataBase64 = bytesToBase64(rgb);
    } else {
      dataBase64 = bytesToBase64(pixels);
    }
  }
  return {
    dataBase64,
    width,
    height,
    components: outputComponents,
    colorSpace: (image && image.colorSpace) || "RGB"
  };
}

function serializeTrimap(request, width, height) {
  const trimap = request.trimap;
  const expectedLength = width * height;
  if (trimap instanceof Uint8Array) {
    validateTrimapBytes(trimap, expectedLength);
    return {
      dataBase64: bytesToBase64(trimap),
      width,
      height,
      encoding: "uint8-labels-unknown-keep-cut"
    };
  }
  if (trimap && typeof trimap === "object" && typeof trimap.dataBase64 === "string") {
    const trimapWidth = trimap.width ?? width;
    const trimapHeight = trimap.height ?? height;
    assertImageDimensions(trimapWidth, trimapHeight);
    if (trimapWidth !== width || trimapHeight !== height) {
      throw new TypeError("Vision API trimap dimensions must match the image");
    }
    const encoded = normalizeBase64(trimap.dataBase64, "Vision API trimap data");
    if (encoded.byteLength !== expectedLength) {
      throw new TypeError("Vision API trimap data length does not match dimensions");
    }
    validateTrimapBytes(base64ToBytes(encoded.value), expectedLength);
    return {
      dataBase64: encoded.value,
      width: trimapWidth,
      height: trimapHeight,
      encoding: trimap.encoding || "uint8-labels-unknown-keep-cut"
    };
  }
  if (trimap && typeof trimap === "object" && (trimap.bytes instanceof Uint8Array || trimap.data instanceof Uint8Array)) {
    const trimapWidth = trimap.width ?? width;
    const trimapHeight = trimap.height ?? height;
    assertImageDimensions(trimapWidth, trimapHeight);
    if (trimapWidth !== width || trimapHeight !== height) {
      throw new TypeError("Vision API trimap dimensions must match the image");
    }
    const bytes = trimap.bytes || trimap.data;
    validateTrimapBytes(bytes, expectedLength);
    return {
      dataBase64: bytesToBase64(bytes),
      width: trimapWidth,
      height: trimapHeight,
      encoding: trimap.encoding || "uint8-labels-unknown-keep-cut"
    };
  }
  throw new TypeError("Vision API requests require a Uint8Array trimap");
}

function serializeVisionRequest(request = {}) {
  const contractVersion = request.contractVersion ?? CONTRACT_VERSION;
  if (!Number.isInteger(contractVersion) || contractVersion < 1) {
    throw new TypeError("Vision API contractVersion must be a positive integer");
  }
  const image = serializeImage(request);
  const trimap = serializeTrimap(request, image.width, image.height);
  if (trimap.width !== image.width || trimap.height !== image.height) {
    throw new TypeError("Vision API trimap dimensions must match the image");
  }
  const payload = {
    contractVersion,
    requestId: request.requestId || createRequestId(),
    image,
    trimap,
    options: request.options && typeof request.options === "object" ? request.options : {}
  };
  if (request.client && typeof request.client === "object") payload.client = request.client;
  return payload;
}

function imageInput(request) {
  const image = request.image && typeof request.image === "object" ? request.image : null;
  const pixels = request.pixels instanceof Uint8Array
    ? request.pixels
    : image && (image.bytes instanceof Uint8Array || image.data instanceof Uint8Array)
      ? (image.bytes || image.data)
      : null;
  return {
    image,
    pixels,
    width: request.width ?? (image && image.width),
    height: request.height ?? (image && image.height),
    components: request.components ?? (image && image.components),
    hasBase64: Boolean(image && typeof image.dataBase64 === "string")
  };
}

function* stripAlphaSteps(pixels, pixelCount) {
  const rgb = new Uint8Array(pixelCount * 3);
  const chunkPixels = 0x4000;
  for (let pixelOffset = 0; pixelOffset < pixelCount; pixelOffset += chunkPixels) {
    const end = Math.min(pixelCount, pixelOffset + chunkPixels);
    for (let pixelIndex = pixelOffset; pixelIndex < end; pixelIndex += 1) {
      const sourceIndex = pixelIndex * 4;
      const targetIndex = pixelIndex * 3;
      rgb[targetIndex] = pixels[sourceIndex];
      rgb[targetIndex + 1] = pixels[sourceIndex + 1];
      rgb[targetIndex + 2] = pixels[sourceIndex + 2];
    }
    yield;
  }
  return rgb;
}

async function serializeImageAsync(request, signal) {
  throwIfAborted(signal);
  const { image, pixels, width, height, components, hasBase64 } = imageInput(request);
  if (!pixels && !hasBase64) throw new TypeError("Vision API requests require Uint8Array pixels");
  const pixelCount = assertImageDimensions(width, height);
  if (components !== 3 && components !== 4) throw new TypeError("Vision API image components must be RGB (3) or RGBA (4)");
  if (image && image.colorSpace && image.colorSpace !== "RGB") throw new TypeError("Vision API image colorSpace must be RGB");
  let dataBase64;
  if (hasBase64) {
    if (components !== 3) throw new TypeError("Vision API base64 images must already be RGB");
    const encoded = await normalizeBase64Async(image.dataBase64, "Vision API image data", signal);
    const expectedBytes = pixelCount * 3;
    if (expectedBytes > MAX_BINARY_BYTES || encoded.byteLength !== expectedBytes) {
      throw new TypeError("Vision API base64 image data length does not match dimensions");
    }
    dataBase64 = encoded.value;
  } else {
    const expectedLength = pixelCount * components;
    if (expectedLength > MAX_BINARY_BYTES) throw new RangeError("Vision API image data exceeds the 64 MiB limit");
    if (pixels.length !== expectedLength) throw new TypeError("Vision API image pixel data length does not match dimensions");
    const rgb = components === 4 ? await runStepsAsync(stripAlphaSteps(pixels, pixelCount), signal) : pixels;
    dataBase64 = await bytesToBase64Async(rgb, signal);
  }
  return {
    dataBase64,
    width,
    height,
    components: 3,
    colorSpace: (image && image.colorSpace) || "RGB"
  };
}

async function serializeTrimapAsync(request, width, height, signal) {
  throwIfAborted(signal);
  const trimap = request.trimap;
  const expectedLength = width * height;
  if (trimap instanceof Uint8Array) {
    await validateTrimapBytesAsync(trimap, expectedLength, signal);
    return {
      dataBase64: await bytesToBase64Async(trimap, signal),
      width,
      height,
      encoding: "uint8-labels-unknown-keep-cut"
    };
  }
  if (trimap && typeof trimap === "object" && typeof trimap.dataBase64 === "string") {
    const trimapWidth = trimap.width ?? width;
    const trimapHeight = trimap.height ?? height;
    assertImageDimensions(trimapWidth, trimapHeight);
    if (trimapWidth !== width || trimapHeight !== height) throw new TypeError("Vision API trimap dimensions must match the image");
    const encoded = await normalizeBase64Async(trimap.dataBase64, "Vision API trimap data", signal);
    if (encoded.byteLength !== expectedLength) throw new TypeError("Vision API trimap data length does not match dimensions");
    const bytes = await runStepsAsync(decodeBase64Steps(encoded.value, encoded.byteLength), signal);
    await validateTrimapBytesAsync(bytes, expectedLength, signal);
    return {
      dataBase64: encoded.value,
      width: trimapWidth,
      height: trimapHeight,
      encoding: trimap.encoding || "uint8-labels-unknown-keep-cut"
    };
  }
  if (trimap && typeof trimap === "object" && (trimap.bytes instanceof Uint8Array || trimap.data instanceof Uint8Array)) {
    const trimapWidth = trimap.width ?? width;
    const trimapHeight = trimap.height ?? height;
    assertImageDimensions(trimapWidth, trimapHeight);
    if (trimapWidth !== width || trimapHeight !== height) throw new TypeError("Vision API trimap dimensions must match the image");
    const bytes = trimap.bytes || trimap.data;
    await validateTrimapBytesAsync(bytes, expectedLength, signal);
    return {
      dataBase64: await bytesToBase64Async(bytes, signal),
      width: trimapWidth,
      height: trimapHeight,
      encoding: trimap.encoding || "uint8-labels-unknown-keep-cut"
    };
  }
  throw new TypeError("Vision API requests require a Uint8Array trimap");
}

async function serializeVisionRequestAsync(request = {}, signal) {
  throwIfAborted(signal);
  const contractVersion = request.contractVersion ?? CONTRACT_VERSION;
  if (!Number.isInteger(contractVersion) || contractVersion < 1) {
    throw new TypeError("Vision API contractVersion must be a positive integer");
  }
  const image = await serializeImageAsync(request, signal);
  const trimap = await serializeTrimapAsync(request, image.width, image.height, signal);
  throwIfAborted(signal);
  const payload = {
    contractVersion,
    requestId: request.requestId || createRequestId(),
    image,
    trimap,
    options: request.options && typeof request.options === "object" ? request.options : {}
  };
  if (request.client && typeof request.client === "object") payload.client = request.client;
  return payload;
}

function stringifyVisionPayload(payload, signal) {
  throwIfAborted(signal);
  const image = payload.image;
  const trimap = payload.trimap;
  const fields = [
    `"contractVersion":${JSON.stringify(payload.contractVersion)}`,
    `"requestId":${JSON.stringify(payload.requestId)}`,
    `"image":{"dataBase64":"${image.dataBase64}","width":${image.width},"height":${image.height},"components":${image.components},"colorSpace":${JSON.stringify(image.colorSpace)}}`,
    `"trimap":{"dataBase64":"${trimap.dataBase64}","width":${trimap.width},"height":${trimap.height},"encoding":${JSON.stringify(trimap.encoding)}}`,
    `"options":${JSON.stringify(payload.options)}`
  ];
  if (payload.client) fields.push(`"client":${JSON.stringify(payload.client)}`);
  throwIfAborted(signal);
  return `{${fields.join(",")}}`;
}

function makeDiagnostics(diagnostics) {
  if (!diagnostics || typeof diagnostics !== "object" || Array.isArray(diagnostics)) return { engine: "vision-api" };
  const normalized = { ...diagnostics, engine: "vision-api" };
  if (Object.prototype.hasOwnProperty.call(normalized, "confidence")) {
    const confidence = Number(normalized.confidence);
    if (!Number.isFinite(confidence) || confidence < 0 || confidence > 100) delete normalized.confidence;
    else normalized.confidence = confidence;
  }
  if (Object.prototype.hasOwnProperty.call(normalized, "processingMs")) {
    const processingMs = Number(normalized.processingMs);
    if (!Number.isFinite(processingMs) || processingMs < 0) delete normalized.processingMs;
    else normalized.processingMs = processingMs;
  }
  if (Object.prototype.hasOwnProperty.call(normalized, "warnings")) {
    if (!Array.isArray(normalized.warnings)) delete normalized.warnings;
    else normalized.warnings = normalized.warnings.filter((warning) => typeof warning === "string");
  }
  return normalized;
}

class VisionApiError extends Error {
  constructor(message, details = {}) {
    super(message);
    this.name = "VisionApiError";
    this.code = details.code || ERROR_CATEGORIES.NETWORK;
    this.category = details.category || this.code;
    this.kind = this.category;
    this.status = details.status;
    this.retryable = Boolean(details.retryable);
    this.requestId = details.requestId;
    this.accepted = Boolean(details.accepted);
    if (details.cause !== undefined) this.cause = details.cause;
  }
}

function errorForCategory(category, message, details = {}) {
  return new VisionApiError(message, {
    ...details,
    code: details.code || category,
    category
  });
}

function classifyHttpStatus(status) {
  if (status === 401) return { category: ERROR_CATEGORIES.AUTHENTICATION, retryable: false };
  if (status === 403) return { category: ERROR_CATEGORIES.PERMISSION, retryable: false };
  if (status === 408) return { category: ERROR_CATEGORIES.TIMEOUT, retryable: true };
  if (status === 429) return { category: ERROR_CATEGORIES.RATE_LIMIT, retryable: true };
  if (status >= 500 && status <= 599) return { category: ERROR_CATEGORIES.SERVER, retryable: true };
  if (status === 404 || status === 0) return { category: ERROR_CATEGORIES.CONFIGURATION, retryable: false };
  return { category: ERROR_CATEGORIES.RESPONSE_FORMAT, retryable: false };
}

function combineAbortSignal(signal, timeoutMs) {
  const hasTimeout = Number.isFinite(timeoutMs) && timeoutMs > 0;
  if (!signal && !hasTimeout) return { signal: undefined, timedOut: () => false, cleanup() {} };
  if (typeof AbortController !== "function") {
    return { signal, timedOut: () => false, cleanup() {} };
  }
  const controller = new AbortController();
  let timedOut = false;
  let timer;
  const abort = () => controller.abort();
  if (signal) {
    if (signal.aborted) controller.abort();
    else signal.addEventListener("abort", abort, { once: true });
  }
  if (hasTimeout) {
    timer = setTimeout(() => {
      timedOut = true;
      controller.abort();
    }, timeoutMs);
  }
  return {
    signal: controller.signal,
    timedOut: () => timedOut,
    cleanup() {
      if (timer) clearTimeout(timer);
      if (signal) signal.removeEventListener("abort", abort);
    }
  };
}

function abortReason(abort, sourceSignal, requestId, cause) {
  if (abort.timedOut()) {
    return errorForCategory(ERROR_CATEGORIES.TIMEOUT, "Vision API request timed out", {
      requestId,
      retryable: true,
      cause
    });
  }
  if ((sourceSignal && sourceSignal.aborted) || (abort.signal && abort.signal.aborted)) {
    return errorForCategory(ERROR_CATEGORIES.CANCELED, "Vision API request was canceled", {
      requestId,
      retryable: false,
      cause
    });
  }
  return null;
}

function awaitWithAbort(value, signal) {
  if (!signal) return Promise.resolve(value);
  if (signal.aborted) {
    const error = new Error("Vision API operation was aborted");
    error.name = "AbortError";
    return Promise.reject(error);
  }
  return new Promise((resolve, reject) => {
    const onAbort = () => {
      const error = new Error("Vision API operation was aborted");
      error.name = "AbortError";
      reject(error);
    };
    signal.addEventListener("abort", onAbort, { once: true });
    Promise.resolve(value).then(
      (result) => {
        signal.removeEventListener("abort", onAbort);
        resolve(result);
      },
      (error) => {
        signal.removeEventListener("abort", onAbort);
        reject(error);
      }
    );
  });
}

function endpointIsValid(endpoint) {
  if (typeof endpoint !== "string" || endpoint.trim() === "") return false;
  if (typeof URL !== "function") {
    if (/^[a-z]+:\/\/[^/\s]*@/i.test(endpoint)) return false;
    return /^https:\/\/[^\s]+$/i.test(endpoint) || /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?(?:\/|$)/i.test(endpoint);
  }
  try {
    const url = new URL(endpoint);
    if (url.username || url.password) return false;
    return url.protocol === "https:" || (url.protocol === "http:" && /^(localhost|127\.0\.0\.1)$/.test(url.hostname));
  } catch (error) {
    return false;
  }
}

function createVisionApiClient({
  endpoint,
  request,
  apiKeyProvider,
  headers = {},
  timeout,
  timeoutMs = timeout,
  logger
} = {}) {
  if (!endpoint) throw errorForCategory(ERROR_CATEGORIES.CONFIGURATION, "Vision API endpoint is required");
  if (!endpointIsValid(endpoint)) {
    throw errorForCategory(ERROR_CATEGORIES.CONFIGURATION, "Vision API endpoint must use HTTPS (localhost HTTP is allowed for development)");
  }
  const transport = request || (typeof fetch === "function" ? fetch : null);
  if (!transport) throw errorForCategory(ERROR_CATEGORIES.CONFIGURATION, "No HTTP transport is available in this runtime");
  if (typeof transport !== "function") {
    throw errorForCategory(ERROR_CATEGORIES.CONFIGURATION, "Vision API request transport must be a function");
  }
  if (!headers || typeof headers !== "object" || Array.isArray(headers)) {
    throw errorForCategory(ERROR_CATEGORIES.CONFIGURATION, "Vision API headers must be an object");
  }
  const sensitiveHeader = /(?:authorization|cookie|api[-_]?key|token|secret)/i;
  for (const name of Object.keys(headers)) {
    if (sensitiveHeader.test(name)) {
      throw errorForCategory(
        ERROR_CATEGORIES.CONFIGURATION,
        `Vision API credential header ${name} must be supplied by the runtime authentication provider`
      );
    }
  }
  const defaultTimeout = Number.isFinite(timeoutMs) && timeoutMs > 0 ? timeoutMs : DEFAULT_TIMEOUT_MS;

  return {
    kind: "vision-api",
    describe() {
      return "AI Vision API";
    },
    async compute(input = {}, computeOptions = {}) {
      computeOptions = computeOptions || {};
      const notifyStatus = (state, dataExported) => {
        if (typeof input.onStatus !== "function") return;
        try {
          input.onStatus({ state, dataExported: Boolean(dataExported) });
        } catch (error) {
          // UI status reporting must not affect the request contract.
        }
      };
      notifyStatus("preparing", false);
      const requestId = input.requestId || createRequestId();
      const directSignal = computeOptions && typeof computeOptions.aborted === "boolean"
        ? computeOptions
        : null;
      const signal = (directSignal || computeOptions.signal || input.signal);
      if (signal && signal.aborted) {
        throw errorForCategory(ERROR_CATEGORIES.CANCELED, "Vision API request was canceled", {
          requestId,
          retryable: false
        });
      }
      const requestedTimeout = computeOptions.timeoutMs ?? computeOptions.timeout ?? input.timeoutMs ?? input.timeout ?? defaultTimeout;
      const abort = combineAbortSignal(signal, requestedTimeout);
      const startedAt = Date.now();
      try {
        let payload;
        try {
          payload = await serializeVisionRequestAsync({ ...input, requestId }, abort.signal);
        } catch (cause) {
          const canceled = abortReason(abort, signal, requestId, cause);
          if (canceled) throw canceled;
          throw cause;
        }
        const requestHeaders = {
          "content-type": "application/json",
          ...headers
        };
        if (apiKeyProvider) {
          let apiKey;
          try {
            apiKey = await awaitWithAbort(apiKeyProvider(), abort.signal);
          } catch (cause) {
            const canceled = abortReason(abort, signal, requestId, cause);
            if (canceled) throw canceled;
            throw errorForCategory(ERROR_CATEGORIES.AUTHENTICATION, "Vision API authentication could not be provided", {
              requestId,
              cause
            });
          }
          if (apiKey !== undefined && apiKey !== null && String(apiKey) !== "") {
            requestHeaders.authorization = `Bearer ${String(apiKey)}`;
          }
        }
        const bodyText = stringifyVisionPayload(payload, abort.signal);
        let response;
        try {
          const responsePromise = transport(endpoint, {
            method: "POST",
            headers: requestHeaders,
            body: bodyText,
            ...(abort.signal ? { signal: abort.signal } : {})
          });
          notifyStatus("uploading", true);
          response = await awaitWithAbort(responsePromise, abort.signal);
          notifyStatus("processing", true);
        } catch (cause) {
          const canceled = abortReason(abort, signal, requestId, cause);
          if (canceled) throw canceled;
          throw errorForCategory(ERROR_CATEGORIES.NETWORK, "Vision API network request failed", {
            requestId,
            retryable: true,
            cause
          });
        }
        const status = response && Number.isInteger(response.status) ? response.status : undefined;
        if (!response || (typeof response.ok === "boolean" && !response.ok) || (status !== undefined && status >= 400)) {
          const classification = classifyHttpStatus(status || 0);
          const error = errorForCategory(
            classification.category,
            `Vision API request failed${status ? ` (${status})` : ""}`,
            { requestId, status, retryable: classification.retryable, accepted: Boolean(status && status >= 200 && status < 300) }
          );
          if (logger && typeof logger === "function") {
            try { logger({ status, requestId, elapsedMs: Date.now() - startedAt, category: error.category }); } catch (ignored) { /* logging must not affect requests */ }
          }
          throw error;
        }
        let body;
        try {
          const bodyPromise = typeof response.json === "function" ? response.json() : response;
          body = await awaitWithAbort(bodyPromise, abort.signal);
        } catch (cause) {
          const canceled = abortReason(abort, signal, requestId, cause);
          if (canceled) throw canceled;
          throw errorForCategory(ERROR_CATEGORIES.RESPONSE_FORMAT, "Vision API returned invalid JSON", {
            requestId,
            retryable: false,
            accepted: true,
            cause
          });
        }
        let result;
        try {
          result = await normalizeVisionResponseAsync(body, payload.image.width, payload.image.height, abort.signal);
        } catch (cause) {
          const canceled = abortReason(abort, signal, requestId, cause);
          if (canceled) throw canceled;
          if (cause instanceof VisionApiError) {
            cause.requestId = requestId;
            cause.accepted = true;
            throw cause;
          }
          throw errorForCategory(ERROR_CATEGORIES.RESPONSE_FORMAT, cause.message || "Vision API returned an invalid response", {
            requestId,
            retryable: false,
            accepted: true,
            cause
          });
        }
        if (logger && typeof logger === "function") {
          try { logger({ status: response.status, requestId, elapsedMs: Date.now() - startedAt, traceId: result.diagnostics.traceId }); } catch (ignored) { /* logging must not affect requests */ }
        }
        return result;
      } finally {
        abort.cleanup();
      }
    }
  };
}

function normalizeVisionResponse(response, width, height) {
  const source = response && response.result && typeof response.result === "object"
    ? response.result
    : response;
  if (!source || typeof source !== "object") {
    throw errorForCategory(ERROR_CATEGORIES.RESPONSE_FORMAT, "Vision API response is not a valid result");
  }
  let pixelCount;
  try {
    pixelCount = assertImageDimensions(width, height);
  } catch (cause) {
    throw errorForCategory(ERROR_CATEGORIES.RESPONSE_FORMAT, "Vision API response dimensions are invalid", { cause });
  }
  let alpha;
  try {
    const raw = source.alphaBase64 !== undefined ? source.alphaBase64 : source.alpha;
    if (typeof raw === "string") {
      const encoded = normalizeBase64(raw, "Vision API alpha");
      if (encoded.byteLength !== pixelCount) {
        throw new TypeError("Vision API returned an alpha buffer with invalid dimensions");
      }
      alpha = base64ToBytes(encoded.value);
    } else {
      if (raw && typeof raw.length === "number" && raw.length !== pixelCount) {
        throw new TypeError("Vision API returned an alpha buffer with invalid dimensions");
      }
      alpha = base64ToBytes(raw);
    }
  } catch (cause) {
    throw errorForCategory(ERROR_CATEGORIES.RESPONSE_FORMAT, "Vision API response alpha is invalid", { cause });
  }
  if (alpha.length !== pixelCount) {
    throw errorForCategory(ERROR_CATEGORIES.RESPONSE_FORMAT, "Vision API returned an alpha buffer with invalid dimensions");
  }
  return {
    alpha,
    diagnostics: makeDiagnostics(source.diagnostics)
  };
}

async function normalizeVisionResponseAsync(response, width, height, signal) {
  throwIfAborted(signal);
  const source = response && response.result && typeof response.result === "object"
    ? response.result
    : response;
  if (!source || typeof source !== "object") {
    throw errorForCategory(ERROR_CATEGORIES.RESPONSE_FORMAT, "Vision API response is not a valid result");
  }
  let pixelCount;
  try {
    pixelCount = assertImageDimensions(width, height);
  } catch (cause) {
    throw errorForCategory(ERROR_CATEGORIES.RESPONSE_FORMAT, "Vision API response dimensions are invalid", { cause });
  }
  let alpha;
  try {
    const raw = source.alphaBase64 !== undefined ? source.alphaBase64 : source.alpha;
    if (typeof raw === "string") {
      const encoded = await normalizeBase64Async(raw, "Vision API alpha", signal);
      if (encoded.byteLength !== pixelCount) {
        throw new TypeError("Vision API returned an alpha buffer with invalid dimensions");
      }
      alpha = await runStepsAsync(decodeBase64Steps(encoded.value, encoded.byteLength), signal);
    } else {
      if (raw && typeof raw.length === "number" && raw.length !== pixelCount) {
        throw new TypeError("Vision API returned an alpha buffer with invalid dimensions");
      }
      alpha = await base64ToBytesAsync(raw, signal, "Vision API alpha");
    }
  } catch (cause) {
    if (signal && signal.aborted) throw cause;
    throw errorForCategory(ERROR_CATEGORIES.RESPONSE_FORMAT, "Vision API response alpha is invalid", { cause });
  }
  if (alpha.length !== pixelCount) {
    throw errorForCategory(ERROR_CATEGORIES.RESPONSE_FORMAT, "Vision API returned an alpha buffer with invalid dimensions");
  }
  throwIfAborted(signal);
  return {
    alpha,
    diagnostics: makeDiagnostics(source.diagnostics)
  };
}

module.exports = {
  CONTRACT_VERSION,
  DEFAULT_TIMEOUT_MS,
  MAX_BINARY_BYTES,
  MAX_BASE64_CHARS,
  MAX_IMAGE_PIXELS,
  ERROR_CATEGORIES,
  VisionApiError,
  base64ToBytes,
  bytesToBase64,
  classifyHttpStatus,
  createRequestId,
  createVisionApiClient,
  normalizeBase64,
  normalizeVisionResponse,
  validateTrimapBytes,
  serializeVisionRequest
};
