/**
 * Coalesces high-frequency UI updates into one frame.
 * Timing functions are injectable so this behavior can be tested outside UXP.
 */
function createFrameScheduler(callback, timing = {}) {
  if (typeof callback !== "function") throw new TypeError("callback must be a function");
  const requestFrame = timing.requestFrame
    || (typeof globalThis !== "undefined" && typeof globalThis.requestAnimationFrame === "function"
      ? (handler) => globalThis.requestAnimationFrame(handler)
      : (handler) => setTimeout(handler, 16));
  const cancelFrame = timing.cancelFrame
    || (typeof globalThis !== "undefined" && typeof globalThis.cancelAnimationFrame === "function"
      ? (handle) => globalThis.cancelAnimationFrame(handle)
      : (handle) => clearTimeout(handle));
  let handle = null;

  function schedule() {
    if (handle !== null) return false;
    handle = requestFrame(() => {
      handle = null;
      callback();
    });
    return true;
  }

  function cancel() {
    if (handle === null) return false;
    cancelFrame(handle);
    handle = null;
    return true;
  }

  return Object.freeze({
    schedule,
    cancel,
    get pending() {
      return handle !== null;
    }
  });
}

module.exports = { createFrameScheduler };
