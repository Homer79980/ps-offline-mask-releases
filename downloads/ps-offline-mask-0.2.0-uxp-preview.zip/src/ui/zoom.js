const ZOOM_MIN = 0.05;
const ZOOM_MAX = 8;
const ZOOM_STEP = 0.05;

function clampZoom(value, fallback = 1) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return fallback;
  const stepped = Math.round(numeric / ZOOM_STEP) * ZOOM_STEP;
  return Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, stepped));
}

function calculateFitZoom(sourceWidth, sourceHeight, frameWidth, frameHeight, padding = 14) {
  const dimensions = [sourceWidth, sourceHeight, frameWidth, frameHeight].map(Number);
  if (dimensions.some((value) => !Number.isFinite(value) || value <= 0)) return ZOOM_MIN;
  const availableWidth = Math.max(1, dimensions[2] - padding);
  const availableHeight = Math.max(1, dimensions[3] - padding);
  return clampZoom(Math.min(availableWidth / dimensions[0], availableHeight / dimensions[1]));
}

module.exports = { ZOOM_MIN, ZOOM_MAX, ZOOM_STEP, calculateFitZoom, clampZoom };
