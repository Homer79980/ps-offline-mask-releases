const { calculateFitZoom, clampZoom } = require("./zoom");

const TRIMAP_COLORS = Object.freeze({
  keep: new Uint8ClampedArray([70, 225, 120, 110]),
  cut: new Uint8ClampedArray([240, 90, 90, 115]),
  unknown: new Uint8ClampedArray([80, 155, 255, 70])
});

function createCanvasView({ element, state, labels }) {
  function updateZoomUI() {
    const range = element("zoom-range");
    const output = element("zoom-value");
    const percent = Math.round(state.zoom * 100);
    if (range) range.value = String(percent);
    if (output) output.textContent = `${percent}%`;
    ["zoom-out", "zoom-in", "zoom-fit"].forEach((id) => {
      const control = element(id);
      if (control) control.disabled = state.busy || !state.source;
    });
  }

  function applyZoom() {
    const canvas = element("preview-canvas");
    if (!canvas || !state.source) return;
    canvas.style.width = `${Math.max(1, Math.round(state.source.width * state.zoom))}px`;
    canvas.style.height = `${Math.max(1, Math.round(state.source.height * state.zoom))}px`;
  }

  function setZoom(value, mode = "manual") {
    if (state.busy || !state.source) return;
    state.zoom = clampZoom(value, state.zoom);
    state.zoomMode = mode;
    applyZoom();
    updateZoomUI();
  }

  function fitZoom() {
    if (!state.source || state.busy) return;
    const frame = element("canvas-frame");
    if (!frame) return;
    setZoom(calculateFitZoom(
      state.source.width,
      state.source.height,
      frame.clientWidth,
      frame.clientHeight
    ), "fit");
  }

  function handleWheel(event) {
    if (!state.source || state.busy || (!event.ctrlKey && !event.metaKey)) return;
    event.preventDefault();
    setZoom(state.zoom * (event.deltaY < 0 ? 1.15 : 0.85));
  }

  function getPoint(event, canvas) {
    const rect = canvas.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left) * (canvas.width / Math.max(1, rect.width)),
      y: (event.clientY - rect.top) * (canvas.height / Math.max(1, rect.height))
    };
  }

  function drawLiveStroke(from, to) {
    const canvas = element("preview-canvas");
    if (!canvas || !from || !to) return;
    const context = canvas.getContext("2d");
    const color = state.tool === "keep"
      ? "rgba(70, 225, 120, 0.66)"
      : state.tool === "cut"
        ? "rgba(240, 90, 90, 0.68)"
        : "rgba(80, 155, 255, 0.52)";
    context.save();
    context.strokeStyle = color;
    context.lineWidth = Math.max(1, state.brushSize * 2);
    context.lineCap = "round";
    context.lineJoin = "round";
    context.beginPath();
    context.moveTo(from.x, from.y);
    context.lineTo(to.x, to.y);
    context.stroke();
    context.restore();
  }

  function drawSource(context) {
    const source = state.source;
    const cacheKey = `${source.width}x${source.height}:${source.components}:${source.pixels.length}`;
    if (!state.sourceImageData || state.sourceImageData.key !== cacheKey || state.sourceImageData.pixels !== source.pixels) {
      const image = context.createImageData(source.width, source.height);
      const channels = source.components >= 4 ? 4 : 3;
      for (let index = 0; index < source.width * source.height; index += 1) {
        const sourceIndex = index * source.components;
        const targetIndex = index * 4;
        image.data[targetIndex] = source.pixels[sourceIndex] || 0;
        image.data[targetIndex + 1] = source.pixels[sourceIndex + 1] || 0;
        image.data[targetIndex + 2] = source.pixels[sourceIndex + 2] || 0;
        image.data[targetIndex + 3] = channels === 4 ? source.pixels[sourceIndex + 3] : 255;
      }
      state.sourceImageData = { key: cacheKey, pixels: source.pixels, image };
    }
    context.putImageData(state.sourceImageData.image, 0, 0);
  }

  function drawMask(context) {
    const image = context.createImageData(state.source.width, state.source.height);
    for (let index = 0; index < state.alpha.length; index += 1) {
      const value = state.alpha[index];
      const targetIndex = index * 4;
      image.data[targetIndex] = value;
      image.data[targetIndex + 1] = value;
      image.data[targetIndex + 2] = value;
      image.data[targetIndex + 3] = 255;
    }
    context.putImageData(image, 0, 0);
  }

  function drawTrimapOverlay(context) {
    if (!state.trimap) return;
    if (!state.trimapImageData || state.trimapImageData.version !== state.trimapRenderVersion) {
      const overlay = context.createImageData(state.trimap.width, state.trimap.height);
      for (let index = 0; index < state.trimap.data.length; index += 1) {
        const label = state.trimap.data[index];
        const targetIndex = index * 4;
        if (label === labels.KEEP) {
          overlay.data.set(TRIMAP_COLORS.keep, targetIndex);
        } else if (label === labels.CUT) {
          overlay.data.set(TRIMAP_COLORS.cut, targetIndex);
        } else if (label === labels.UNKNOWN && state.trimap.painted[index]) {
          overlay.data.set(TRIMAP_COLORS.unknown, targetIndex);
        }
      }
      state.trimapImageData = { version: state.trimapRenderVersion, overlay };
    }
    context.putImageData(state.trimapImageData.overlay, 0, 0);
  }

  function draw() {
    const canvas = element("preview-canvas");
    const placeholder = element("canvas-placeholder");
    if (!canvas || !placeholder) return;
    if (!state.source) {
      placeholder.style.display = "block";
      canvas.width = 1;
      canvas.height = 1;
      canvas.style.width = "";
      canvas.style.height = "";
      updateZoomUI();
      return;
    }
    placeholder.style.display = "none";
    if (canvas.width !== state.source.width) canvas.width = state.source.width;
    if (canvas.height !== state.source.height) canvas.height = state.source.height;
    applyZoom();
    const context = canvas.getContext("2d");
    context.clearRect(0, 0, canvas.width, canvas.height);
    if (state.viewMode === "mask" && state.alpha) drawMask(context);
    else {
      drawSource(context);
      drawTrimapOverlay(context);
    }
  }

  return Object.freeze({ draw, drawLiveStroke, fitZoom, getPoint, handleWheel, setZoom, updateZoomUI });
}

module.exports = { createCanvasView };
