function createListenerRegistry() {
  const removers = [];

  function add(target, type, handler, options) {
    if (!target || typeof target.addEventListener !== "function") return false;
    target.addEventListener(type, handler, options);
    removers.push(() => target.removeEventListener(type, handler, options));
    return true;
  }

  function clear() {
    const callbacks = removers.splice(0);
    callbacks.forEach((remove) => {
      try { remove(); } catch (error) { /* listener may already be detached */ }
    });
    return callbacks.length;
  }

  return Object.freeze({
    add,
    clear,
    get size() {
      return removers.length;
    }
  });
}

module.exports = { createListenerRegistry };
