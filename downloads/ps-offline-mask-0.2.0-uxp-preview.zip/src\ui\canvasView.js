const { calculateFitZoom, clampZoom } = require("./zoom");

const TRIMAP_COLORS = Object.freeze({
  keep: "rgba(70, 225, 120, 0.43)",
  cut: "rgba(240, 90, 90, 0.45)",
  unknown: "rgba(80, 155, 255, 0.27)"
});

function createCanvasView({ element, state, labels }) {
  function updateZoomUI() {
    const range = element("zoom-range");
    const output = element("zoom-value");
    const percent = Math.round(state.zoom * 100);
    if (range) range.value = String(percent);
    if (output) output.textContent = `${percent}%`;
    ["zoom-out", "zoom-in", "zoom-fit"].forEach((id) => {
      const control = element(id);
      if (control) control.disabled = state.busy || !state.source;
    });
  }

  function applyZoom() {
    const canvas = element("preview-canvas");
    const stack = element("preview-stack");
    if (!canvas || !state.source) return;
    const width = Math.max(1, Math.round(state.source.width * state.zoom));
    const height = Math.max(1, Math.round(state.source.height * state.zoom));
    if (stack) {
      stack.style.width = `${width}px`;
      stack.style.height = `${height}px`;
    } else {
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
    }
  }

  function setZoom(value, mode = "manual") {
    if (state.busy || !state.source) return;
    state.zoom = clampZoom(value, state.zoom);
    state.zoomMode = mode;
    applyZoom();
    updateZoomUI();
  }

  function fitZoom() {
    if (!state.source || state.busy) return;
    const frame = element("canvas-frame");
    if (!frame) return;
    setZoom(calculateFitZoom(
      state.source.width,
      state.source.height,
      frame.clientWidth,
      frame.clientHeight
    ), "fit");
  }

  function handleWheel(event) {
    if (!state.source || state.busy || (!event.ctrlKey && !event.metaKey)) return;
    event.preventDefault();
    setZoom(state.zoom * (event.deltaY < 0 ? 1.15 : 0.85));
  }

  function getPoint(event, canvas) {
    const rect = canvas.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left) * (canvas.width / Math.max(1, rect.width)),
      y: (event.clientY - rect.top) * (canvas.height / Math.max(1, rect.height))
    };
  }

  function drawLiveStroke(from, to) {
    const canvas = element("preview-canvas");
    if (!canvas || !from || !to) return;
    const context = canvas.getContext("2d");
    if (!context) return;
    const color = state.tool === "keep"
      ? TRIMAP_COLORS.keep
      : state.tool === "cut"
        ? TRIMAP_COLORS.cut
        : TRIMAP_COLORS.unknown;
    if (typeof context.save === "function") context.save();
    context.strokeStyle = color;
    context.lineWidth = Math.max(1, state.brushSize * 2);
    context.lineCap = "round";
    context.lineJoin = "round";
    context.beginPath();
    context.moveTo(from.x, from.y);
    context.lineTo(to.x, to.y);
    context.stroke();
    if (typeof context.restore === "function") context.restore();
  }

  function colorForLabel(label) {
    if (label === labels.KEEP) return TRIMAP_COLORS.keep;
    if (label === labels.CUT) return TRIMAP_COLORS.cut;
    if (label === labels.UNKNOWN) return TRIMAP_COLORS.unknown;
    return null;
  }

  function drawTrimapOverlay(context) {
    if (!state.trimap || typeof context.fillRect !== "function") return;
    if (typeof context.save === "function") context.save();
    for (let y = 0; y < state.trimap.height; y += 1) {
      let runLabel = null;
      let runStart = 0;
      for (let x = 0; x <= state.trimap.width; x += 1) {
        const index = y * state.trimap.width + x;
        const label = x < state.trimap.width && state.trimap.painted[index]
          ? state.trimap.data[index]
          : null;
        if (label === runLabel) continue;
        if (runLabel !== null) {
          const color = colorForLabel(runLabel);
          if (color) {
            context.fillStyle = color;
            context.fillRect(runStart, y, x - runStart, 1);
          }
        }
        runLabel = label;
        runStart = x;
      }
    }
    if (typeof context.restore === "function") context.restore();
  }

  function draw() {
    const canvas = element("preview-canvas");
    const image = element("preview-image");
    const stack = element("preview-stack");
    const placeholder = element("canvas-placeholder");
    if (!canvas || !placeholder) return;
    if (!state.source) {
      placeholder.textContent = "读取图层后开始标记";
      placeholder.style.display = "block";
      if (image) image.style.display = "none";
      if (stack) {
        stack.style.width = "1px";
        stack.style.height = "1px";
      }
      canvas.width = 1;
      canvas.height = 1;
      canvas.style.width = "1px";
      canvas.style.height = "1px";
      updateZoomUI();
      return;
    }

    const hasRaster = typeof state.previewImageUrl === "string" && state.previewImageUrl.length > 0;
    placeholder.textContent = hasRaster
      ? ""
      : "当前 UXP 主机未生成预览图，结果仍显示在 Photoshop 画布";
    placeholder.style.display = hasRaster ? "none" : "block";
    if (image) {
      if (image.src !== state.previewImageUrl) image.src = state.previewImageUrl || "";
      image.style.display = hasRaster ? "block" : "none";
    }
    if (canvas.width !== state.source.width) canvas.width = state.source.width;
    if (canvas.height !== state.source.height) canvas.height = state.source.height;
    applyZoom();
    const context = canvas.getContext("2d");
    if (!context) return;
    if (typeof context.clearRect === "function") context.clearRect(0, 0, canvas.width, canvas.height);
    if (state.viewMode !== "mask") drawTrimapOverlay(context);
  }

  return Object.freeze({ draw, drawLiveStroke, fitZoom, getPoint, handleWheel, setZoom, updateZoomUI });
}

module.exports = { createCanvasView };
