const MAX_LOCAL_PIXELS = 16_777_216;

function toBounds(bounds) {
  if (!bounds) throw new Error("图层没有有效边界");
  const left = Math.round(Number(bounds.left) || 0);
  const top = Math.round(Number(bounds.top) || 0);
  const width = Math.max(1, Math.round(Number(bounds.width) || (Number(bounds.right) - left)));
  const height = Math.max(1, Math.round(Number(bounds.height) || (Number(bounds.bottom) - top)));
  return { left, top, width, height, right: left + width, bottom: top + height };
}

function copy8BitData(data, expectedLength, errorMessage) {
  if (data === null || data === undefined) throw new Error(errorMessage);
  if (ArrayBuffer.isView(data) && data.BYTES_PER_ELEMENT !== 1) {
    throw new Error(errorMessage);
  }
  if (Array.isArray(data) && data.some((value) => !Number.isInteger(value) || value < 0 || value > 255)) {
    throw new Error(errorMessage);
  }
  let copy;
  try {
    copy = new Uint8Array(data);
  } catch (error) {
    throw new Error(errorMessage);
  }
  if (copy.length !== expectedLength) throw new Error(errorMessage);
  return copy;
}

/**
 * Build the small Photoshop-facing adapter used by the panel.
 *
 * `action`/`batchPlay` are optional because older callers only injected the
 * four dependencies used by the first version of this adapter. They are used
 * solely for removing a mask that did not exist before a temporary preview.
 */
function createPhotoshopHost({ app, constants, imaging, core, action, batchPlay, photoshop } = {}) {
  const play = typeof batchPlay === "function"
    ? batchPlay
    : action && typeof action.batchPlay === "function"
      ? action.batchPlay.bind(action)
      : photoshop && photoshop.action && typeof photoshop.action.batchPlay === "function"
        ? photoshop.action.batchPlay.bind(photoshop.action)
        : null;
  const layerRefs = new Map();
  const maskSnapshots = new Map();
  let activePreviewKey = null;
  let activePreviewLayerInfo = null;

  function layerKey(layerInfo) {
    if (!layerInfo || !Number.isFinite(Number(layerInfo.documentID)) || !Number.isFinite(Number(layerInfo.layerID))) {
      throw new Error("图层信息不完整。");
    }
    return `${layerInfo.documentID}:${layerInfo.layerID}`;
  }

  function normalizedLayerInfo(layerInfo) {
    layerKey(layerInfo);
    const bounds = toBounds(layerInfo.bounds);
    return {
      ...layerInfo,
      bounds
    };
  }

  function copyAlpha(alpha, layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    const expectedLength = normalized.bounds.width * normalized.bounds.height;
    if (!(alpha instanceof Uint8Array) || alpha.length !== expectedLength) {
      throw new Error("蒙版尺寸与图层边界不一致。");
    }
    return new Uint8Array(alpha);
  }

  function layerReference(layerInfo) {
    return layerRefs.get(layerKey(layerInfo)) || layerInfo.layer || layerInfo.layerRef || null;
  }

  function assertDocumentIsActive(layerInfo) {
    const activeDocument = app && app.activeDocument;
    if (!activeDocument) {
      throw new Error("当前 Photoshop 文档不可用，请重新读取图层。");
    }
    if (activeDocument.id !== undefined && Number(activeDocument.id) !== Number(layerInfo.documentID)) {
      throw new Error("当前 Photoshop 文档已切换，请重新读取图层。");
    }
  }

  function assertLayerIsActive(layerInfo) {
    assertDocumentIsActive(layerInfo);
    const activeDocument = app && app.activeDocument;
    // `activeLayers` is available in Photoshop UXP. Keep compatibility with
    // older injected hosts that only expose the active document identity.
    if (!Array.isArray(activeDocument.activeLayers)) return;
    const activeLayer = activeDocument.activeLayers[0];
    if (!activeLayer || Number(activeLayer.id) !== Number(layerInfo.layerID)) {
      throw new Error("当前 Photoshop 图层已切换，请重新读取图层。");
    }
    const currentBoundsSource = activeLayer.boundsNoEffects || activeLayer.bounds;
    if (currentBoundsSource && layerInfo.bounds) {
      const currentBounds = toBounds(currentBoundsSource);
      const expectedBounds = toBounds(layerInfo.bounds);
      const changed = ["left", "top", "width", "height"]
        .some((key) => currentBounds[key] !== expectedBounds[key]);
      if (changed) throw new Error("当前 Photoshop 图层边界已变化，请重新读取图层。");
    }
  }

  function hasKnownMissingMask(layerInfo) {
    const candidate = layerReference(layerInfo);
    const userMaskValues = [
      layerInfo && layerInfo.hasUserMask,
      layerInfo && layerInfo.pixelMask && layerInfo.pixelMask.hasMask,
      layerInfo && layerInfo.userMask && layerInfo.userMask.hasMask,
      candidate && candidate.hasUserMask,
      candidate && candidate.pixelMask && candidate.pixelMask.hasMask,
      candidate && candidate.userMask && candidate.userMask.hasMask
    ];
    if (userMaskValues.some((value) => value === true)) return false;
    if (userMaskValues.some((value) => value === false)) return true;

    // Generic `hasMask` may include a vector mask, so only consult it when no
    // user/pixel-mask-specific metadata exists.
    const genericValues = [layerInfo && layerInfo.hasMask, candidate && candidate.hasMask];
    if (genericValues.some((value) => value === true)) return false;
    return genericValues.some((value) => value === false);
  }

  function isMissingMaskError(error) {
    const message = String(error && error.message || error || "").toLowerCase();
    const code = String(error && (error.code || error.number || error.name) || "").toLowerCase();
    const combined = `${message} ${code}`;
    return /(mask|channel|蒙版)/.test(combined)
      && /(not found|does not exist|doesn't exist|no such|missing|absent|not available|no .*mask|without .*mask|invalid .*channel|channel .*invalid|蒙版不存在|没有.*蒙版)/.test(combined);
  }

  function maskBounds(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    return {
      left: normalized.bounds.left,
      top: normalized.bounds.top,
      right: normalized.bounds.right,
      bottom: normalized.bounds.bottom
    };
  }

  function maskSnapshotCopy(snapshot) {
    return {
      documentID: snapshot.documentID,
      layerID: snapshot.layerID,
      width: snapshot.width,
      height: snapshot.height,
      bounds: { ...snapshot.bounds },
      present: snapshot.present === true,
      hasMask: snapshot.present === true,
      alpha: snapshot.alpha ? new Uint8Array(snapshot.alpha) : null,
      mask: snapshot.alpha ? new Uint8Array(snapshot.alpha) : null
    };
  }

  function canRemoveLayerMask(layerInfo) {
    if (play) return true;
    const layer = layerReference(layerInfo);
    if (!layer) return false;
    const masks = [layer.pixelMask, layer.userMask].filter(Boolean);
    return typeof layer.removeLayerMask === "function"
      || typeof layer.deleteLayerMask === "function"
      || masks.some((mask) => typeof mask.remove === "function" || typeof mask.delete === "function");
  }

  async function executeModal(work, commandName) {
    if (!core || typeof core.executeAsModal !== "function") {
      throw new Error("Photoshop executeAsModal API 不可用。");
    }
    return core.executeAsModal(work, { commandName });
  }

  async function removeLayerUserMask(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    assertLayerIsActive(normalized);
    const layerID = normalized.layerID;
    await executeModal(async () => {
      if (play) {
        await play([{
          _obj: "delete",
          _target: [
            { _ref: "channel", _enum: "channel", _value: "mask" },
            { _ref: "layer", _id: layerID }
          ]
        }], {});
        return;
      }

      const layer = layerReference(normalized);
      const mask = layer && (layer.pixelMask || layer.userMask);
      const remove = layer && (layer.removeLayerMask || layer.deleteLayerMask);
      if (typeof remove === "function") {
        await remove.call(layer);
        return;
      }
      if (mask && typeof mask.remove === "function") {
        await mask.remove();
        return;
      }
      if (mask && typeof mask.delete === "function") {
        await mask.delete();
        return;
      }
      throw new Error("Photoshop 无法删除临时图层蒙版，请注入 action.batchPlay。");
    }, "取消离线抠图蒙版预览");
  }

  async function readLayerMask(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    const expectedWidth = normalized.bounds.width;
    const expectedHeight = normalized.bounds.height;
    const emptySnapshot = {
      documentID: normalized.documentID,
      layerID: normalized.layerID,
      width: expectedWidth,
      height: expectedHeight,
      bounds: { ...normalized.bounds },
      present: false,
      hasMask: false,
      alpha: null,
      mask: null
    };

    if (!imaging || typeof imaging.getLayerMask !== "function") {
      if (hasKnownMissingMask(normalized)) return emptySnapshot;
      throw new Error("Photoshop imaging.getLayerMask API 不可用。");
    }

    let result;
    try {
      // Photoshop 27.x can enforce the modal scope for Imaging reads even
      // though older builds allowed getLayerMask outside it.
      result = await executeModal(() => imaging.getLayerMask({
        documentID: normalized.documentID,
        layerID: normalized.layerID,
        kind: "user",
        sourceBounds: maskBounds(normalized)
      }), "读取 Photoshop 图层蒙版");
    } catch (error) {
      if (hasKnownMissingMask(normalized) || isMissingMaskError(error)) return emptySnapshot;
      throw error;
    }

    if (!result || !result.imageData) {
      if (hasKnownMissingMask(normalized)) return emptySnapshot;
      throw new Error("Photoshop 返回了无效的图层蒙版数据。");
    }
    const imageData = result.imageData;
    try {
      const width = Number(imageData.width);
      const height = Number(imageData.height);
      const components = Number(imageData.components);
      const componentSize = imageData.componentSize ?? imageData.bitsPerChannel;
      if (componentSize !== undefined && Number(componentSize) !== 8) {
        throw new Error("Photoshop 图层蒙版必须是 8-bit 数据。");
      }
      if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1) {
        throw new Error("Photoshop 返回了无效的图层蒙版尺寸。");
      }
      if (components !== 1) {
        throw new Error("Photoshop 图层蒙版必须是单通道灰度数据。");
      }
      if (width !== expectedWidth || height !== expectedHeight) {
        throw new Error("Photoshop 图层蒙版尺寸与图层边界不一致。");
      }
      const data = await imageData.getData({ chunky: true });
      const alpha = copy8BitData(data, expectedWidth * expectedHeight, "Photoshop 图层蒙版数据长度不正确。");
      const snapshot = {
        documentID: normalized.documentID,
        layerID: normalized.layerID,
        width: expectedWidth,
        height: expectedHeight,
        bounds: { ...normalized.bounds },
        present: true,
        hasMask: true,
        alpha,
        mask: new Uint8Array(alpha),
        sourceBounds: toBounds(result.sourceBounds || normalized.bounds)
      };
      return snapshot;
    } finally {
      if (typeof imageData.dispose === "function") imageData.dispose();
    }
  }

  async function saveLayerMask(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    const key = layerKey(normalized);
    if (maskSnapshots.has(key)) return maskSnapshotCopy(maskSnapshots.get(key));
    const snapshot = await readLayerMask(normalized);
    const copy = maskSnapshotCopy(snapshot);
    maskSnapshots.set(key, copy);
    return maskSnapshotCopy(copy);
  }

  async function writeLayerMask(layerInfo, alpha) {
    const normalized = normalizedLayerInfo(layerInfo);
    assertLayerIsActive(normalized);
    const copy = copyAlpha(alpha, normalized);
    await executeModal(async () => {
      const maskData = await imaging.createImageDataFromBuffer(copy, {
        width: normalized.bounds.width,
        height: normalized.bounds.height,
        components: 1,
        chunky: false,
        colorProfile: "Gray Gamma 2.2",
        colorSpace: "Grayscale"
      });

      try {
        await imaging.putLayerMask({
          documentID: normalized.documentID,
          layerID: normalized.layerID,
          kind: "user",
          imageData: maskData,
          replace: true,
          targetBounds: {
            left: normalized.bounds.left,
            top: normalized.bounds.top
          },
          commandName: "应用离线抠图蒙版"
        });
      } finally {
        if (maskData && typeof maskData.dispose === "function") maskData.dispose();
      }
    }, "应用离线抠图蒙版");
    return copy;
  }

  async function restoreLayerMask(layerInfo, snapshot) {
    const normalized = normalizedLayerInfo(layerInfo);
    if (!snapshot || snapshot.present !== true) {
      await removeLayerUserMask(normalized);
      return;
    }
    await writeLayerMask(normalized, snapshot.alpha || snapshot.mask);
  }
  function getActivePixelLayer() {
    if (!app.documents || app.documents.length === 0) {
      throw new Error("请先打开一个 Photoshop 文档。");
    }

    const document = app.activeDocument;
    const layer = document.activeLayers && document.activeLayers[0];
    if (!layer) {
      throw new Error("请先选择一个图层。");
    }
    if (layer.kind !== constants.LayerKind.NORMAL) {
      throw new Error("第一版只支持像素图层。");
    }

    const layerInfo = {
      documentID: document.id,
      layerID: layer.id,
      name: layer.name,
      bounds: toBounds(layer.boundsNoEffects || layer.bounds)
    };
    layerRefs.set(layerKey(layerInfo), layer);
    return { ...layerInfo };
  }

  async function readLayerPixels(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    assertLayerIsActive(normalized);
    if (!imaging || typeof imaging.getPixels !== "function") {
      throw new Error("Photoshop imaging.getPixels API 不可用。");
    }
    // Keep pixel acquisition in the same modal scope as mask access. This is
    // required by current Photoshop builds and remains compatible with older
    // UXP hosts.
    const result = await executeModal(() => imaging.getPixels({
      documentID: normalized.documentID,
      layerID: normalized.layerID,
      sourceBounds: {
        left: normalized.bounds.left,
        top: normalized.bounds.top,
        right: normalized.bounds.right,
        bottom: normalized.bounds.bottom
      },
      colorSpace: "RGB",
      componentSize: 8,
      applyAlpha: false
    }), "读取 Photoshop 图层像素");
    if (!result || !result.imageData) {
      throw new Error("Photoshop 返回了无效的图层像素数据。");
    }
    const imageData = result.imageData;
    try {
      const width = Number(imageData.width);
      const height = Number(imageData.height);
      const components = Number(imageData.components);
      const componentSize = imageData.componentSize ?? imageData.bitsPerChannel;
      if (componentSize !== undefined && Number(componentSize) !== 8) {
        throw new Error("Photoshop 图层像素必须是 8-bit 数据。");
      }
      if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1) {
        throw new Error("Photoshop 返回了无效的图层像素尺寸。");
      }
      if (!Number.isSafeInteger(width * height) || width * height > MAX_LOCAL_PIXELS) {
        throw new Error("当前图层超过 16,777,216 像素的本地处理上限，请先缩小图层或分区处理。");
      }
      if (components !== 3 && components !== 4) {
        throw new Error("Photoshop 图层像素必须是 RGB 或 RGBA 数据。");
      }
      const data = await imageData.getData({ chunky: true });
      const copy = copy8BitData(data, width * height * components, "Photoshop 图层像素数据长度不正确。");
      const bounds = toBounds(result.sourceBounds || normalized.bounds);
      if (bounds.width !== width || bounds.height !== height) {
        throw new Error("Photoshop 图层像素尺寸与来源边界不一致。");
      }
      return {
        pixels: copy,
        width,
        height,
        components,
        bounds
      };
    } finally {
      if (typeof imageData.dispose === "function") imageData.dispose();
    }
  }

  async function legacyPutLayerMask(layerInfo, alpha) {
    const expectedLength = layerInfo.bounds.width * layerInfo.bounds.height;
    if (!(alpha instanceof Uint8Array) || alpha.length !== expectedLength) {
      throw new Error("蒙版尺寸与图层边界不一致。");
    }

    await executeModal(async () => {
      const maskData = await imaging.createImageDataFromBuffer(alpha, {
        width: layerInfo.bounds.width,
        height: layerInfo.bounds.height,
        components: 1,
        chunky: false,
        colorProfile: "Gray Gamma 2.2",
        colorSpace: "Grayscale"
      });

      try {
        await imaging.putLayerMask({
          documentID: layerInfo.documentID,
          layerID: layerInfo.layerID,
          kind: "user",
          imageData: maskData,
          replace: true,
          targetBounds: {
            left: layerInfo.bounds.left,
            top: layerInfo.bounds.top
          },
          commandName: "应用离线抠图蒙版"
        });
      } finally {
        maskData.dispose();
      }
    }, "应用离线抠图蒙版");
  }

  // Keep the original method name as a committed-write API while routing it
  // through the validated writer used by temporary previews.
  async function putLayerMask(layerInfo, alpha) {
    const normalized = normalizedLayerInfo(layerInfo);
    const copy = await writeLayerMask(normalized, alpha);
    const key = layerKey(normalized);
    maskSnapshots.delete(key);
    if (activePreviewKey === key) {
      activePreviewKey = null;
      activePreviewLayerInfo = null;
    }
    return copy;
  }

  async function previewLayerMask(layerInfo, alpha) {
    const normalized = normalizedLayerInfo(layerInfo);
    const copy = copyAlpha(alpha, normalized);
    const key = layerKey(normalized);
    let snapshot = maskSnapshots.get(key);
    let createdSnapshot = false;
    if (!snapshot) {
      snapshot = await readLayerMask(normalized);
      snapshot = maskSnapshotCopy(snapshot);
      maskSnapshots.set(key, snapshot);
      createdSnapshot = true;
    }
    // A layer without a mask needs a reversible remove operation after the
    // preview creates one. Refuse to write if no such operation was injected.
    if (!snapshot.present && !canRemoveLayerMask(normalized)) {
      if (createdSnapshot) maskSnapshots.delete(key);
      throw new Error("无法安全预览无原始图层蒙版的图层，请注入 action.batchPlay。");
    }

    try {
      await writeLayerMask(normalized, copy);
    } catch (error) {
      if (createdSnapshot) maskSnapshots.delete(key);
      throw error;
    }
    activePreviewKey = key;
    activePreviewLayerInfo = normalized;
    return {
      previewing: true,
      documentID: normalized.documentID,
      layerID: normalized.layerID,
      width: normalized.bounds.width,
      height: normalized.bounds.height,
      bounds: { ...normalized.bounds },
      alpha: new Uint8Array(copy),
      original: maskSnapshotCopy(snapshot)
    };
  }

  async function cancelMaskPreview(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo || activePreviewLayerInfo);
    const key = layerKey(normalized);
    const snapshot = maskSnapshots.get(key);
    if (!snapshot) {
      if (activePreviewKey === key) {
        activePreviewKey = null;
        activePreviewLayerInfo = null;
      }
      return {
        restored: false,
        previewing: false,
        documentID: normalized.documentID,
        layerID: normalized.layerID
      };
    }
    await restoreLayerMask(normalized, snapshot);
    maskSnapshots.delete(key);
    if (activePreviewKey === key) {
      activePreviewKey = null;
      activePreviewLayerInfo = null;
    }
    return { restored: true, previewing: false, original: maskSnapshotCopy(snapshot) };
  }

  async function applyLayerMask(layerInfo, alpha) {
    const normalized = normalizedLayerInfo(layerInfo);
    const copy = await writeLayerMask(normalized, alpha);
    const key = layerKey(normalized);
    maskSnapshots.delete(key);
    if (activePreviewKey === key) {
      activePreviewKey = null;
      activePreviewLayerInfo = null;
    }
    return {
      applied: true,
      documentID: normalized.documentID,
      layerID: normalized.layerID,
      width: normalized.bounds.width,
      height: normalized.bounds.height,
      bounds: { ...normalized.bounds },
      alpha: new Uint8Array(copy)
    };
  }

  return {
    getActivePixelLayer,
    readLayerPixels,
    putLayerMask,
    readLayerMask,
    saveLayerMask,
    previewLayerMask,
    cancelMaskPreview,
    applyLayerMask,
    readUserMask: readLayerMask,
    saveOriginalLayerMask: saveLayerMask,
    previewAlpha: previewLayerMask,
    cancelPreview: cancelMaskPreview,
    applyMask: applyLayerMask
  };
}

module.exports = { MAX_LOCAL_PIXELS, createPhotoshopHost, toBounds };
