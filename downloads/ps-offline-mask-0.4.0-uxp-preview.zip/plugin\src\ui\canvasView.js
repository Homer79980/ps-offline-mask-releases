const { calculateFitZoom, clampZoom } = require("./zoom");
const { normalizeWheelDirection } = require("./previewInput");
const { zoomAtPoint } = require("./viewportTransform");

const TRIMAP_COLORS = Object.freeze({
  keep: "rgba(70, 225, 120, 0.43)",
  cut: "rgba(240, 90, 90, 0.45)",
  unknown: "rgba(80, 155, 255, 0.27)"
});

function createCanvasView({ element, state, labels }) {
  function updateZoomUI() {
    const range = element("zoom-range");
    const output = element("zoom-value");
    const percent = Math.round(state.zoom * 100);
    if (range) range.value = String(percent);
    if (output) output.textContent = `${percent}%`;
    ["zoom-out", "zoom-in", "zoom-fit"].forEach((id) => {
      const control = element(id);
      if (control) control.disabled = state.busy || !state.source;
    });
  }

  function applyZoom() {
    const canvas = element("preview-canvas");
    const stack = element("preview-stack");
    if (!canvas || !state.source) return;
    const width = Math.max(1, Math.round(state.source.width * state.zoom));
    const height = Math.max(1, Math.round(state.source.height * state.zoom));
    if (stack) {
      stack.style.width = `${width}px`;
      stack.style.height = `${height}px`;
    } else {
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
    }
    const compareImage = element("preview-compare-image");
    if (compareImage) {
      compareImage.style.width = `${width}px`;
      compareImage.style.height = `${height}px`;
    }
  }

  function setZoom(value, mode = "manual") {
    if (state.busy || !state.source) return state.zoom;
    state.zoom = clampZoom(value, state.zoom);
    state.zoomMode = mode;
    applyZoom();
    updateZoomUI();
    return state.zoom;
  }

  function fitZoom() {
    if (!state.source || state.busy) return;
    const frame = element("canvas-frame");
    if (!frame) return;
    if (Number(frame.clientWidth) <= 0 || Number(frame.clientHeight) <= 0) return;
    setZoom(calculateFitZoom(
      state.source.width,
      state.source.height,
      frame.clientWidth,
      frame.clientHeight
    ), "fit");
  }

  function handleWheel(event) {
    if (!state.source || state.busy) return;
    if (event && typeof event.preventDefault === "function") event.preventDefault();
    const direction = normalizeWheelDirection(event);
    if (direction === 0) return;
    const frame = element("canvas-frame");
    const stack = element("preview-stack");
    const nextZoom = clampZoom(state.zoom * (direction < 0 ? 1.15 : 0.85), state.zoom);
    if (!frame || !stack) {
      setZoom(nextZoom);
      return;
    }
    const rect = typeof frame.getBoundingClientRect === "function"
      ? frame.getBoundingClientRect()
      : { left: 0, top: 0, width: frame.clientWidth, height: frame.clientHeight };
    const pointerX = Number.isFinite(Number(event && event.clientX))
      ? Number(event.clientX) - Number(rect.left || 0)
      : Number(frame.clientWidth || rect.width || 0) / 2;
    const pointerY = Number.isFinite(Number(event && event.clientY))
      ? Number(event.clientY) - Number(rect.top || 0)
      : Number(frame.clientHeight || rect.height || 0) / 2;
    const currentZoom = state.zoom;
    const currentScrollLeft = Number(frame.scrollLeft) || 0;
    const currentScrollTop = Number(frame.scrollTop) || 0;
    const currentStackRect = typeof stack.getBoundingClientRect === "function"
      ? stack.getBoundingClientRect()
      : { left: rect.left, top: rect.top };
    const contentOffsetX = Number(currentStackRect.left || 0) - Number(rect.left || 0) + currentScrollLeft;
    const contentOffsetY = Number(currentStackRect.top || 0) - Number(rect.top || 0) + currentScrollTop;
    setZoom(nextZoom);
    const nextStackRect = typeof stack.getBoundingClientRect === "function"
      ? stack.getBoundingClientRect()
      : currentStackRect;
    const layoutScrollLeft = Number(frame.scrollLeft) || 0;
    const layoutScrollTop = Number(frame.scrollTop) || 0;
    const nextContentOffsetX = Number(nextStackRect.left || 0) - Number(rect.left || 0) + layoutScrollLeft;
    const nextContentOffsetY = Number(nextStackRect.top || 0) - Number(rect.top || 0) + layoutScrollTop;
    const scrollWidth = Number(frame.scrollWidth);
    const scrollHeight = Number(frame.scrollHeight);
    const transformed = zoomAtPoint({
      zoom: currentZoom,
      nextZoom,
      scrollLeft: currentScrollLeft,
      scrollTop: currentScrollTop,
      pointerX,
      pointerY,
      contentOffsetX,
      contentOffsetY,
      nextContentOffsetX,
      nextContentOffsetY,
      contentWidth: state.source.width,
      contentHeight: state.source.height,
      viewportWidth: frame.clientWidth || rect.width,
      viewportHeight: frame.clientHeight || rect.height,
      ...(Number.isFinite(scrollWidth) && scrollWidth > 0
        ? { maxScrollLeft: Math.max(0, scrollWidth - Number(frame.clientWidth || rect.width || 0)) }
        : {}),
      ...(Number.isFinite(scrollHeight) && scrollHeight > 0
        ? { maxScrollTop: Math.max(0, scrollHeight - Number(frame.clientHeight || rect.height || 0)) }
        : {})
    });
    frame.scrollLeft = transformed.scrollLeft;
    frame.scrollTop = transformed.scrollTop;
  }

  function getPoint(event, canvas) {
    const rect = canvas.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left) * (canvas.width / Math.max(1, rect.width)),
      y: (event.clientY - rect.top) * (canvas.height / Math.max(1, rect.height))
    };
  }

  function strokeLine(context, from, to, color, width) {
    context.strokeStyle = color;
    context.lineWidth = Math.max(1, width);
    context.lineCap = "round";
    context.lineJoin = "round";
    context.beginPath();
    context.moveTo(from.x, from.y);
    context.lineTo(to.x, to.y);
    context.stroke();
  }

  function drawLiveStroke(from, to) {
    const canvas = element("preview-canvas");
    if (!canvas || !from || !to) return;
    const context = canvas.getContext("2d");
    if (!context) return;
    const color = state.tool === "keep"
      ? TRIMAP_COLORS.keep
      : state.tool === "cut"
        ? TRIMAP_COLORS.cut
        : TRIMAP_COLORS.unknown;
    if (typeof context.save === "function") context.save();
    const softness = Math.min(1, Math.max(0, Number(state.brushSoftness) || 0));
    if (state.tool !== "unknown" && softness > 0) {
      strokeLine(context, from, to, TRIMAP_COLORS.unknown, state.brushSize);
      strokeLine(context, from, to, color, Math.max(1, state.brushSize * (1 - softness)));
    } else {
      strokeLine(context, from, to, color, state.brushSize);
    }
    if (typeof context.restore === "function") context.restore();
  }

  function colorForLabel(label) {
    if (label === labels.KEEP) return TRIMAP_COLORS.keep;
    if (label === labels.CUT) return TRIMAP_COLORS.cut;
    if (label === labels.UNKNOWN) return TRIMAP_COLORS.unknown;
    return null;
  }

  function drawTrimapOverlay(context) {
    if (!state.trimap || typeof context.fillRect !== "function") return;
    if (typeof context.save === "function") context.save();
    for (let y = 0; y < state.trimap.height; y += 1) {
      let runLabel = null;
      let runStart = 0;
      for (let x = 0; x <= state.trimap.width; x += 1) {
        const index = y * state.trimap.width + x;
        const label = x < state.trimap.width && state.trimap.painted[index]
          ? state.trimap.data[index]
          : null;
        if (label === runLabel) continue;
        if (runLabel !== null) {
          const color = colorForLabel(runLabel);
          if (color) {
            context.fillStyle = color;
            context.fillRect(runStart, y, x - runStart, 1);
          }
        }
        runLabel = label;
        runStart = x;
      }
    }
    if (typeof context.restore === "function") context.restore();
  }

  function draw() {
    const canvas = element("preview-canvas");
    const image = element("preview-image");
    const compareLayer = element("preview-compare-layer");
    const compareImage = element("preview-compare-image");
    const compareDivider = element("preview-compare-divider");
    const stack = element("preview-stack");
    const placeholder = element("canvas-placeholder");
    if (!canvas || !placeholder) return;
    if (!state.source) {
      placeholder.textContent = "请选择一个像素图层";
      placeholder.style.display = "block";
      if (image) image.style.display = "none";
      if (compareLayer) compareLayer.style.display = "none";
      if (compareDivider) compareDivider.style.display = "none";
      if (stack) {
        stack.style.width = "1px";
        stack.style.height = "1px";
      }
      canvas.width = 1;
      canvas.height = 1;
      canvas.style.width = "1px";
      canvas.style.height = "1px";
      updateZoomUI();
      return;
    }

    const viewMode = String(state.viewMode || "");
    const cutoutPreviewUrls = state.cutoutPreviewUrls || {};
    const compareResultUrl = state.cutoutPreviewImageUrl
      || cutoutPreviewUrls["cutout-transparent"]
      || cutoutPreviewUrls.transparent;
    const selectedCutoutUrl = viewMode.startsWith("cutout-")
      ? cutoutPreviewUrls[viewMode] || cutoutPreviewUrls[viewMode.slice("cutout-".length)]
      : null;
    const previewImageUrl = viewMode === "mask"
      ? state.maskPreviewImageUrl
      : viewMode === "result"
        ? compareResultUrl
        : viewMode === "compare"
          ? compareResultUrl
          : selectedCutoutUrl || state.sourcePreviewImageUrl || state.previewImageUrl;
    const hasRaster = typeof previewImageUrl === "string" && previewImageUrl.length > 0;
    placeholder.textContent = hasRaster
      ? ""
      : "当前 UXP 主机未生成预览图，结果仍显示在 Photoshop 画布";
    placeholder.style.display = hasRaster ? "none" : "block";
    if (image) {
      if (image.src !== previewImageUrl) image.src = previewImageUrl || "";
      image.style.display = hasRaster ? "block" : "none";
    }
    const compareSourceUrl = state.sourcePreviewImageUrl || state.previewImageUrl;
    const showCompare = viewMode === "compare"
      && hasRaster
      && typeof compareSourceUrl === "string"
      && compareSourceUrl.length > 0;
    if (compareLayer) compareLayer.style.display = showCompare ? "block" : "none";
    if (compareImage) {
      if (compareImage.src !== compareSourceUrl) compareImage.src = compareSourceUrl || "";
      compareImage.style.display = showCompare ? "block" : "none";
    }
    if (compareDivider) compareDivider.style.display = showCompare ? "block" : "none";
    if (canvas.width !== state.source.width) canvas.width = state.source.width;
    if (canvas.height !== state.source.height) canvas.height = state.source.height;
    applyZoom();
    const context = canvas.getContext("2d");
    if (!context) return;
    if (typeof context.clearRect === "function") context.clearRect(0, 0, canvas.width, canvas.height);
    if (viewMode === "mark") drawTrimapOverlay(context);
  }

  return Object.freeze({ draw, drawLiveStroke, fitZoom, getPoint, handleWheel, setZoom, updateZoomUI });
}

module.exports = { createCanvasView };
