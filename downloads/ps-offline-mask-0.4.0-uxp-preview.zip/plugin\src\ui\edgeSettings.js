function clamp(value, minimum, maximum) {
  return Math.min(maximum, Math.max(minimum, value));
}

function quantize(value, step, minimum, maximum) {
  const numeric = Number.isFinite(Number(value)) ? Number(value) : 0;
  return clamp(Math.round(numeric / step) * step, minimum, maximum);
}

function normalizeEdgeSettings(settings = {}, changedKey = null) {
  const normalized = {
    edgeShift: quantize(settings.edgeShift, 10, -100, 100),
    feather: quantize(settings.feather, 25, 0, 100),
    hardThreshold: quantize(settings.hardThreshold, 1, 0, 255)
  };
  if (normalized.feather > 0 && normalized.hardThreshold > 0) {
    if (changedKey === "hardThreshold") normalized.feather = 0;
    else normalized.hardThreshold = 0;
  }
  return normalized;
}

function edgeSettingLabels(settings = {}) {
  const normalized = normalizeEdgeSettings(settings);
  const shiftPixels = normalized.edgeShift / 10;
  return {
    edgeShift: `${shiftPixels > 0 ? "+" : ""}${shiftPixels} px`,
    feather: normalized.feather === 0 ? "关闭" : `${normalized.feather / 25} px`,
    hardThreshold: normalized.hardThreshold === 0 ? "关闭" : String(normalized.hardThreshold)
  };
}

module.exports = { edgeSettingLabels, normalizeEdgeSettings };
