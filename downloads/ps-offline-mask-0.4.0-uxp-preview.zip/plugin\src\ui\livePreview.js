function canReuseForegroundForEdgePreview(foregroundSource, options = {}) {
  return foregroundSource === "local-decontamination" && options.invert !== true;
}

function scaleEdgeOptionsForPreview(options = {}, scale = 1) {
  const ratio = Math.max(0, Math.min(1, Number(scale) || 0));
  const edgeShift = Number(options.edgeShift) || 0;
  const edgeRadius = Math.round(Math.abs(edgeShift) / 10);
  const scaledEdgeRadius = Math.round(edgeRadius * ratio);
  const featherRadius = Math.min(4, Math.round((Number(options.feather) || 0) / 25));
  const scaledFeatherRadius = Math.round(featherRadius * ratio);
  return {
    ...options,
    edgeShift: Math.sign(edgeShift) * scaledEdgeRadius * 10,
    feather: scaledFeatherRadius * 25
  };
}

function createLivePreviewScheduler(options = {}) {
  const delay = Math.max(0, Number(options.delay) || 120);
  const setTimer = options.setTimer || setTimeout;
  const clearTimer = options.clearTimer || clearTimeout;
  const eligible = typeof options.eligible === "function" ? options.eligible : () => true;
  const readValue = typeof options.readValue === "function" ? options.readValue : () => undefined;
  const run = typeof options.run === "function" ? options.run : async () => undefined;
  const publish = typeof options.publish === "function" ? options.publish : () => undefined;
  const publishIntermediate = typeof options.publishIntermediate === "function"
    ? options.publishIntermediate
    : () => undefined;
  const onError = typeof options.onError === "function" ? options.onError : () => undefined;
  let timer = null;
  let inFlight = Promise.resolve();
  let controller = null;
  let revision = 0;

  function clearPendingTimer() {
    if (timer === null) return false;
    clearTimer(timer);
    timer = null;
    return true;
  }

  function cancel() {
    revision += 1;
    const cleared = clearPendingTimer();
    const aborted = Boolean(controller && !controller.signal.aborted);
    if (aborted) controller.abort();
    controller = null;
    return cleared || aborted;
  }

  function schedule() {
    revision += 1;
    const scheduledRevision = revision;
    if (controller && !controller.signal.aborted) controller.abort();
    controller = null;
    if (!eligible()) {
      clearPendingTimer();
      return false;
    }
    clearPendingTimer();
    timer = setTimer(() => {
      timer = null;
      if (scheduledRevision !== revision || !eligible()) return;
      const value = readValue();
      const activeController = typeof AbortController === "function" ? new AbortController() : null;
      controller = activeController;
      const emitIntermediate = (result) => {
        if (scheduledRevision !== revision || !eligible()) return false;
        if (activeController && activeController.signal.aborted) return false;
        publishIntermediate(result, value);
        return true;
      };
      try {
        inFlight = Promise.resolve(run(
          value,
          scheduledRevision,
          activeController ? activeController.signal : undefined,
          emitIntermediate
        )).then(
          (result) => {
            if (controller === activeController) controller = null;
            if (scheduledRevision === revision && eligible()) publish(result, value);
            return result;
          },
          (error) => {
            if (controller === activeController) controller = null;
            const canceled = Boolean(activeController && activeController.signal.aborted)
              || Boolean(error && (error.name === "AbortError" || error.code === "canceled"));
            if (!canceled && scheduledRevision === revision && eligible()) onError(error);
            return undefined;
          }
        );
      } catch (error) {
        if (controller === activeController) controller = null;
        const canceled = Boolean(activeController && activeController.signal.aborted)
          || Boolean(error && (error.name === "AbortError" || error.code === "canceled"));
        if (!canceled && scheduledRevision === revision && eligible()) onError(error);
        inFlight = Promise.resolve(undefined);
      }
    }, delay);
    return true;
  }

  return Object.freeze({
    cancel,
    schedule,
    settled() {
      return inFlight;
    },
    get pending() {
      return timer !== null;
    }
  });
}

module.exports = {
  canReuseForegroundForEdgePreview,
  createLivePreviewScheduler,
  scaleEdgeOptionsForPreview
};
