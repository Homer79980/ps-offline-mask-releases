const { entrypoints, host: uxpHost, storage: uxpStorage } = require("uxp");
const photoshop = require("photoshop");
const { app, constants, imaging, core, action } = photoshop;
// index.html loads this file as a root-level UXP script. Keep these imports
// rooted at src/ so UXP resolves them the same way as the packaged plugin.
const { TrimapRaster, LABELS } = require("./src/core/trimap");
const { createEngine } = require("./src/core/engine");
const { applyAlphaPostProcessingAsync, applySourceAlphaLimitAsync } = require("./src/core/alpha");
const { autoTrimapAsync, prepareAutoTrimapForEngine } = require("./src/core/autoTrimap");
const { runBatchCutout } = require("./src/core/batchCutout");
const {
  buildFolderBatchReport,
  createNumberedOutputFile,
  ensureOutputFolder,
  folderBatchOptionsForPreset,
  runFolderBatch,
  scanSourceFolder
} = require("./src/core/folderBatch");
const { createPhotoshopHost, formatHostError } = require("./src/host/photoshopHost");
const {
  createFolderBatchHost,
  createPhotoshopFolderBatchDocumentAdapter
} = require("./src/host/folderBatchHost");
const { createRequestId, DEFAULT_TIMEOUT_MS, VisionApiError } = require("./src/core/visionApi");
const { createFrameScheduler } = require("./src/ui/frameScheduler");
const { createListenerRegistry } = require("./src/ui/listenerRegistry");
const { createCanvasView } = require("./src/ui/canvasView");
const { createMaskPreviewPixels, encodePngDataUrl, scalePreviewPixels } = require("./src/ui/previewImage");
const { createCutoutPreview } = require("./src/ui/cutoutPreview");
const { createSelectionSync } = require("./src/ui/selectionSync");
const { brushRingGeometry, clampBrushSize } = require("./src/ui/brushSettings");
const { createWheelInputRouter } = require("./src/ui/previewInput");
const { createEditSession } = require("./src/ui/editSession");
const { createRefineInteraction, isPrimaryButton } = require("./src/ui/refineInteraction");
const { selectQuickPreview } = require("./src/ui/quickPreview");
const { createUxpInputProbe } = require("./src/ui/uxpInputProbe");
const { normalizePointerEvent, shortcutFromKeyboard } = require("./src/ui/refineInputAdapter");
const { createTrimapHistory } = require("./src/ui/trimapHistory");
const { createWorkspaceHistory } = require("./src/ui/workspaceHistory");
const { createParameterGesture } = require("./src/ui/parameterGesture");
const { edgeSettingLabels, normalizeEdgeSettings } = require("./src/ui/edgeSettings");
const {
  canReuseForegroundForEdgePreview,
  createLivePreviewScheduler,
  scaleEdgeOptionsForPreview
} = require("./src/ui/livePreview");

const runtimeVisionConfig = typeof globalThis !== "undefined" ? globalThis.__PS_MASK_VISION_API__ : null;
let visionConfigError = null;
let visionClientConfig = null;
if (runtimeVisionConfig && typeof runtimeVisionConfig === "object") {
  visionClientConfig = runtimeVisionConfig;
}

let engine;
try {
  engine = createEngine({
    visionApi: visionClientConfig || undefined,
    requireFn: require
  });
} catch (error) {
  visionConfigError = error;
  engine = createEngine({ requireFn: require });
}
const folderBatchEngine = createEngine({ mode: "algorithm", requireFn: require });
const host = createPhotoshopHost({
  app,
  constants,
  imaging,
  core,
  action,
  hostVersion: uxpHost && uxpHost.version
});
let folderHost = null;
try {
  folderHost = createFolderBatchHost({
    storage: uxpStorage && uxpStorage.localFileSystem,
    documentAdapter: createPhotoshopFolderBatchDocumentAdapter({ app, imaging, core, constants })
  });
} catch (error) {
  folderHost = null;
}
const VISION_STATES = Object.freeze({
  NOT_CONFIGURED: "not-configured",
  PENDING_CONSENT: "pending-consent",
  READY: "ready",
  PREPARING: "preparing",
  UPLOADING: "uploading",
  PROCESSING: "processing",
  PREVIEW: "preview",
  CANCELED: "canceled",
  RETRYABLE_ERROR: "retryable-error",
  NONRETRYABLE_ERROR: "nonretryable-error",
  APPLIED: "applied"
});
const VISION_STATE_LABELS = Object.freeze({
  [VISION_STATES.NOT_CONFIGURED]: "未配置",
  [VISION_STATES.PENDING_CONSENT]: "等待外发确认",
  [VISION_STATES.READY]: "已就绪",
  [VISION_STATES.PREPARING]: "准备请求",
  [VISION_STATES.UPLOADING]: "请求已发起",
  [VISION_STATES.PROCESSING]: "校验服务结果",
  [VISION_STATES.PREVIEW]: "结果可预览",
  [VISION_STATES.CANCELED]: "已取消",
  [VISION_STATES.RETRYABLE_ERROR]: "失败，可重试",
  [VISION_STATES.NONRETRYABLE_ERROR]: "失败，不可重试",
  [VISION_STATES.APPLIED]: "已应用"
});
const ALGORITHM_PHASE_LABELS = Object.freeze({
  distance: "分析标记",
  infer: "生成蒙版",
  blur: "处理边缘",
  edge: "调整轮廓",
  postprocess: "整理结果"
});
const DEFAULT_MASK_OPTIONS = Object.freeze({
  edgeShift: -10,
  feather: 0,
  hardThreshold: 0,
  invert: false
});
const MAX_PREVIEW_DIMENSION = 2048;
const LIVE_EDGE_PREVIEW_DIMENSION = 1024;
const state = {
  mounted: false,
  mainMounted: false,
  refineMounted: false,
  refineRoot: null,
  drawing: false,
  tool: "unknown",
  lastPaintTool: "unknown",
  brushSize: 32,
  brushSoftness: 0,
  zoom: 1,
  zoomMode: "manual",
  viewMode: "mark",
  layer: null,
  source: null,
  trimap: null,
  alpha: null,
  baseAlpha: null,
  foreground: null,
  foregroundSource: null,
  foregroundUsable: false,
  algorithmBackground: null,
  lastPoint: null,
  engineMode: "algorithm",
  previewActive: false,
  panelPreviewActive: false,
  requestId: null,
  requestController: null,
  previewPromise: null,
  previewCanceling: false,
  restoreFailed: false,
  cancelRequested: false,
  busy: false,
  busyOperation: null,
  lastOperation: null,
  lastError: null,
  retryPendingConfirmation: false,
  resultEngine: null,
  requiresLowConfidenceConfirmation: false,
  lowConfidenceApplyArmed: false,
  optionsDirty: false,
  maskOptions: { ...DEFAULT_MASK_OPTIONS },
  visionState: VISION_STATES.NOT_CONFIGURED,
  visionDataExported: false,
  operationToken: 0,
  panelGeneration: 0,
  activeListenerRegistry: null,
  mainListenerRegistry: null,
  refineListenerRegistry: null,
  activeOperations: new Set(),
  lifecycleWaiting: false,
  paintScheduler: null,
  edgePreviewScheduler: null,
  resizeObserver: null,
  sourcePreviewImageUrl: null,
  maskPreviewImageUrl: null,
  cutoutPreviewImageUrl: null,
  cutoutPreviewUrls: Object.create(null),
  previewBackgroundColor: "#808080",
  trimapDirty: false,
  trimapHistory: null,
  workspaceHistory: createWorkspaceHistory(),
  pendingPaintPointerId: null,
  trimapRenderVersion: 0,
  workDirty: false,
  previewPointerInside: false,
  lastPreviewClientPoint: null,
  lastSurfaceMoveEvent: null,
  lastSurfaceEndEvent: null,
  refineInteraction: null,
  wheelInputRouter: null,
  refineBaselinePreviewActive: false,
  selectionSync: null,
  notificationEvents: null,
  notificationHandler: null,
  notificationRegistered: false,
  notificationToken: 0,
  shutdownPromise: null,
  refineSessionPromise: null,
  refineDialogPromise: null,
  refineDialogSettlement: null,
  refineDialogToken: 0,
  refineDialogOpen: false,
  refineDialogAction: null,
  workspaceReadOnly: false,
  refineInputProbe: null,
  refineInputCapability: "untested",
  lastShortcutEvent: null,
  selectionRefreshPending: false,
  folderSource: null,
  folderOutput: null,
  folderBatchController: null,
  folderBatchDialogOpen: false,
  folderBatchReport: null,
  folderScanToken: 0,
  qualityDiagnostics: null,
  automaticDraftSnapshot: null,
  edgePreviewStage: "idle",
  edgePreviewDraft: null
};

function resetWorkspaceHistory() {
  state.workspaceHistory = createWorkspaceHistory({
    limit: state.trimapHistory ? state.trimapHistory.capacity : 50
  });
}

function cloneTrimap(trimap) {
  if (!trimap) return null;
  const copy = new TrimapRaster(trimap.width, trimap.height, trimap.data);
  copy.painted.set(trimap.painted);
  return copy;
}

function cloneAlgorithmBackground(background) {
  if (!background || !Array.isArray(background.color)) return null;
  return { ...background, color: background.color.slice() };
}

function cloneRefineSnapshot(snapshot) {
  if (!snapshot) return null;
  return {
    trimap: cloneTrimap(snapshot.trimap),
    alpha: snapshot.alpha ? new Uint8Array(snapshot.alpha) : null,
    baseAlpha: snapshot.baseAlpha ? new Uint8Array(snapshot.baseAlpha) : null,
    foreground: snapshot.foreground ? new Uint8Array(snapshot.foreground) : null,
    foregroundSource: snapshot.foregroundSource || null,
    foregroundUsable: Boolean(snapshot.foregroundUsable),
    algorithmBackground: cloneAlgorithmBackground(snapshot.algorithmBackground),
    maskPreviewImageUrl: snapshot.maskPreviewImageUrl || null,
    cutoutPreviewImageUrl: snapshot.cutoutPreviewImageUrl || null,
    cutoutPreviewUrls: { ...(snapshot.cutoutPreviewUrls || {}) },
    previewBackgroundColor: snapshot.previewBackgroundColor || "#808080",
    maskOptions: { ...(snapshot.maskOptions || DEFAULT_MASK_OPTIONS) },
    trimapDirty: Boolean(snapshot.trimapDirty),
    panelPreviewActive: Boolean(snapshot.panelPreviewActive),
    previewActive: Boolean(snapshot.previewActive),
    resultEngine: snapshot.resultEngine || null,
    requiresLowConfidenceConfirmation: Boolean(snapshot.requiresLowConfidenceConfirmation),
    lowConfidenceApplyArmed: Boolean(snapshot.lowConfidenceApplyArmed),
    optionsDirty: Boolean(snapshot.optionsDirty),
    workDirty: Boolean(snapshot.workDirty),
    viewMode: snapshot.viewMode || "mark",
    qualityDiagnostics: snapshot.qualityDiagnostics
      ? { ...snapshot.qualityDiagnostics, warnings: [...(snapshot.qualityDiagnostics.warnings || [])] }
      : null
  };
}

function captureRefineSnapshot() {
  return cloneRefineSnapshot(state);
}

function restoreRefineSnapshot(snapshot, { restorePreviewFlag = false } = {}) {
  if (!snapshot) return;
  state.edgePreviewDraft = null;
  state.edgePreviewStage = "idle";
  state.trimap = snapshot.trimap;
  state.trimapHistory = state.trimap ? createTrimapHistory(state.trimap) : null;
  resetWorkspaceHistory();
  state.alpha = snapshot.alpha;
  state.baseAlpha = snapshot.baseAlpha;
  state.foreground = snapshot.foreground;
  state.foregroundSource = snapshot.foregroundSource;
  state.foregroundUsable = snapshot.foregroundUsable;
  state.algorithmBackground = cloneAlgorithmBackground(snapshot.algorithmBackground);
  state.maskPreviewImageUrl = snapshot.maskPreviewImageUrl;
  state.cutoutPreviewImageUrl = snapshot.cutoutPreviewImageUrl;
  state.cutoutPreviewUrls = { ...(snapshot.cutoutPreviewUrls || {}) };
  state.previewBackgroundColor = snapshot.previewBackgroundColor || "#808080";
  state.maskOptions = { ...(snapshot.maskOptions || DEFAULT_MASK_OPTIONS) };
  state.trimapDirty = Boolean(snapshot.trimapDirty);
  state.panelPreviewActive = snapshot.panelPreviewActive;
  state.previewActive = restorePreviewFlag && snapshot.previewActive;
  state.resultEngine = snapshot.resultEngine;
  state.requiresLowConfidenceConfirmation = snapshot.requiresLowConfidenceConfirmation;
  state.lowConfidenceApplyArmed = snapshot.lowConfidenceApplyArmed;
  state.optionsDirty = snapshot.optionsDirty;
  state.workDirty = snapshot.workDirty;
  state.viewMode = snapshot.viewMode;
  state.qualityDiagnostics = snapshot.qualityDiagnostics
    ? { ...snapshot.qualityDiagnostics, warnings: [...(snapshot.qualityDiagnostics.warnings || [])] }
    : null;
  state.trimapRenderVersion += 1;
  syncEdgeOptionsUI();
  updateQualityStatus();
  const viewMode = element("view-mode");
  if (viewMode) viewMode.value = state.viewMode;
}

const refineEditSession = createEditSession({ clone: cloneRefineSnapshot });
const edgeParameterGesture = createParameterGesture({
  clone: (value) => ({ ...(value || {}) }),
  equals: (left, right) => JSON.stringify(left) === JSON.stringify(right)
});

function syncRefineWorkingSnapshot() {
  const working = refineEditSession.working;
  if (!working) return;
  Object.assign(working, captureRefineSnapshot());
}

function element(id) {
  return document.getElementById(id);
}

const canvasView = createCanvasView({ element, state, labels: LABELS });
const {
  draw: drawRefineCanvas,
  drawLiveStroke,
  fitZoom: fitZoomToWindow,
  getPoint: getCanvasPoint,
  handleWheel: handlePreviewWheel,
  setZoom,
  updateZoomUI
} = canvasView;

function renderQuickPreview() {
  const image = element("quick-preview-image");
  const placeholder = element("quick-preview-placeholder");
  const label = element("quick-preview-label");
  if (!image || !placeholder || !label) return;

  const preview = selectQuickPreview(state);
  label.textContent = preview.label;
  placeholder.textContent = preview.emptyText;
  placeholder.hidden = Boolean(preview.url);
  image.hidden = !preview.url;
  if (preview.url) {
    if (image.src !== preview.url) image.src = preview.url;
  } else {
    image.removeAttribute("src");
  }
}

function parsePreviewColor(value) {
  const match = /^#([0-9a-f]{6})$/i.exec(String(value || ""));
  if (!match) return [128, 128, 128];
  const packed = Number.parseInt(match[1], 16);
  return [(packed >> 16) & 255, (packed >> 8) & 255, packed & 255];
}

function previewBackgroundForMode(mode) {
  if (mode === "cutout-white") return "white";
  if (mode === "cutout-black") return "black";
  if (mode === "cutout-gray") return "gray";
  if (mode === "cutout-custom") return { color: parsePreviewColor(state.previewBackgroundColor) };
  return "transparent";
}

function currentPreviewRaster() {
  if (state.edgePreviewDraft && state.edgePreviewDraft.source
    && state.edgePreviewDraft.alpha instanceof Uint8Array) {
    return state.edgePreviewDraft;
  }
  if (!state.source || !(state.alpha instanceof Uint8Array)) return null;
  const source = scalePreviewPixels(state.source, MAX_PREVIEW_DIMENSION);
  const alpha = scalePreviewPixels({
    pixels: state.alpha,
    width: state.source.width,
    height: state.source.height,
    components: 1
  }, MAX_PREVIEW_DIMENSION).pixels;
  const foreground = state.foregroundUsable && state.foreground instanceof Uint8Array
    ? scalePreviewPixels({
      pixels: state.foreground,
      width: state.source.width,
      height: state.source.height,
      components: 3
    }, MAX_PREVIEW_DIMENSION).pixels
    : null;
  return { source, alpha, foreground, foregroundUsable: Boolean(foreground) };
}

function hasPreviewRaster() {
  return Boolean(
    state.edgePreviewDraft && state.edgePreviewDraft.source
      && state.edgePreviewDraft.alpha instanceof Uint8Array
  ) || Boolean(state.source && state.alpha instanceof Uint8Array);
}

function createCutoutPreviewUrl(background = "transparent") {
  const raster = currentPreviewRaster();
  if (!raster) return null;
  const preview = createCutoutPreview({
    source: raster.source,
    alpha: raster.alpha,
    foreground: raster.foreground,
    foregroundUsable: Boolean(raster.foregroundUsable),
    background
  });
  return encodePngDataUrl(preview);
}

function createMaskPreviewUrl() {
  const raster = currentPreviewRaster();
  if (!raster) return null;
  return encodePngDataUrl({
    pixels: createMaskPreviewPixels(raster.alpha),
    width: raster.source.width,
    height: raster.source.height,
    components: 3
  });
}

function ensureCutoutPreviewMode(mode) {
  if (!String(mode || "").startsWith("cutout-") || !hasPreviewRaster()) return null;
  const keep = Object.create(null);
  const transparent = state.cutoutPreviewUrls && state.cutoutPreviewUrls["cutout-transparent"];
  if (transparent) keep["cutout-transparent"] = transparent;
  let url = state.cutoutPreviewUrls && state.cutoutPreviewUrls[mode];
  if (!url) {
    try { url = createCutoutPreviewUrl(previewBackgroundForMode(mode)); } catch (error) { url = null; }
  }
  if (url) keep[mode] = url;
  state.cutoutPreviewUrls = keep;
  if (mode === "cutout-transparent") state.cutoutPreviewImageUrl = url;
  return url;
}

function ensurePreviewForView(mode) {
  if (mode === "mask" && !state.maskPreviewImageUrl && hasPreviewRaster()) {
    try { state.maskPreviewImageUrl = createMaskPreviewUrl(); } catch (error) { state.maskPreviewImageUrl = null; }
  }
  if (mode === "compare") ensureCutoutPreviewMode("cutout-transparent");
  else if (String(mode || "").startsWith("cutout-")) ensureCutoutPreviewMode(mode);
}

function refreshGeneratedPreviewImages() {
  if (!state.source || !(state.alpha instanceof Uint8Array)) {
    state.maskPreviewImageUrl = null;
    state.cutoutPreviewImageUrl = null;
    state.cutoutPreviewUrls = Object.create(null);
    return;
  }
  state.maskPreviewImageUrl = null;
  state.cutoutPreviewUrls = Object.create(null);
  state.cutoutPreviewImageUrl = ensureCutoutPreviewMode("cutout-transparent");
  ensurePreviewForView(state.viewMode);
}

function draw() {
  drawRefineCanvas();
  drawBrushCursorCanvas();
  renderQuickPreview();
}

function isCurrentPanel(generation) {
  return state.mounted && state.panelGeneration === generation;
}

function canUseMainPanel(generation) {
  return state.mainMounted && isCurrentPanel(generation);
}

function finishLifecycleWait() {
  if (!state.mounted || !state.lifecycleWaiting) return;
  if (state.previewCanceling || state.previewPromise || state.activeOperations.size > 0) return;
  state.lifecycleWaiting = false;
  if (!state.restoreFailed) clearLoadedLayerState();
  setBusy(false);
  setMessage(state.restoreFailed
    ? "旧蒙版预览尚未恢复；请点击“重试恢复原蒙版”。"
    : "上一次 Photoshop 操作已安全结束，请重新读取当前图层。", state.restoreFailed);
}

function trackOperation(operation) {
  const promise = Promise.resolve(operation);
  state.activeOperations.add(promise);
  const settled = () => {
    state.activeOperations.delete(promise);
    finishLifecycleWait();
  };
  promise.then(settled, settled);
  return promise;
}

function listen(target, type, handler, options) {
  if (!state.activeListenerRegistry || !target) return false;
  try {
    return state.activeListenerRegistry.add(target, type, handler, options);
  } catch (error) {
    return false;
  }
}

function resetRefineInteractionState() {
  edgeParameterGesture.cancel();
  state.drawing = false;
  state.pendingPaintPointerId = null;
  state.previewPointerInside = false;
  state.lastPreviewClientPoint = null;
  state.lastSurfaceMoveEvent = null;
  state.lastSurfaceEndEvent = null;
  state.lastShortcutEvent = null;
  if (state.refineInteraction) state.refineInteraction.reset();
  state.lastPoint = null;
  if (state.paintScheduler) state.paintScheduler.cancel();
  hideBrushCursor();
  syncPreviewPanClasses();
}

function cleanupRefineDialog() {
  if (state.refineListenerRegistry) state.refineListenerRegistry.clear();
  state.refineListenerRegistry = null;
  resetRefineInteractionState();
  releaseBrushCursorCanvas();
  state.refineMounted = false;
  state.refineInteraction = null;
  state.wheelInputRouter = null;
  state.paintScheduler = null;
  if (state.resizeObserver) state.resizeObserver.disconnect();
  state.resizeObserver = null;
  state.refineRoot = null;
  state.refineDialogOpen = false;
  state.refineDialogPromise = null;
  state.refineDialogSettlement = null;
  state.refineDialogToken += 1;
  state.refineDialogAction = null;
}

function cleanupMainPanel() {
  if (state.mainListenerRegistry) state.mainListenerRegistry.clear();
  state.mainListenerRegistry = null;
  state.mainMounted = false;
  if (state.edgePreviewScheduler) state.edgePreviewScheduler.cancel();
}

async function settleActiveOperations() {
  const pending = Array.from(state.activeOperations);
  if (!pending.length) return;
  await Promise.all(pending.map((operation) => Promise.resolve(operation).catch(() => undefined)));
}

async function shutdownWorkspace() {
  if (!state.mounted) return state.shutdownPromise || true;
  if (state.shutdownPromise) return state.shutdownPromise;
  const previewLayer = state.layer;
  const pendingPreview = state.previewPromise;
  const shouldRestorePreview = Boolean(state.previewActive || pendingPreview);
  state.operationToken += 1;
  state.cancelRequested = true;
  if (state.folderBatchController) state.folderBatchController.abort();
  if (state.requestController) state.requestController.abort();
  if (state.selectionSync) state.selectionSync.dispose();
  state.selectionSync = null;
  unregisterPhotoshopNotifications();
  state.mounted = false;
  state.panelGeneration += 1;
  state.lifecycleWaiting = false;
  state.busy = false;
  state.busyOperation = null;
  state.requestController = null;
  closeRefineDialog("shutdown");
  closeFolderBatchDialog();
  cleanupRefineDialog();
  cleanupMainPanel();
  if (refineEditSession.active) refineEditSession.cancel();
  state.refineBaselinePreviewActive = false;

  const cleanup = (async () => {
    await settleActiveOperations();
    if (pendingPreview) {
      try { await pendingPreview; } catch (error) { /* cleanup continues below */ }
    }
    if (shouldRestorePreview && previewLayer && typeof host.cancelMaskPreview === "function") {
      try {
        await host.cancelMaskPreview(previewLayer);
        state.previewActive = false;
        state.restoreFailed = false;
      } catch (error) {
        state.restoreFailed = true;
      }
    }
    state.cancelRequested = false;
    return !state.restoreFailed;
  })();
  state.shutdownPromise = cleanup;
  cleanup.then(
    () => { if (state.shutdownPromise === cleanup) state.shutdownPromise = null; },
    () => { if (state.shutdownPromise === cleanup) state.shutdownPromise = null; }
  );
  return cleanup;
}

function shutdownWithinLifecycleDeadline(timeoutMs = 250) {
  const cleanup = shutdownWorkspace();
  if (!cleanup || typeof cleanup.then !== "function") return cleanup;
  return Promise.race([
    cleanup,
    new Promise((resolve) => setTimeout(() => resolve(false), timeoutMs))
  ]);
}

async function destroyMainPanel() {
  state.panelGeneration += 1;
  state.operationToken += 1;
  state.cancelRequested = true;
  if (state.folderBatchController) state.folderBatchController.abort();
  if (state.requestController) state.requestController.abort();
  state.requestController = null;
  state.busy = false;
  state.busyOperation = null;
  if (refineEditSession.active) {
    const baseline = refineEditSession.cancel();
    restoreRefineSnapshot(baseline);
  }
  state.refineBaselinePreviewActive = false;
  closeRefineDialog("panel-destroy");
  closeFolderBatchDialog();
  cleanupRefineDialog();
  cleanupMainPanel();
  return true;
}

function clearErrorActions() {
  const actions = element("error-actions");
  if (actions) actions.hidden = true;
  const retry = element("retry-compute");
  if (retry) {
    retry.hidden = false;
    retry.textContent = "重试";
  }
  state.lastError = null;
  state.retryPendingConfirmation = false;
}

function showErrorActions(error) {
  const actions = element("error-actions");
  if (!actions || !(error instanceof VisionApiError)) return;
  const shouldShow = error.category !== "canceled";
  actions.hidden = !shouldShow;
  const retry = element("retry-compute");
  if (retry) retry.hidden = false;
  state.lastError = error;
}

function setMessage(message, isError = false) {
  const node = element("message");
  const refineNode = element("refine-message");
  if (node) {
    node.textContent = message;
    node.style.color = isError ? "#ef746f" : "";
  }
  if (refineNode) {
    refineNode.textContent = message;
    refineNode.style.color = isError ? "#ef746f" : "";
  }
  if (!isError) clearErrorActions();
}

function setVisionState(nextState, dataExported = state.visionDataExported) {
  state.visionState = nextState;
  state.visionDataExported = Boolean(dataExported);
  const settings = document.querySelector(".engine-settings");
  if (settings) {
    settings.dataset.visionState = nextState;
    settings.dataset.dataExported = state.visionDataExported ? "true" : "false";
  }
  const runtimeStatus = element("vision-runtime-status");
  if (runtimeStatus) {
    runtimeStatus.textContent = `AI 状态：${VISION_STATE_LABELS[nextState] || nextState} · ${state.visionDataExported ? "已发起图层数据外发" : "未外发图层数据"}`;
  }
}

function clearLoadedLayerState() {
  if (state.edgePreviewScheduler) state.edgePreviewScheduler.cancel();
  state.layer = null;
  state.source = null;
  state.sourcePreviewImageUrl = null;
  state.maskPreviewImageUrl = null;
  state.cutoutPreviewImageUrl = null;
  state.cutoutPreviewUrls = Object.create(null);
  state.trimap = null;
  state.trimapHistory = null;
  state.workspaceHistory.clear();
  state.trimapRenderVersion += 1;
  state.alpha = null;
  state.baseAlpha = null;
  state.foreground = null;
  state.foregroundSource = null;
  state.foregroundUsable = false;
  state.algorithmBackground = null;
  state.resultEngine = null;
  state.requiresLowConfidenceConfirmation = false;
  state.lowConfidenceApplyArmed = false;
  state.qualityDiagnostics = null;
  state.automaticDraftSnapshot = null;
  state.edgePreviewStage = "idle";
  state.edgePreviewDraft = null;
  state.previewActive = false;
  state.panelPreviewActive = false;
  state.requestId = null;
  state.workDirty = false;
  state.trimapDirty = false;
  const status = element("layer-status");
  if (status) status.textContent = "未读取图层";
  const refineStatus = element("refine-layer-status");
  if (refineStatus) refineStatus.textContent = "等待当前像素图层";
  setResultState("还没有生成蒙版");
  updateQualityStatus();
  draw();
}

function setBusy(isBusy, operation = null) {
  state.busy = isBusy;
  state.busyOperation = isBusy ? operation : null;
  if (!isBusy) state.cancelRequested = false;
  const restoreBlocked = state.restoreFailed;
  const setDisabled = (id, value) => {
    const control = element(id);
    if (control) control.disabled = value;
  };
  const refreshBlocked = isBusy && ["load", "apply", "batch", "folder-batch"].includes(state.busyOperation);
  setDisabled("load-layer", refreshBlocked);
  setDisabled("auto-cutout", isBusy || restoreBlocked || !state.source || refineEditSession.active);
  setDisabled("batch-cutout", isBusy || restoreBlocked || refineEditSession.active);
  setDisabled("folder-batch", isBusy || restoreBlocked || refineEditSession.active);
  setDisabled("open-refine", isBusy || restoreBlocked);
  setDisabled("quick-preview-expand", isBusy || restoreBlocked || !state.source);
  setDisabled("compute-mask", isBusy || restoreBlocked || state.workspaceReadOnly
    || !state.trimap || !refineEditSession.active);
  const hasPreview = state.previewActive || state.panelPreviewActive;
  const cancelableOperation = isBusy && ["compute", "auto", "batch"].includes(state.busyOperation);
  const applyDisabled = isBusy || restoreBlocked || !state.alpha || !hasPreview || state.optionsDirty || state.trimapDirty;
  setDisabled("apply-mask", applyDisabled || state.workspaceReadOnly || !refineEditSession.active);
  setDisabled("quick-apply", applyDisabled || refineEditSession.active);
  const applyLabel = state.requiresLowConfidenceConfirmation && state.lowConfidenceApplyArmed
    ? "确认应用"
    : "应用";
  const workspaceApply = element("apply-mask");
  const quickApply = element("quick-apply");
  if (workspaceApply) workspaceApply.textContent = applyLabel;
  if (quickApply) quickApply.textContent = applyLabel;
  const quickCancel = element("quick-cancel");
  if (quickCancel) {
    quickCancel.disabled = restoreBlocked
      || refineEditSession.active
      || (isBusy && !cancelableOperation)
      || state.cancelRequested
      || (!isBusy && !state.workDirty && !hasPreview);
    quickCancel.textContent = cancelableOperation
      ? state.cancelRequested ? "正在停止" : state.busyOperation === "batch" ? "停止批量" : "取消计算"
      : "取消预览";
  }
  setDisabled("cancel-refine", isBusy || restoreBlocked || !refineEditSession.active);
  const mode = element("engine-mode");
  if (mode) mode.disabled = isBusy || restoreBlocked;
  const consent = element("vision-consent");
  if (consent) consent.disabled = isBusy || restoreBlocked || !engine.availableModes().visionApi;
  ["view-mode", "edge-shift", "feather", "hard-threshold", "invert-mask",
    "preview-background-color", "zoom-range"]
    .map((id) => element(id))
    .filter(Boolean)
    .forEach((control) => { control.disabled = isBusy || restoreBlocked; });
  ["refine-edge-shift", "refine-feather", "refine-hard-threshold", "refine-invert-mask",
    "refine-reset-options", "brush-size", "brush-softness"]
    .map((id) => element(id))
    .filter(Boolean)
    .forEach((control) => {
      control.disabled = isBusy || restoreBlocked || state.workspaceReadOnly || !refineEditSession.active;
    });
  const refineRoot = state.refineRoot;
  (refineRoot ? refineRoot.querySelectorAll(".tool-button") : []).forEach((button) => {
    button.disabled = isBusy || restoreBlocked || !state.source || !refineEditSession.active;
  });
  const resetMarkControl = element("reset-mark");
  if (resetMarkControl) {
    resetMarkControl.disabled = isBusy || restoreBlocked || state.workspaceReadOnly
      || !refineEditSession.active || !state.trimap;
    resetMarkControl.textContent = "重置标记";
  }
  const reset = element("reset-all");
  if (reset) {
    const cancelable = cancelableOperation;
    reset.disabled = state.workspaceReadOnly
      || (isBusy && !cancelable)
      || state.cancelRequested
      || !refineEditSession.active
      || (!isBusy && !state.trimap);
    reset.textContent = restoreBlocked && !isBusy
      ? "重试恢复原蒙版"
      : cancelable
      ? state.cancelRequested ? "正在取消" : state.busyOperation === "batch" ? "停止批量" : "取消计算"
      : "重置全部";
  }
  const resetOptions = element("reset-options");
  if (resetOptions) resetOptions.disabled = isBusy || restoreBlocked;
  if (!refineEditSession.active) hideBrushCursor();
  updateTrimapHistoryUI();
  updateFolderBatchUI();
  updateZoomUI();
  if (!isBusy && state.selectionRefreshPending && state.selectionSync && state.mainMounted) {
    state.selectionRefreshPending = false;
    state.selectionSync.schedule("selection-after-busy", 0);
  } else if (!isBusy && state.selectionSync && state.selectionSync.pending && !isAutoSelectionBlocked()) {
    Promise.resolve()
      .then(() => state.selectionSync && state.selectionSync.flush())
      .catch(showSelectionSyncError);
  }
}

function setResultState(text, isReady = false) {
  const node = document.querySelector("[data-result-state]");
  if (!node) return;
  node.textContent = text;
  node.classList.toggle("ready", isReady);
}

function getOptions() {
  const invert = element("invert-mask");
  state.maskOptions = {
    ...state.maskOptions,
    ...normalizeEdgeSettings(state.maskOptions)
  };
  if (invert && !element("refine-invert-mask")) state.maskOptions.invert = Boolean(invert.checked);
  const options = { ...state.maskOptions };
  if (state.engineMode === "vision-api" && typeof visionClientConfig?.model === "string" && visionClientConfig.model.trim()) {
    options.model = visionClientConfig.model.trim();
  }
  return options;
}

function canLivePreviewEdgeOptions() {
  return Boolean(
    state.mainMounted
    && state.source
    && state.baseAlpha instanceof Uint8Array
    && state.alpha instanceof Uint8Array
    && state.panelPreviewActive
    && !state.busy
  );
}

function ensureEdgePreviewScheduler() {
  if (state.edgePreviewScheduler) return state.edgePreviewScheduler;
  state.edgePreviewScheduler = createLivePreviewScheduler({
    delay: 16,
    eligible: canLivePreviewEdgeOptions,
    readValue() {
      const options = getOptions();
      return {
        generation: state.panelGeneration,
        source: state.source,
        baseAlpha: state.baseAlpha,
        foreground: state.foreground instanceof Uint8Array
          && canReuseForegroundForEdgePreview(state.foregroundSource, options)
          ? state.foreground
          : null,
        options
      };
    },
    async run(snapshot, _revision, signal, emitIntermediate) {
      if (Math.max(snapshot.source.width, snapshot.source.height) > LIVE_EDGE_PREVIEW_DIMENSION) {
        const previewSource = scalePreviewPixels(snapshot.source, LIVE_EDGE_PREVIEW_DIMENSION);
        const previewBaseAlpha = scalePreviewPixels({
          pixels: snapshot.baseAlpha,
          width: snapshot.source.width,
          height: snapshot.source.height,
          components: 1
        }, LIVE_EDGE_PREVIEW_DIMENSION);
        const previewScale = Math.min(
          previewSource.width / snapshot.source.width,
          previewSource.height / snapshot.source.height
        );
        const previewOptions = scaleEdgeOptionsForPreview(snapshot.options, previewScale);
        let previewAlpha = await applyAlphaPostProcessingAsync(
          previewBaseAlpha.pixels,
          previewBaseAlpha.width,
          previewBaseAlpha.height,
          previewOptions,
          signal
        );
        previewAlpha = await applySourceAlphaLimitAsync(
          previewAlpha,
          previewSource.pixels,
          previewSource.width,
          previewSource.height,
          previewSource.components,
          signal
        );
        const previewForeground = snapshot.foreground instanceof Uint8Array
          ? scalePreviewPixels({
            pixels: snapshot.foreground,
            width: snapshot.source.width,
            height: snapshot.source.height,
            components: 3
          }, LIVE_EDGE_PREVIEW_DIMENSION).pixels
          : null;
        emitIntermediate({
          source: previewSource,
          alpha: previewAlpha,
          foreground: previewForeground,
          foregroundUsable: Boolean(previewForeground)
        });
      }
      let alpha = await applyAlphaPostProcessingAsync(snapshot.baseAlpha,
        snapshot.source.width,
        snapshot.source.height,
        snapshot.options,
        signal
      );
      alpha = await applySourceAlphaLimitAsync(
        alpha,
        snapshot.source.pixels,
        snapshot.source.width,
        snapshot.source.height,
        snapshot.source.components,
        signal
      );
      return { alpha };
    },
    publishIntermediate(result, snapshot) {
      if (!result || !isCurrentPanel(snapshot.generation) || state.source !== snapshot.source) return;
      try {
        state.edgePreviewDraft = result;
        state.maskPreviewImageUrl = createMaskPreviewUrl();
        state.cutoutPreviewImageUrl = null;
        state.cutoutPreviewUrls = Object.create(null);
        ensureCutoutPreviewMode("cutout-transparent");
        ensurePreviewForView(state.viewMode);
        state.edgePreviewStage = "preview";
        setResultState("预览已更新，正在生成全分辨率结果", true);
        setMessage("边缘预览已更新；正在生成全分辨率结果…", false);
        draw();
      } catch (error) {
        // The full-resolution calculation remains authoritative when a display raster cannot be encoded.
      }
    },
    publish(result, snapshot) {
      if (!isCurrentPanel(snapshot.generation) || state.source !== snapshot.source) return;
      state.alpha = new Uint8Array(result.alpha);
      state.foregroundUsable = Boolean(state.foreground)
        && canReuseForegroundForEdgePreview(state.foregroundSource, snapshot.options);
      state.optionsDirty = false;
      state.panelPreviewActive = true;
      state.workDirty = true;
      state.lowConfidenceApplyArmed = false;
      state.edgePreviewStage = "full";
      state.edgePreviewDraft = null;
      updateQualityStatus();
      refreshGeneratedPreviewImages();
      if (refineEditSession.active) syncRefineWorkingSnapshot();
      setResultState("边缘参数已实时更新", true);
      setMessage("边缘预览已更新；确认效果后可保留结果。", false);
      setBusy(false);
      draw();
    },
    onError(error) {
      state.edgePreviewStage = "error";
      setMessage(`边缘实时预览失败：${error.message || "请重新生成蒙版"}`, true);
    }
  });
  return state.edgePreviewScheduler;
}

function scheduleEdgeLivePreview() {
  const scheduler = ensureEdgePreviewScheduler();
  if (!scheduler.schedule()) return false;
  state.edgePreviewStage = "scheduled";
  setResultState("正在实时更新边缘预览");
  setMessage("正在本机更新边缘预览…", false);
  return true;
}

function algorithmContext(generated) {
  const diagnostics = generated && generated.diagnostics;
  if (!diagnostics || diagnostics.mode !== "border-color") {
    return { strategy: "classic", autoTrimapDiagnostics: diagnostics || {} };
  }
  return {
    strategy: "solid-background",
    background: {
      color: diagnostics.background,
      spread: diagnostics.backgroundSpread
    },
    autoTrimapDiagnostics: diagnostics
  };
}

function visionRequestContext() {
  if (state.engineMode !== "vision-api"
    || !visionClientConfig
    || !Number.isInteger(visionClientConfig.contractVersion)) return {};
  return { contractVersion: visionClientConfig.contractVersion };
}

function updateEngineUI() {
  const mode = element("engine-mode");
  const hint = element("engine-hint");
  const endpointStatus = element("vision-endpoint-status");
  const consent = element("vision-consent");
  const visionAvailable = engine.availableModes().visionApi;
  const visionOption = mode && mode.querySelector('option[value="vision-api"]');

  if (visionOption) visionOption.disabled = !visionAvailable;
  if (consent) consent.disabled = !visionAvailable || state.busy;
  if (mode) mode.value = state.engineMode;
  const autoLabel = element("auto-cutout") && element("auto-cutout").querySelector("strong");
  if (autoLabel) autoLabel.textContent = state.engineMode === "vision-api" ? "AI 一键抠图" : "本地一键抠图";
  if (hint) hint.textContent = state.engineMode === "vision-api" ? "AI 视觉模型 · 会发送图层数据" : "本地算法 · 不上传图片";
  let endpointHost = "";
  if (visionClientConfig && visionClientConfig.endpoint) {
    try {
      endpointHost = new URL(visionClientConfig.endpoint).host;
    } catch (error) {
      endpointHost = String(visionClientConfig.endpoint).replace(/^https?:\/\//i, "").split("/")[0];
    }
  }
  if (endpointStatus) {
    const configuredTimeout = Number(visionClientConfig?.timeoutMs ?? visionClientConfig?.timeout);
    const timeoutMs = Number.isFinite(configuredTimeout) && configuredTimeout > 0 ? configuredTimeout : DEFAULT_TIMEOUT_MS;
    const model = typeof visionClientConfig?.model === "string" && visionClientConfig.model.trim()
      ? `；模型 ${visionClientConfig.model.trim()}`
      : "";
    endpointStatus.textContent = visionConfigError
      ? "AI 配置无效，已保持本地算法。"
      : visionAvailable
        ? `AI 服务已配置${endpointHost ? `：${endpointHost}` : ""}${model}；请求超时 ${Math.round(timeoutMs / 1000)} 秒；图层数据会外发，留存策略未知，请确认服务商条款。`
        : "未配置 AI 视觉模型服务，当前仅使用本地算法。";
    endpointStatus.style.color = visionConfigError ? "#ef746f" : "";
  }
  const status = element("engine-status");
  if (status) status.textContent = engine.describe();
  const modeLabel = document.querySelector(".engine-mode");
  if (modeLabel) modeLabel.textContent = state.engineMode === "vision-api" ? "AI 视觉模型" : "本地算法";
  if (!visionAvailable) setVisionState(VISION_STATES.NOT_CONFIGURED, false);
  else if ((!consent || !consent.checked) && !state.visionDataExported) {
    setVisionState(VISION_STATES.PENDING_CONSENT, false);
  }
  else if ([VISION_STATES.NOT_CONFIGURED, VISION_STATES.PENDING_CONSENT].includes(state.visionState)) {
    setVisionState(VISION_STATES.READY, false);
  }
}

function resetVisionCycleForLayer() {
  if (!engine.availableModes().visionApi) {
    setVisionState(VISION_STATES.NOT_CONFIGURED, false);
    return;
  }
  const consent = element("vision-consent");
  setVisionState(consent && consent.checked ? VISION_STATES.READY : VISION_STATES.PENDING_CONSENT, false);
}

function selectEngineMode(nextMode) {
  if (nextMode === "vision-api") {
    const consent = element("vision-consent");
    if (!engine.availableModes().visionApi) {
      setVisionState(VISION_STATES.NOT_CONFIGURED, false);
      setMessage("AI 视觉模型尚未配置，已保持本地算法。", true);
      updateEngineUI();
      return;
    }
    if (!consent || !consent.checked) {
      setVisionState(VISION_STATES.PENDING_CONSENT, false);
      setMessage("请先确认图层数据会发送到已配置的 AI 服务。", true);
      updateEngineUI();
      return;
    }
  }

  try {
    engine.setMode(nextMode);
    state.engineMode = nextMode;
    if (nextMode === "vision-api") setVisionState(VISION_STATES.READY, false);
    setMessage(nextMode === "vision-api" ? "已切换到 AI 视觉模型，下一次计算会发送图层数据。" : "已切换到本地算法，不会上传图片。");
    updateEngineUI();
  } catch (error) {
    state.engineMode = "algorithm";
    setMessage(error.message || "切换计算引擎失败。", true);
    updateEngineUI();
  }
}

function getLabel() {
  if (state.tool === "keep") return LABELS.KEEP;
  if (state.tool === "cut") return LABELS.CUT;
  return LABELS.UNKNOWN;
}

function showLayerReadError(error) {
  setMessage(`读取图层失败：${formatHostError(error)}`, true);
}

function showSelectionSyncError(error) {
  setMessage(`同步 Photoshop 图层失败：${formatHostError(error)}`, true);
}

function abortCancelableWorkForReload() {
  if (!["compute", "auto"].includes(state.busyOperation)) return false;
  state.operationToken += 1;
  state.cancelRequested = true;
  if (state.requestController) state.requestController.abort();
  state.requestController = null;
  setBusy(false);
  return true;
}

async function prepareLayerReload(nextKey, { automatic = false } = {}) {
  const loadedKey = selectionLayerKey(state.layer);
  const contextChanged = Boolean(loadedKey && nextKey && nextKey !== loadedKey);
  if (automatic && !contextChanged && isAutoSelectionBlocked({ status: "ready", key: nextKey })) return false;
  if (state.busy && !abortCancelableWorkForReload()) return false;

  if (refineEditSession.active) {
    refineEditSession.cancel();
    state.refineBaselinePreviewActive = false;
    closeRefineDialog("reload");
  }
  resetRefineInteractionState();

  if (state.previewActive && state.layer && !contextChanged) {
    try {
      await cancelCurrentPreview();
    } catch (error) {
      state.previewActive = false;
    }
  } else if (contextChanged) {
    // Current releases never write a temporary preview. This branch releases
    // stale in-memory state left by an older loaded instance.
    state.previewActive = false;
  }

  state.restoreFailed = false;
  state.previewPromise = null;
  clearErrorActions();
  clearLoadedLayerState();
  return true;
}

async function loadLayer({ automatic = false, layer: requestedLayer = null, expectedKey = null } = {}) {
  let layer;
  try {
    layer = requestedLayer || host.getActivePixelLayer();
  } catch (error) {
    showLayerReadError(error);
    return false;
  }
  const nextKey = expectedKey || selectionLayerKey(layer);
  if (!await prepareLayerReload(nextKey, { automatic })) return false;
  const generation = state.panelGeneration;
  setBusy(true, "load");
  try {
    if (!isCurrentPanel(generation)) return false;
    const layerStatus = element("layer-status");
    if (layerStatus) layerStatus.textContent = automatic ? `正在读取 ${layer.name}……` : `正在刷新 ${layer.name}……`;
    const source = await host.readLayerPixels(layer);
    if (!isCurrentPanel(generation)) return false;
    if (automatic && expectedKey) {
      const currentSelection = inspectPhotoshopSelection();
      if (currentSelection.status !== "ready" || currentSelection.key !== expectedKey) {
        state.selectionRefreshPending = true;
        clearLoadedLayerState();
        showSelectionState(currentSelection);
        return false;
      }
    }
    state.layer = { ...layer, bounds: source.bounds };
    state.source = source;
    state.sourcePreviewImageUrl = null;
    state.maskPreviewImageUrl = null;
    state.cutoutPreviewImageUrl = null;
    state.cutoutPreviewUrls = Object.create(null);
    state.trimap = new TrimapRaster(source.width, source.height);
    state.trimapHistory = createTrimapHistory(state.trimap);
    resetWorkspaceHistory();
    state.trimapRenderVersion += 1;
    state.alpha = null;
    state.baseAlpha = null;
    state.foreground = null;
    state.foregroundSource = null;
    state.foregroundUsable = false;
    state.algorithmBackground = null;
    state.panelPreviewActive = false;
    state.optionsDirty = false;
    state.edgePreviewDraft = null;
    state.edgePreviewStage = "idle";
    state.trimapDirty = false;
    state.zoom = 1;
    state.zoomMode = "fit";
    state.requestId = null;
    state.workDirty = false;
    resetVisionCycleForLayer();
    try {
      state.sourcePreviewImageUrl = encodePngDataUrl(scalePreviewPixels(source, MAX_PREVIEW_DIMENSION));
    } catch (previewError) {
      state.sourcePreviewImageUrl = null;
    }
    const layerText = `${layer.name} · ${source.width} × ${source.height}`;
    const refreshedLayerStatus = element("layer-status");
    const refineLayerStatus = element("refine-layer-status");
    if (refreshedLayerStatus) refreshedLayerStatus.textContent = layerText;
    if (refineLayerStatus) refineLayerStatus.textContent = layerText;
    setMessage(`${automatic ? "已自动读取" : "已刷新"}图层。当前引擎：${engine.describe()}`);
    setResultState("还没有生成蒙版");
    draw();
    return true;
  } catch (error) {
    if (!isCurrentPanel(generation)) return false;
    // If no temporary preview remains to protect, discard the old source so
    // a failed reload cannot leave controls operating on stale pixels.
    if (!state.previewActive) clearLoadedLayerState();
    showLayerReadError(error);
    return false;
  } finally {
    if (isCurrentPanel(generation)) {
      setBusy(false);
      if (state.source && state.zoomMode === "fit") fitZoomToWindow();
    }
  }
}

async function previewAlpha(alpha) {
  if (!state.layer || !(alpha instanceof Uint8Array)) return false;
  if (typeof host.previewLayerMask !== "function") return false;
  const generation = state.panelGeneration;
  const layer = state.layer;
  await host.previewLayerMask(layer, alpha);
  if (!isCurrentPanel(generation) || state.layer !== layer) return false;
  state.previewActive = true;
  return true;
}

async function runPreview(alpha) {
  const previewPromise = previewAlpha(alpha);
  state.previewPromise = previewPromise;
  try {
    return await previewPromise;
  } finally {
    if (state.previewPromise === previewPromise) state.previewPromise = null;
  }
}

async function cancelCurrentPreview() {
  if (!state.previewActive) return false;
  if (!state.layer || typeof host.cancelMaskPreview !== "function") {
    throw new Error("无法安全取消 Photoshop 临时蒙版预览。");
  }
  const generation = state.panelGeneration;
  const layer = state.layer;
  const cancelPromise = host.cancelMaskPreview(layer);
  state.previewPromise = cancelPromise;
  try {
    await cancelPromise;
    if (isCurrentPanel(generation) && state.layer === layer) {
      state.previewActive = false;
      state.restoreFailed = false;
    }
    return true;
  } catch (error) {
    if (isCurrentPanel(generation) && state.layer === layer) state.restoreFailed = true;
    throw error;
  } finally {
    if (state.previewPromise === cancelPromise) state.previewPromise = null;
  }
}

function describeEngineError(error) {
  if (error && (error.name === "AbortError" || error.code === "canceled")) {
    return "计算已取消；当前 Trimap 和参数已保留。";
  }
  if (error instanceof VisionApiError) {
    if (error.category === "canceled") return "AI 视觉模型请求已取消。";
    if (error.category === "timeout") return "AI 视觉模型请求超时，可重试或切换到本地算法。";
    if (error.category === "authentication") return "AI 视觉模型认证失败，请检查运行时配置。";
    if (error.category === "permission") return "AI 视觉模型服务拒绝了当前权限，请检查项目授权或模型访问范围。";
    if (error.category === "rate-limit") return "AI 视觉模型服务限流，请稍后重试。";
    if (error.category === "response-format") return "AI 视觉模型返回了无法识别的蒙版。";
    if (error.category === "server") return "AI 视觉模型服务暂时不可用，可重试或切换到本地算法。";
    if (error.category === "configuration") return "AI 视觉模型配置无效，已保持本地算法。";
    if (error.accepted) return "AI 服务可能已接受本次请求，但返回结果无法识别；请先确认服务端记录，再决定是否重试。";
    return "AI 视觉模型请求失败，可重试或切换到本地算法。";
  }
  return error && error.message ? error.message : "蒙版计算失败。";
}

function diagnosticConfidencePercent(diagnostics) {
  const value = Number(diagnostics && diagnostics.confidence);
  if (!Number.isFinite(value)) return null;
  return Math.round(value >= 0 && value <= 1 ? value * 100 : value);
}

function updateQualityStatus(next = state.qualityDiagnostics) {
  const output = element("refine-quality-status");
  if (!output) return;
  if (!next) {
    output.textContent = "计算结果后显示边缘与残留风险。";
    output.classList.remove("warning");
    return;
  }
  const confidence = diagnosticConfidencePercent(next);
  const warnings = Array.isArray(next.warnings) ? next.warnings.filter(Boolean) : [];
  const parts = [next.engine === "vision-api" ? "AI 视觉模型" : "本地算法"];
  if (next.strategy) parts.push(`策略 ${next.strategy}`);
  if (confidence !== null) parts.push(`置信度 ${confidence}%`);
  parts.push(warnings.length ? `${warnings.length} 项边缘风险：${warnings.join("；")}` : "未报告边缘风险");
  output.textContent = parts.join(" · ");
  output.classList.toggle("warning", Boolean(next.lowConfidence || warnings.length));
}

function describeDiagnostics(diagnostics, engineMode) {
  if (!diagnostics || typeof diagnostics !== "object") return "";
  const parts = [];
  if (diagnostics.model) parts.push(`模型 ${diagnostics.model}`);
  if (diagnostics.modelVersion) parts.push(`版本 ${diagnostics.modelVersion}`);
  const confidence = diagnosticConfidencePercent(diagnostics);
  if (confidence !== null) parts.push(`置信度 ${confidence}%`);
  if (Number.isFinite(Number(diagnostics.processingMs))) {
    parts.push(`${Math.round(Number(diagnostics.processingMs))} ms`);
  }
  if (diagnostics.traceId) parts.push(`追踪 ${diagnostics.traceId}`);
  if (engineMode === "vision-api" && diagnostics.fringeMode === "mask-only") {
    parts.push("当前服务仅返回蒙版");
  }
  const warnings = Array.isArray(diagnostics.warnings) ? [...diagnostics.warnings] : [];
  if (diagnostics.warning) warnings.push(diagnostics.warning);
  if (warnings.length) parts.push(`提示：${warnings.join("；")}`);
  return parts.join(" · ");
}

function startVisionProgress(prepareMessage) {
  setVisionState(VISION_STATES.PREPARING, false);
  setMessage(prepareMessage);
}

function reportVisionStatus(token, status) {
  if (!status || token !== state.operationToken || !state.busy || state.cancelRequested) return;
  if (status.state === "uploading") {
    setVisionState(VISION_STATES.UPLOADING, true);
    setMessage("AI 请求已发起，正在等待服务响应……");
  } else if (status.state === "processing") {
    setVisionState(VISION_STATES.PROCESSING, true);
    setMessage("已收到 AI 服务响应，正在校验结果……");
  }
}

function beginRequest() {
  const token = state.operationToken + 1;
  state.operationToken = token;
  state.cancelRequested = false;
  state.requestController = typeof AbortController === "function" ? new AbortController() : null;
  return { controller: state.requestController, token };
}

function reportAlgorithmProgress(token, progress) {
  if (!progress || !state.busy || state.cancelRequested || state.operationToken !== token) return;
  const total = Number(progress.total);
  const completed = Number(progress.completed);
  if (!Number.isFinite(total) || total < 1 || !Number.isFinite(completed)) return;
  const percent = Math.max(0, Math.min(100, Math.round((completed / total) * 100)));
  const phaseKey = String(progress.phase || "");
  const phase = phaseKey.startsWith("auto-")
    ? "分析前景"
    : ALGORITHM_PHASE_LABELS[phaseKey] || "整理结果";
  setMessage(`正在${phase}……${percent}%`);
}

function endRequest(request) {
  if (state.requestController === request.controller) state.requestController = null;
}

function requestWasCanceled(request) {
  return request.token !== state.operationToken
    || state.cancelRequested
    || Boolean(request.controller && request.controller.signal.aborted);
}

function recordVisionFailure(error) {
  const canceled = error && (error.category === "canceled" || error.code === "canceled" || error.name === "AbortError");
  setVisionState(canceled
    ? VISION_STATES.CANCELED
    : error && error.retryable
      ? VISION_STATES.RETRYABLE_ERROR
      : VISION_STATES.NONRETRYABLE_ERROR);
}

async function runMaskOperation(operation) {
  const isAuto = operation === "auto";
  if (!state.source || (!isAuto && !state.trimap) || state.busy) return;
  if (state.edgePreviewScheduler) state.edgePreviewScheduler.cancel();
  setBusy(true, operation);
  state.lastOperation = operation;
  const request = beginRequest();
  const operationEngine = state.engineMode;
  let generated = null;
  try {
    state.requestId = createRequestId();
    if (operationEngine === "vision-api") {
      startVisionProgress(isAuto ? "准备 Trimap 并发送图层数据……" : "准备发送图层数据……");
    } else {
      setMessage(isAuto ? "正在根据边界和透明通道自动推测前景……" : "正在计算蒙版，请稍候……");
    }
    if (state.previewActive) await cancelCurrentPreview();
    if (requestWasCanceled(request)) return;

    if (isAuto) {
      generated = await autoTrimapAsync({
        pixels: state.source.pixels,
        width: state.source.width,
        height: state.source.height,
        components: state.source.components,
        ...(request.controller ? { signal: request.controller.signal } : {}),
        onProgress: (progress) => reportAlgorithmProgress(request.token, progress)
      });
      generated = prepareAutoTrimapForEngine(generated, operationEngine);
      if (requestWasCanceled(request)) return;
      state.trimap = generated.trimap;
      state.trimapHistory = createTrimapHistory(state.trimap);
      resetWorkspaceHistory();
      state.trimapRenderVersion += 1;
      state.alpha = null;
      state.baseAlpha = null;
      state.foreground = null;
      state.foregroundSource = null;
      state.foregroundUsable = false;
      state.workDirty = true;
    }

    const computeContext = isAuto ? algorithmContext(generated) : { strategy: "classic" };
    if (isAuto) {
      state.algorithmBackground = operationEngine === "algorithm"
        && computeContext.strategy === "solid-background"
        ? computeContext.background
        : null;
    } else if (operationEngine === "algorithm" && state.algorithmBackground) {
      computeContext.background = state.algorithmBackground;
    }
    const requestOptions = getOptions();
    if (!isAuto && operationEngine === "algorithm" && computeContext.background) {
      requestOptions.decontaminate = true;
    }
    const response = await engine.compute({
      pixels: state.source.pixels,
      width: state.source.width,
      height: state.source.height,
      components: state.source.components,
      trimap: state.trimap.data,
      ...computeContext,
      ...visionRequestContext(),
      requestId: state.requestId,
      ...(request.controller ? { signal: request.controller.signal } : {}),
      onProgress: (progress) => reportAlgorithmProgress(request.token, progress),
      onStatus: (status) => reportVisionStatus(request.token, status),
      options: requestOptions
    });
    if (requestWasCanceled(request)) {
      if (state.previewActive) await cancelCurrentPreview();
      return;
    }
    state.alpha = response.alpha;
    state.baseAlpha = response.baseAlpha
      ? new Uint8Array(response.baseAlpha)
      : new Uint8Array(response.alpha);
    state.foreground = response.foreground ? new Uint8Array(response.foreground) : null;
    state.foregroundSource = state.foreground ? response.foregroundSource || "provider" : null;
    state.foregroundUsable = Boolean(state.foreground);
    state.workDirty = true;
    state.trimapDirty = false;
    if (state.trimapHistory) state.trimapHistory.clearPending();
    state.resultEngine = operationEngine;
    state.requiresLowConfidenceConfirmation = Boolean(isAuto
      && operationEngine === "algorithm"
      && generated
      && generated.diagnostics
      && generated.diagnostics.confidence < 0.55);
    state.lowConfidenceApplyArmed = false;
    state.panelPreviewActive = false;
    state.optionsDirty = false;
    const generatedWarnings = Array.isArray(generated && generated.diagnostics && generated.diagnostics.warnings)
      ? generated.diagnostics.warnings : [];
    const responseWarnings = Array.isArray(response && response.diagnostics && response.diagnostics.warnings)
      ? response.diagnostics.warnings : [];
    state.qualityDiagnostics = {
      engine: operationEngine,
      strategy: String(response && response.diagnostics && (response.diagnostics.strategy || response.diagnostics.model)
        || generated && generated.diagnostics && generated.diagnostics.mode || "classic"),
      confidence: generated && generated.diagnostics && generated.diagnostics.confidence !== undefined
        ? generated.diagnostics.confidence
        : response && response.diagnostics && response.diagnostics.confidence,
      warnings: [
        ...generatedWarnings,
        ...responseWarnings,
        ...(response && response.diagnostics && response.diagnostics.warning ? [response.diagnostics.warning] : [])
      ].filter((value, index, all) => typeof value === "string" && all.indexOf(value) === index),
      lowConfidence: state.requiresLowConfidenceConfirmation
    };
    updateQualityStatus();
    state.edgePreviewDraft = null;
    state.edgePreviewStage = "full";
    // The plugin workspace is the authoritative preview. Build both the
    // grayscale mask and the real color cutout from the same alpha result.
    refreshGeneratedPreviewImages();

    if (requestWasCanceled(request)) {
      return;
    }

    state.previewActive = false;
    state.panelPreviewActive = true;
    if (refineEditSession.active) {
      syncRefineWorkingSnapshot();
      refineEditSession.markChanged();
    }
    state.viewMode = "cutout-transparent";
    const viewMode = element("view-mode");
    if (viewMode) viewMode.value = state.viewMode;
    if (isAuto) state.automaticDraftSnapshot = captureRefineSnapshot();
    setResultState("蒙版结果待确认", true);
    draw();

    if (operationEngine === "vision-api") setVisionState(VISION_STATES.PREVIEW, true);
    const previewNotice = "结果仅在插件中预览；点击“应用蒙版”后才会写入 Photoshop。";
    if (!isAuto) {
      const diagnostics = describeDiagnostics(response.diagnostics, operationEngine);
      setMessage(`蒙版已生成，${previewNotice}${diagnostics ? ` ${diagnostics}` : ""}`);
      return;
    }
    const diagnostics = operationEngine === "vision-api"
      ? describeDiagnostics(response.diagnostics, operationEngine)
      : `算法置信度约 ${Math.round(generated.diagnostics.confidence * 100)}%`;
    const lowConfidence = state.requiresLowConfidenceConfirmation;
    const warning = lowConfidence ? "建议用保留/删除笔刷修正后重新计算。" : "请检查缩略图或精修窗口中的蒙版后再应用。";
    setMessage(`一键抠图完成，${diagnostics || "结果已生成"}。${warning} ${previewNotice}`, lowConfidence);
  } catch (error) {
    if (request.token !== state.operationToken) return;
    if (operationEngine === "vision-api") recordVisionFailure(error);
    setMessage(describeEngineError(error), true);
    showErrorActions(error);
  } finally {
    endRequest(request);
    if (request.token === state.operationToken) {
      setBusy(false);
      updateEngineUI();
    }
  }
}

function computeMask() {
  return runMaskOperation("compute");
}

function autoCutout() {
  if (refineEditSession.active) {
    setMessage("请先在抠图精修工作区应用或取消当前修改。", true);
    return Promise.resolve(false);
  }
  return runMaskOperation("auto");
}

function isBatchSessionError(error) {
  const message = String(error && error.message || "");
  return /文档已切换|图层选择已变化|图层已切换|图层边界已变化/.test(message);
}

async function batchCutout() {
  if (state.busy) return;
  if (state.engineMode !== "algorithm") {
    setMessage("批量抠图第一版仅支持本地算法，请先在计算引擎中切回本地算法。", true);
    return;
  }
  if (state.previewActive || state.panelPreviewActive) {
    setMessage("当前还有单图层预览，请先应用蒙版或重置，再开始批量抠图。", true);
    return;
  }

  let selection;
  try {
    selection = host.getSelectedPixelLayers();
  } catch (error) {
    setMessage(error.message || "无法读取 Photoshop 多选图层。", true);
    return;
  }
  if (!selection.layers.length) {
    setMessage("所选内容中没有可处理的像素图层。", true);
    return;
  }

  setBusy(true, "batch");
  state.lastOperation = "batch";
  const generation = state.panelGeneration;
  const request = beginRequest();
  const isCurrentBatch = () => isCurrentPanel(generation) && request.token === state.operationToken;
  const total = selection.layers.length;
  let batchSessionError = null;
  const runHostOperation = async (operation) => {
    try {
      return await operation();
    } catch (error) {
      if (isBatchSessionError(error)) {
        batchSessionError = error;
        if (request.controller) request.controller.abort();
      }
      throw error;
    }
  };
  try {
    const result = await runBatchCutout({
      layers: selection.layers,
      signal: request.controller && request.controller.signal,
      processLayer: async (layer, context) => {
        const prefix = `第 ${context.index + 1}/${context.total} 层 · ${layer.name}`;
        if (isCurrentBatch()) setMessage(`${prefix} · 读取像素……`);
        const source = await runHostOperation(() => host.readLayerPixels(layer));
        const generated = await autoTrimapAsync({
          pixels: source.pixels,
          width: source.width,
          height: source.height,
          components: source.components,
          ...(context.signal ? { signal: context.signal } : {}),
          onProgress: (progress) => {
            if (!isCurrentBatch()) return;
            const completed = Number(progress && progress.completed) || 0;
            const phaseTotal = Math.max(1, Number(progress && progress.total) || 1);
            setMessage(`${prefix} · 分析前景 ${Math.round((completed / phaseTotal) * 100)}%`);
          }
        });
        const confidence = Number(generated && generated.diagnostics && generated.diagnostics.confidence);
        if (Number.isFinite(confidence) && confidence < 0.55) {
          const error = new Error(`本地算法置信度不足（${Math.round(confidence * 100)}%），需要单图精修确认`);
          error.stage = "quality";
          error.code = "low-confidence";
          throw error;
        }
        let prepared;
        try {
          prepared = prepareAutoTrimapForEngine(generated, "algorithm");
        } catch (error) {
          error.stage = error.stage || "quality";
          throw error;
        }
        const response = await engine.compute({
          pixels: source.pixels,
          width: source.width,
          height: source.height,
          components: source.components,
          trimap: prepared.trimap.data,
          ...algorithmContext(prepared),
          requestId: createRequestId(),
          ...(context.signal ? { signal: context.signal } : {}),
          options: getOptions()
        });
        return {
          alpha: response.alpha,
          foreground: response.foreground,
          width: source.width,
          height: source.height,
          diagnostics: response.diagnostics
        };
      },
      saveOriginalMask: (layer) => runHostOperation(() => host.saveLayerMask(layer)),
      applyResult: (layer, processed) => runHostOperation(() => {
        if (processed.foreground && typeof host.applyForegroundResult === "function") {
          return host.applyForegroundResult(layer, {
            foreground: processed.foreground,
            alpha: processed.alpha,
            width: processed.width,
            height: processed.height,
            name: `${layer.name} 抠图结果`,
            preserveSelection: true
          });
        }
        return host.applyLayerMask(layer, processed.alpha);
      }),
      restoreOriginalMask: (layer, snapshot) => host.restoreLayerMaskSnapshot(layer, snapshot),
      onProgress: ({ phase, index, layer }) => {
        if (isCurrentBatch() && phase === "applying") {
          setMessage(`第 ${index + 1}/${total} 层 · ${layer.name} · 正在应用蒙版……`);
        }
      }
    });

    if (!isCurrentBatch()) return;
    const skipped = selection.skipped.length;
    const summary = `批量完成 ${result.succeeded.length} 层，失败 ${result.failed.length} 层，跳过 ${skipped} 层`;
    if (result.canceled) {
      setResultState(`${summary}，已停止`, result.succeeded.length > 0);
      setMessage(batchSessionError
        ? `${summary}；${batchSessionError.message}`
        : `${summary}；未开始的图层没有修改。`, Boolean(batchSessionError || result.failed.length));
    } else {
      setResultState(summary, result.succeeded.length > 0);
      const failedNames = result.failed.slice(0, 3).map((item) => {
        const reason = formatHostError(item.error);
        return `${item.layer.name}（${reason}）`;
      }).join("、");
      const skippedNames = selection.skipped.slice(0, 3)
        .map((item) => `${item.name}（${item.reason}）`)
        .join("、");
      const succeededNames = result.succeeded.slice(0, 3).map((item) => {
        const diagnostics = item.diagnostics || {};
        const source = diagnostics.strategy || diagnostics.engine || "local-algorithm";
        const confidence = diagnosticConfidencePercent(diagnostics);
        return `${item.layer.name}（${source}${confidence === null ? "" : `，置信度 ${confidence}%`}）`;
      }).join("、");
      const details = [
        succeededNames ? `成功图层：${succeededNames}` : "",
        failedNames ? `失败图层：${failedNames}` : "",
        skippedNames ? `跳过：${skippedNames}` : ""
      ].filter(Boolean).join("；");
      setMessage(details ? `${summary}。${details}` : `${summary}。`, result.failed.length > 0);
    }
  } catch (error) {
    if (!isCurrentBatch()) return;
    setResultState("批量抠图失败");
    setMessage(`批量抠图失败：${formatHostError(error)}`, true);
  } finally {
    endRequest(request);
    if (isCurrentBatch()) setBusy(false);
  }
}

async function applyMask() {
  const hasPreview = state.previewActive || state.panelPreviewActive;
  if (!state.layer || !state.alpha || !hasPreview || state.optionsDirty || state.trimapDirty || state.busy) {
    if (state.trimapDirty) setMessage("标记已修改，请先重新计算，再应用结果。", true);
    if (state.optionsDirty) setMessage("边缘参数已修改，请重新计算后再应用蒙版。", true);
    if (state.alpha && !hasPreview) setMessage("请先生成并检查蒙版预览，再应用。", true);
    return false;
  }
  if (state.requiresLowConfidenceConfirmation && !state.lowConfidenceApplyArmed) {
    state.lowConfidenceApplyArmed = true;
    setBusy(false);
    setMessage("当前结果置信度较低。请检查预览；仍要写入时，再点击一次“确认应用”。", true);
    return false;
  }
  setBusy(true, "apply");
  const generation = state.panelGeneration;
  const layer = state.layer;
  const applyForeground = Boolean(state.foreground && state.foregroundUsable);
  try {
    if (applyForeground && typeof host.applyForegroundResult === "function") {
      await host.applyForegroundResult(layer, {
        foreground: state.foreground,
        alpha: state.alpha,
        width: state.source.width,
        height: state.source.height,
        name: `${layer.name} 抠图结果`
      });
    } else if (typeof host.applyLayerMask === "function") await host.applyLayerMask(layer, state.alpha);
    else await host.putLayerMask(layer, state.alpha);
    if (!isCurrentPanel(generation)) return;
    state.previewActive = false;
    state.panelPreviewActive = false;
    state.workDirty = false;
    state.requiresLowConfidenceConfirmation = false;
    state.lowConfidenceApplyArmed = false;
    if (state.resultEngine === "vision-api") setVisionState(VISION_STATES.APPLIED, true);
    setResultState(applyForeground ? "校正前景已应用" : "蒙版已应用", true);
    setMessage(applyForeground
      ? "已新建校正前景图层并应用蒙版；原始图层保持不变。"
      : "图层蒙版已应用，可以在 Photoshop 中继续编辑。", false);
    return true;
  } catch (error) {
    if (!isCurrentPanel(generation)) return;
    setMessage(`应用蒙版失败：${formatHostError(error)}`, true);
    return false;
  } finally {
    if (isCurrentPanel(generation)) setBusy(false);
  }
}

async function beginRefineSession(entryMode = "refine") {
  if (refineEditSession.active) {
    draw();
    if (state.zoomMode === "fit") fitZoomToWindow();
    return true;
  }
  if (!state.source) await loadLayer();
  if (!state.source || !state.trimap) return false;
  const resumeEdgePreview = Boolean(
    state.optionsDirty
    && state.baseAlpha instanceof Uint8Array
    && state.alpha instanceof Uint8Array
    && state.panelPreviewActive
  );
  if (state.edgePreviewScheduler) state.edgePreviewScheduler.cancel();

  const hadPreview = Boolean(state.previewActive);
  const sessionOpenSnapshot = captureRefineSnapshot();
  const automaticDraft = state.automaticDraftSnapshot || sessionOpenSnapshot;
  const working = refineEditSession.begin(sessionOpenSnapshot, { automaticDraft });
  state.refineBaselinePreviewActive = hadPreview;
  restoreRefineSnapshot(working);
  state.workspaceReadOnly = entryMode === "view";
  state.previewActive = hadPreview;
  if (state.refineBaselinePreviewActive) {
    setBusy(true, "prepare-refine");
    try {
      await cancelCurrentPreview();
      state.panelPreviewActive = Boolean(state.alpha);
    } catch (error) {
      refineEditSession.cancel();
      setMessage(error.message || "无法安全进入精修工作区。", true);
      return false;
    } finally {
      setBusy(false);
    }
  }
  state.viewMode = entryMode === "view" && state.alpha ? "cutout-transparent" : "mark";
  const viewMode = element("view-mode");
  if (viewMode) viewMode.value = state.viewMode;
  const modeLabel = element("workspace-mode-label");
  if (modeLabel) modeLabel.textContent = entryMode === "view" ? "查看" : "精修";
  setMessage("精修工作区已就绪：选择画笔后直接在原图上涂抹。", false);
  setBusy(false);
  draw();
  fitZoomToWindow();
  if (resumeEdgePreview) scheduleEdgeLivePreview();
  return true;
}

async function cancelRefineSession() {
  if (!refineEditSession.active || state.busy) return false;
  if (state.edgePreviewScheduler) state.edgePreviewScheduler.cancel();
  setBusy(true, "cancel-refine");
  edgeParameterGesture.cancel();
  const shouldRestorePreview = state.refineBaselinePreviewActive;
  let resumeRestoredEdgePreview = false;
  try {
    if (state.previewActive) await cancelCurrentPreview();
    const baseline = refineEditSession.cancel();
    restoreRefineSnapshot(baseline);
    resumeRestoredEdgePreview = Boolean(
      state.optionsDirty
      && state.baseAlpha instanceof Uint8Array
      && state.alpha instanceof Uint8Array
      && state.panelPreviewActive
    );
    state.previewActive = false;
    if (shouldRestorePreview && state.alpha) {
      try {
        await runPreview(state.alpha);
      } catch (error) {
        state.previewActive = false;
        state.panelPreviewActive = true;
      }
    }
    state.refineBaselinePreviewActive = false;
    setResultState(state.alpha ? "已恢复进入精修前的结果" : "还没有生成蒙版", Boolean(state.alpha));
    setMessage("已取消精修并恢复进入前的标记和结果。", false);
    draw();
    return true;
  } catch (error) {
    setMessage(error.message || "取消精修失败。", true);
    return false;
  } finally {
    setBusy(false);
    if (resumeRestoredEdgePreview) scheduleEdgeLivePreview();
  }
}

async function applyRefineSession() {
  if (!refineEditSession.active || state.busy) return false;
  commitEdgeOptionGesture();
  syncRefineWorkingSnapshot();
  const applied = await applyMask();
  if (!applied) return false;
  refineEditSession.apply();
  state.refineBaselinePreviewActive = false;
  setBusy(false);
  return true;
}

async function resetWorkspace({ preserveOptions = false } = {}) {
  if (!state.trimap || (state.busy && !["compute", "auto"].includes(state.busyOperation))) return;
  if (state.edgePreviewScheduler) state.edgePreviewScheduler.cancel();
  const generation = state.panelGeneration;
  state.operationToken += 1;
  if (state.requestController) {
    state.requestController.abort();
    state.requestController = null;
  }
  setBusy(true, "reset");
  try {
    if (state.previewPromise) await state.previewPromise;
    if (state.previewActive) await cancelCurrentPreview();
    if (!isCurrentPanel(generation)) return;
  } catch (error) {
    if (!isCurrentPanel(generation)) return;
    setMessage(error.message || "取消蒙版预览失败。", true);
    setBusy(false);
    return;
  }
  if (refineEditSession.active) {
    const retainedOptions = { ...state.maskOptions };
    const retainedBackground = state.previewBackgroundColor;
    edgeParameterGesture.cancel();
    const baseline = preserveOptions
      ? refineEditSession.restoreAutomaticDraft()
      : refineEditSession.resetAll();
    restoreRefineSnapshot(baseline, { restorePreviewFlag: false });
    if (preserveOptions) {
      state.maskOptions = retainedOptions;
      state.previewBackgroundColor = retainedBackground;
      syncEdgeOptionsUI();
      const backgroundInput = element("preview-background-color");
      if (backgroundInput) backgroundInput.value = retainedBackground;
    }
    state.workspaceReadOnly = false;
    const optionsChanged = preserveOptions
      && JSON.stringify(state.maskOptions) !== JSON.stringify(baseline.maskOptions || DEFAULT_MASK_OPTIONS);
    if (optionsChanged) {
      state.optionsDirty = Boolean(state.alpha);
      syncRefineWorkingSnapshot();
      refineEditSession.markChanged();
    }
    setResultState(state.alpha ? (optionsChanged ? "标记已重置，正在更新边缘" : "已恢复自动初稿") : "还没有生成蒙版", Boolean(state.alpha));
    setMessage(preserveOptions ? "标记已重置；边缘参数保持不变。" : "已恢复打开工作区时的全部初始设置。", false);
    setBusy(false);
    draw();
    if (optionsChanged) scheduleEdgeLivePreview();
    return;
  }
  state.restoreFailed = false;
  state.trimap.clear();
  state.trimapHistory = createTrimapHistory(state.trimap);
  resetWorkspaceHistory();
  state.trimapRenderVersion += 1;
  state.alpha = null;
  state.baseAlpha = null;
  state.foreground = null;
  state.foregroundSource = null;
  state.foregroundUsable = false;
  state.algorithmBackground = null;
  state.panelPreviewActive = false;
  state.maskPreviewImageUrl = null;
  state.cutoutPreviewImageUrl = null;
  state.cutoutPreviewUrls = Object.create(null);
  state.optionsDirty = false;
  state.trimapDirty = false;
  state.workDirty = false;
  state.automaticDraftSnapshot = null;
  state.edgePreviewDraft = null;
  state.edgePreviewStage = "idle";
  if (state.resultEngine === "vision-api") setVisionState(VISION_STATES.CANCELED, state.visionDataExported);
  state.resultEngine = null;
  state.requestId = null;
  const viewMode = element("view-mode");
  if (viewMode) viewMode.value = "mark";
  state.viewMode = "mark";
  setResultState("还没有生成蒙版");
  setMessage("预览已取消，标记和计算结果已重置。");
  draw();
  if (isCurrentPanel(generation)) setBusy(false);
}

function resetMark() {
  return resetWorkspace({ preserveOptions: true });
}

function resetAll() {
  return resetWorkspace({ preserveOptions: false });
}

function cancelComputation() {
  if (!state.busy || state.cancelRequested || !["compute", "auto", "batch"].includes(state.busyOperation)) return;
  state.cancelRequested = true;
  if (state.requestController) state.requestController.abort();
  if (state.engineMode === "vision-api") {
    setVisionState(VISION_STATES.CANCELED, state.visionDataExported);
  }
  setBusy(true, state.busyOperation);
  setMessage(state.busyOperation === "batch"
    ? "正在停止批量；当前层安全完成后不再处理后续图层。"
    : "正在取消计算；完成当前 Photoshop 操作后会保留 Trimap 和参数。", false);
}

function handleResetAction() {
  if (state.busy) cancelComputation();
  else return resetAll();
}

function markOptionsDirty() {
  if (state.busy) return;
  getOptions();
  state.optionsDirty = Boolean(state.alpha || state.previewActive || state.panelPreviewActive);
  if (!state.optionsDirty) return;
  const apply = element("apply-mask");
  if (apply) apply.disabled = true;
  setResultState("边缘参数已修改，等待重新计算");
  setMessage("边缘参数已修改；点击一键抠图或根据标记重新计算后生效。", false);
}

function syncEdgeOptionsUI() {
  const labels = edgeSettingLabels(state.maskOptions);
  const controls = {
    "edge-shift": state.maskOptions.edgeShift,
    feather: state.maskOptions.feather,
    "hard-threshold": state.maskOptions.hardThreshold,
    "refine-edge-shift": state.maskOptions.edgeShift,
    "refine-feather": state.maskOptions.feather,
    "refine-hard-threshold": state.maskOptions.hardThreshold
  };
  const outputs = {
    "edge-shift-value": labels.edgeShift,
    "feather-value": labels.feather,
    "hard-threshold-value": labels.hardThreshold,
    "refine-edge-shift-value": labels.edgeShift,
    "refine-feather-value": labels.feather,
    "refine-hard-threshold-value": labels.hardThreshold
  };
  Object.entries(controls).forEach(([id, value]) => {
    const control = element(id);
    if (control) control.value = String(value);
  });
  Object.entries(outputs).forEach(([id, value]) => {
    const output = element(id);
    if (output) output.textContent = value;
  });
  ["invert-mask", "refine-invert-mask"].forEach((id) => {
    const control = element(id);
    if (control) control.checked = Boolean(state.maskOptions.invert);
  });
}

function recordWorkspaceOptionChange(before, after) {
  if (!refineEditSession.active || JSON.stringify(before) === JSON.stringify(after)) return;
  state.workspaceHistory.record({ type: "options", before: { ...before }, after: { ...after } });
  updateTrimapHistoryUI();
}

function beginEdgeOptionGesture(event) {
  if (state.busy || !refineEditSession.active || !event || !event.target) return false;
  if (state.workspaceReadOnly && String(event.target.id || "").startsWith("refine-")) return false;
  const key = String(event.target.id || "");
  if (!key) return false;
  if (edgeParameterGesture.active) {
    if (edgeParameterGesture.key === key) return true;
    commitEdgeOptionGesture();
  }
  edgeParameterGesture.begin(key, state.maskOptions);
  return true;
}

function commitEdgeOptionGesture() {
  const command = edgeParameterGesture.commit();
  if (!command) return false;
  recordWorkspaceOptionChange(command.before, command.after);
  return true;
}

function restoreEdgeOptionsFromHistory(options) {
  if (!options) return false;
  state.maskOptions = { ...options };
  state.lowConfidenceApplyArmed = false;
  syncEdgeOptionsUI();
  markOptionsDirty();
  scheduleEdgeLivePreview();
  if (refineEditSession.active) {
    refineEditSession.markChanged();
    syncRefineWorkingSnapshot();
  }
  updateTrimapHistoryUI();
  return true;
}

function handleEdgeOptionInput(event) {
  if (state.busy || !event || !event.target) return;
  if (state.workspaceReadOnly && String(event.target.id || "").startsWith("refine-")) return;
  const keyById = {
    "edge-shift": "edgeShift",
    feather: "feather",
    "hard-threshold": "hardThreshold",
    "refine-edge-shift": "edgeShift",
    "refine-feather": "feather",
    "refine-hard-threshold": "hardThreshold"
  };
  const changedKey = keyById[event.target.id];
  if (!changedKey) return;
  if (refineEditSession.active && !edgeParameterGesture.active) beginEdgeOptionGesture(event);
  state.maskOptions = { ...state.maskOptions };
  state.maskOptions[changedKey] = Number(event.target.value);
  state.maskOptions = { ...state.maskOptions, ...normalizeEdgeSettings(state.maskOptions, changedKey) };
  state.lowConfidenceApplyArmed = false;
  if (refineEditSession.active && edgeParameterGesture.active) {
    edgeParameterGesture.update(state.maskOptions);
  }
  syncEdgeOptionsUI();
  markOptionsDirty();
  scheduleEdgeLivePreview();
}

function handleInvertOptionChange(event) {
  if (state.busy) return;
  if (state.workspaceReadOnly && event && event.target && event.target.id === "refine-invert-mask") return;
  const before = { ...state.maskOptions };
  state.maskOptions = { ...state.maskOptions, invert: Boolean(event && event.target && event.target.checked) };
  state.lowConfidenceApplyArmed = false;
  recordWorkspaceOptionChange(before, state.maskOptions);
  syncEdgeOptionsUI();
  markOptionsDirty();
  scheduleEdgeLivePreview();
}

function resetOptions(fromWorkspace = false) {
  if (state.busy || (fromWorkspace && state.workspaceReadOnly)) return;
  commitEdgeOptionGesture();
  const before = { ...state.maskOptions };
  state.maskOptions = { ...DEFAULT_MASK_OPTIONS };
  state.lowConfidenceApplyArmed = false;
  recordWorkspaceOptionChange(before, state.maskOptions);
  syncEdgeOptionsUI();
  markOptionsDirty();
  scheduleEdgeLivePreview();
  if (!state.optionsDirty) setMessage("边缘参数已恢复默认值。", false);
}

async function cancelPreviewForEditing() {
  if (!state.previewActive || !state.layer || typeof host.cancelMaskPreview !== "function" || state.previewCanceling) return false;
  const generation = state.panelGeneration;
  state.previewCanceling = true;
  try {
    await cancelCurrentPreview();
    if (!isCurrentPanel(generation)) return false;
    setResultState("已进入手动精修");
    return true;
  } catch (error) {
    if (!isCurrentPanel(generation)) return false;
    setMessage(error.message || "取消旧蒙版预览失败。", true);
    return false;
  } finally {
    if (isCurrentPanel(generation)) state.previewCanceling = false;
  }
}

function selectToolButton(tool, activeButton) {
  state.tool = tool;
  if (["unknown", "keep", "cut"].includes(tool)) state.lastPaintTool = tool;
  const root = state.refineRoot;
  (root ? root.querySelectorAll(".tool-button") : []).forEach((item) => item.classList.toggle("active", item === activeButton));
}

async function activatePaintTool(tool, activeButton) {
  if (!refineEditSession.active || state.busy || !state.source) return;
  const generation = state.panelGeneration;
  selectToolButton(tool, activeButton);
  state.workspaceReadOnly = false;
  setBusy(false);
  const modeLabel = element("workspace-mode-label");
  if (modeLabel) modeLabel.textContent = "精修";
  if (state.previewActive) {
    setBusy(true, "prepare-refine");
    const canceled = await cancelPreviewForEditing();
    if (!isCurrentPanel(generation)) return;
    if (!canceled) {
      setBusy(false);
      return;
    }
    state.panelPreviewActive = Boolean(state.alpha);
    setBusy(false);
  }
  state.viewMode = "mark";
  const viewMode = element("view-mode");
  if (viewMode) viewMode.value = "mark";
  draw();
  const frame = element("canvas-frame");
  if (frame && typeof frame.focus === "function") {
    try { frame.focus(); } catch (error) { /* keyboard shortcuts remain available on the dialog */ }
  }
  setMessage(`已选择${tool === "keep" ? "保留" : tool === "cut" ? "删除" : "未知区域"}画笔，请在预览图中按住鼠标涂抹。`);
}

function setBrushSize(value) {
  state.brushSize = clampBrushSize(value);
  const input = element("brush-size");
  const output = element("brush-size-value");
  const cursorOutput = element("brush-cursor-size");
  if (input) input.value = String(state.brushSize);
  if (output) output.textContent = `${state.brushSize} px`;
  if (cursorOutput) cursorOutput.textContent = `${state.brushSize} px`;
  updateBrushCursor();
}

function setBrushSoftness(value) {
  const percent = Math.min(100, Math.max(0, Math.round(Number(value) || 0)));
  state.brushSoftness = percent / 100;
  const input = element("brush-softness");
  const output = element("brush-softness-value");
  if (input) input.value = String(percent);
  if (output) output.textContent = `${percent}%`;
  updateBrushCursor();
}

function effectiveBrushSoftness() {
  return state.tool === "unknown" ? 0 : state.brushSoftness;
}

const REFINE_INPUT_LABELS = Object.freeze({
  down: "按下",
  move: "移动",
  up: "释放",
  wheel: "滚轮",
  "bracket-left": "[",
  "bracket-right": "]"
});

function updateRefineInputStatus(result) {
  const output = element("refine-input-status");
  if (!output) return;
  const passed = Boolean(result && result.passed);
  output.classList.toggle("passed", passed);
  if (passed) {
    output.textContent = "输入诊断完整：已检测到画笔、滚轮、快捷键和坐标映射。";
    return;
  }
  const missing = result && Array.isArray(result.missing)
    ? result.missing.map((kind) => REFINE_INPUT_LABELS[kind] || kind)
    : Object.values(REFINE_INPUT_LABELS);
  output.textContent = `输入诊断：尚未检测到 ${missing.join("、")}；操作会直接响应，请把未消失的项目用于故障反馈。`;
}

function startRefineInputProbe() {
  if (state.refineInputCapability === "passed" && state.refineInputProbe) {
    updateRefineInputStatus(state.refineInputProbe.result());
    return;
  }
  state.refineInputProbe = createUxpInputProbe({ mappingTolerance: 1 });
  state.refineInputCapability = "testing";
  updateRefineInputStatus(state.refineInputProbe.result());
}

function recordRefineInput(event, { mapping = false } = {}) {
  if (!state.refineInputProbe) startRefineInputProbe();
  if (!state.refineInputProbe) return false;
  state.refineInputProbe.recordEvent(event);
  if (mapping && event && event.isTrusted !== false) {
    const canvas = element("preview-canvas");
    if (canvas && typeof canvas.getBoundingClientRect === "function") {
      const rect = canvas.getBoundingClientRect();
      const expected = {
        x: (Number(event.clientX) - rect.left) * (canvas.width / Math.max(1, rect.width)),
        y: (Number(event.clientY) - rect.top) * (canvas.height / Math.max(1, rect.height))
      };
      if (Number.isFinite(expected.x) && Number.isFinite(expected.y)) {
        state.refineInputProbe.recordMapping({
          isTrusted: event.isTrusted,
          expected,
          actual: getCanvasPoint(event, canvas)
        });
      }
    }
  }
  const result = state.refineInputProbe.result();
  state.refineInputCapability = result.passed ? "passed" : "testing";
  updateRefineInputStatus(result);
  return result.passed;
}

function normalizeRefineEvent(event) {
  const canvas = element("preview-canvas");
  const normalized = normalizePointerEvent(event, canvas, state.drawing ? 1 : 0);
  return {
    ...normalized,
    altKey: Boolean(event && event.altKey),
    shiftKey: Boolean(event && event.shiftKey),
    ctrlKey: Boolean(event && event.ctrlKey),
    metaKey: Boolean(event && event.metaKey),
    isTrusted: event && event.isTrusted,
    target: event && event.target,
    preventDefault() {
      if (event && typeof event.preventDefault === "function") event.preventDefault();
    }
  };
}

function drawBrushCursorCanvas() {
  const cursor = element("brush-cursor-canvas");
  const cursorOutput = element("brush-cursor-size");
  const canvas = element("preview-canvas");
  if (!cursor || !canvas) return;
  const navigating = state.refineInteraction
    && (state.refineInteraction.spacePressed || state.refineInteraction.mode === "pan");
  const point = state.lastPreviewClientPoint;
  if (!point || !state.previewPointerInside || !state.source || !refineEditSession.active || state.busy
    || state.workspaceReadOnly
    || !["unknown", "keep", "cut"].includes(state.tool)
    || state.viewMode !== "mark" || navigating) {
    cursor.style.display = "none";
    if (cursorOutput) cursorOutput.style.display = "none";
    return;
  }
  const rect = canvas.getBoundingClientRect();
  const scale = rect.width / Math.max(1, canvas.width);
  const geometry = brushRingGeometry({
    brushSize: state.brushSize,
    softness: effectiveBrushSoftness(),
    scale
  });
  const padding = 4;
  const size = Math.max(1, Math.ceil(geometry.outerDiameter + padding * 2));
  if (cursor.width !== size || cursor.height !== size) {
    cursor.width = size;
    cursor.height = size;
  }
  cursor.style.width = `${size}px`;
  cursor.style.height = `${size}px`;
  cursor.style.left = `${point.clientX - rect.left - size / 2}px`;
  cursor.style.top = `${point.clientY - rect.top - size / 2}px`;
  cursor.style.display = "block";
  if (cursorOutput) {
    cursorOutput.textContent = `${state.brushSize} px`;
    cursorOutput.style.left = `${point.clientX - rect.left}px`;
    cursorOutput.style.top = `${point.clientY - rect.top - geometry.outerDiameter / 2 - 26}px`;
    cursorOutput.style.display = "block";
  }
  const context = typeof cursor.getContext === "function" ? cursor.getContext("2d") : null;
  if (!context) return;
  if (typeof context.clearRect === "function") context.clearRect(0, 0, size, size);
  const softness = effectiveBrushSoftness();
  const colors = state.tool === "keep"
    ? { stroke: "#55e09a", fill: "rgba(85, 224, 154, 0.16)" }
    : state.tool === "cut"
      ? { stroke: "#ff7777", fill: "rgba(255, 119, 119, 0.16)" }
      : { stroke: "#4eaeff", fill: "rgba(78, 174, 255, 0.14)" };
  if (typeof context.save === "function") context.save();
  context.strokeStyle = colors.stroke;
  context.fillStyle = colors.fill;
  context.lineWidth = 2;
  context.beginPath();
  context.arc(size / 2, size / 2, geometry.outerDiameter / 2, 0, Math.PI * 2);
  if (typeof context.fill === "function") context.fill();
  context.stroke();
  if (softness > 0 && softness < 1) {
    context.beginPath();
    context.arc(size / 2, size / 2, geometry.coreDiameter / 2, 0, Math.PI * 2);
    context.stroke();
  }
  if (typeof context.restore === "function") context.restore();
}

function updateBrushCursor(event) {
  if (event && Number.isFinite(Number(event.clientX)) && Number.isFinite(Number(event.clientY))) {
    state.lastPreviewClientPoint = { clientX: Number(event.clientX), clientY: Number(event.clientY) };
  }
  drawBrushCursorCanvas();
}

function hideBrushCursor() {
  const cursor = element("brush-cursor-canvas");
  const cursorOutput = element("brush-cursor-size");
  if (cursor) cursor.style.display = "none";
  if (cursorOutput) cursorOutput.style.display = "none";
}

function releaseBrushCursorCanvas() {
  const cursor = element("brush-cursor-canvas");
  if (!cursor) return;
  hideBrushCursor();
  cursor.width = 1;
  cursor.height = 1;
  cursor.style.width = "1px";
  cursor.style.height = "1px";
}

function startPaintAt(point, pointerId, continueStroke = true) {
  const canvas = element("preview-canvas");
  const inputTarget = canvas;
  if (!refineEditSession.active || state.workspaceReadOnly || !canvas || !state.trimap) return;
  if (state.trimapHistory) state.trimap = state.trimapHistory.beginStroke();
  state.viewMode = "mark";
  state.drawing = continueStroke;
  state.lastPoint = point;
  state.trimap.paintCircle(state.lastPoint.x, state.lastPoint.y, state.brushSize / 2, getLabel(), effectiveBrushSoftness());
  if (refineEditSession.active) refineEditSession.markChanged();
  state.workDirty = true;
  state.trimapDirty = true;
  state.trimapRenderVersion += 1;
  if (refineEditSession.active) syncRefineWorkingSnapshot();
  setResultState("标记已修改，等待重新计算");
  draw();
  if (continueStroke && inputTarget && typeof inputTarget.setPointerCapture === "function" && pointerId !== undefined) {
    try { inputTarget.setPointerCapture(pointerId); } catch (error) { /* document listeners provide the fallback */ }
  }
}

async function beginPaint(event) {
  if (!refineEditSession.active || state.workspaceReadOnly || !state.trimap || state.busy || state.previewCanceling) return;
  const generation = state.panelGeneration;
  const canvas = element("preview-canvas");
  const point = getCanvasPoint(event, canvas);
  state.pendingPaintPointerId = event.pointerId;
  if (typeof event.preventDefault === "function") event.preventDefault();
  if (state.previewActive) {
    setBusy(true, "prepare-refine");
    const canceled = await cancelPreviewForEditing();
    if (!isCurrentPanel(generation)) return;
    if (!canceled) {
      state.pendingPaintPointerId = null;
      setBusy(false);
      return;
    }
  }
  const continueStroke = state.pendingPaintPointerId === event.pointerId;
  state.pendingPaintPointerId = null;
  if (state.busyOperation === "prepare-refine") setBusy(false);
  startPaintAt(point, continueStroke ? event.pointerId : undefined, continueStroke);
  updateBrushCursor(event);
}

function continuePaint(event) {
  if (state.refineInteraction && state.refineInteraction.mode === "pan") return;
  updateBrushCursor(event);
  if (!refineEditSession.active || state.busy || !state.drawing || !state.trimap) return;
  const canvas = element("preview-canvas");
  const point = getCanvasPoint(event, canvas);
  const previousPoint = state.lastPoint;
  state.trimap.paintLine(previousPoint.x, previousPoint.y, point.x, point.y, state.brushSize / 2, getLabel(), effectiveBrushSoftness());
  if (refineEditSession.active) refineEditSession.markChanged();
  state.lastPoint = point;
  state.trimapDirty = true;
  state.trimapRenderVersion += 1;
  drawLiveStroke(previousPoint, point);
}

function updateTrimapHistoryUI() {
  const history = state.trimapHistory;
  const workspaceHistory = state.workspaceHistory;
  const undo = element("refine-undo");
  const redo = element("refine-redo");
  if (undo) undo.disabled = state.busy || state.workspaceReadOnly || !history || !workspaceHistory.canUndo;
  if (redo) redo.disabled = state.busy || state.workspaceReadOnly || !history || !workspaceHistory.canRedo;
}

function restoreTrimapFromHistory(snapshot) {
  if (!snapshot) return false;
  state.trimap = snapshot;
  state.trimapDirty = Boolean(state.trimapHistory && state.trimapHistory.pendingCount > 0);
  state.workDirty = true;
  state.viewMode = "mark";
  state.trimapRenderVersion += 1;
  if (refineEditSession.active) {
    refineEditSession.markChanged();
    syncRefineWorkingSnapshot();
  }
  const viewMode = element("view-mode");
  if (viewMode) viewMode.value = "mark";
  updateTrimapHistoryUI();
  setBusy(false);
  draw();
  return true;
}

function undoTrimapStroke() {
  if (state.workspaceReadOnly) return false;
  const actionEntry = state.workspaceHistory.undo();
  if (!actionEntry) return false;
  if (actionEntry.type === "stroke") {
    return restoreTrimapFromHistory(state.trimapHistory && state.trimapHistory.undo());
  }
  return restoreEdgeOptionsFromHistory(actionEntry.before);
}

function redoTrimapStroke() {
  if (state.workspaceReadOnly) return false;
  const actionEntry = state.workspaceHistory.redo();
  if (!actionEntry) return false;
  if (actionEntry.type === "stroke") {
    return restoreTrimapFromHistory(state.trimapHistory && state.trimapHistory.redo());
  }
  return restoreEdgeOptionsFromHistory(actionEntry.after);
}

function endPaint(event) {
  const completedStroke = state.drawing;
  if (!event || state.pendingPaintPointerId === event.pointerId) state.pendingPaintPointerId = null;
  state.drawing = false;
  state.lastPoint = null;
  if (completedStroke && state.trimapHistory && state.trimap) {
    state.trimap = state.trimapHistory.commitStroke(state.trimap);
    state.workspaceHistory.record({ type: "stroke" });
    state.trimapDirty = state.trimapHistory.pendingCount > 0;
    updateTrimapHistoryUI();
  }
  if (state.paintScheduler) state.paintScheduler.schedule();
}

function cancelActiveStroke() {
  if (!state.drawing || !state.trimapHistory) return false;
  state.drawing = false;
  state.pendingPaintPointerId = null;
  state.lastPoint = null;
  state.trimap = state.trimapHistory.current;
  state.trimapDirty = state.trimapHistory.pendingCount > 0;
  state.trimapRenderVersion += 1;
  if (state.refineInteraction) state.refineInteraction.reset();
  if (refineEditSession.active) syncRefineWorkingSnapshot();
  updateTrimapHistoryUI();
  syncPreviewPanClasses();
  setResultState(state.trimapDirty ? "标记已修改，等待重新计算" : "已取消当前笔画");
  draw();
  return true;
}

function leavePreview(event) {
  state.previewPointerInside = false;
  hideBrushCursor();
}

function syncPreviewPanClasses(next) {
  const frame = element("canvas-frame");
  if (!frame) return;
  const interaction = next || state.refineInteraction;
  frame.classList.toggle("pan-ready", Boolean(interaction && interaction.spacePressed));
  frame.classList.toggle("is-panning", Boolean(interaction && interaction.mode === "pan"));
}

function handlePreviewKeyDown(event) {
  if (event === state.lastShortcutEvent) return;
  state.lastShortcutEvent = event;
  if (!state.refineDialogOpen || !refineEditSession.active || !state.source || state.busy) return;
  recordRefineInput(event);
  const shortcut = shortcutFromKeyboard(event);
  if (!shortcut) return;
  if (shortcut.kind === "cancel-stroke") {
    if (cancelActiveStroke() && typeof event.preventDefault === "function") event.preventDefault();
    return;
  }
  if (state.workspaceReadOnly && ["brush-size", "brush-softness", "undo", "redo"].includes(shortcut.kind)) return;
  if (shortcut.kind === "brush-size") {
    setBrushSize(state.brushSize + shortcut.delta * 4);
  } else if (shortcut.kind === "brush-softness") {
    setBrushSoftness(state.brushSoftness * 100 + shortcut.delta * 5);
  } else if (shortcut.kind === "undo") {
    undoTrimapStroke();
  } else if (shortcut.kind === "redo") {
    redoTrimapStroke();
  } else if (shortcut.kind === "tool") {
    const button = state.refineRoot && state.refineRoot.querySelector(`[data-tool="${shortcut.tool}"]`);
    if (button) selectToolButton(shortcut.tool, button);
    hideBrushCursor();
  } else if (shortcut.kind === "space" && shortcut.pressed && state.previewPointerInside) {
    if (state.refineInteraction) state.refineInteraction.setSpacePressed(true);
    syncPreviewPanClasses();
    hideBrushCursor();
  }
  if (typeof event.preventDefault === "function") event.preventDefault();
}

function handlePreviewKeyUp(event) {
  const shortcut = shortcutFromKeyboard(event);
  if (!shortcut || shortcut.kind !== "space" || shortcut.pressed) return;
  const handled = Boolean(state.refineInteraction && state.refineInteraction.spacePressed);
  if (state.refineInteraction) state.refineInteraction.setSpacePressed(false);
  syncPreviewPanClasses();
  if (handled && typeof event.preventDefault === "function") event.preventDefault();
}

function enterPreview(event) {
  state.previewPointerInside = true;
  updateBrushCursor(event);
}

function beginPreviewInteraction(event) {
  recordRefineInput(event, { mapping: true });
  if (!refineEditSession.active || state.busy || !isPrimaryButton(event) || !state.refineInteraction || !state.trimap) return;
  if (state.drawing || state.refineInteraction.mode !== "idle" || state.busyOperation === "prepare-refine") return;
  const frame = element("canvas-frame");
  if (frame && typeof frame.focus === "function") {
    try { frame.focus(); } catch (error) { /* focus is only needed for Space handling */ }
  }
  if (state.tool === "zoom") {
    if (typeof event.preventDefault === "function") event.preventDefault();
    setZoom(state.zoom * (event.altKey ? 0.8 : 1.25));
    return;
  }
  if (state.tool === "hand") state.refineInteraction.setSpacePressed(true);
  if (state.workspaceReadOnly && !["hand", "zoom"].includes(state.tool)) return;
  const action = state.refineInteraction.begin(event);
  if (!action) return;
  if (typeof event.preventDefault === "function") event.preventDefault();
  syncPreviewPanClasses();
  if (action.kind === "pan-start") {
    hideBrushCursor();
    return;
  }
  void trackOperation(beginPaint(event));
}

function beginPreviewFrameInteraction(event) {
  const frame = element("canvas-frame");
  if (!frame || event.target !== frame || !state.refineInteraction || !state.refineInteraction.spacePressed) return;
  beginPreviewInteraction(event);
}

function continuePreviewSurfaceInteraction(event) {
  state.lastSurfaceMoveEvent = event.originalEvent || event;
  recordRefineInput(event, { mapping: true });
  continuePreviewInteraction(event);
}

function continuePreviewDocumentInteraction(event) {
  if ((event.originalEvent || event) === state.lastSurfaceMoveEvent) return;
  recordRefineInput(event, { mapping: true });
  if (!state.drawing && !(state.refineInteraction && state.refineInteraction.mode === "pan")) return;
  continuePreviewInteraction(event);
}

function endPreviewSurfaceInteraction(event) {
  state.lastSurfaceEndEvent = event.originalEvent || event;
  recordRefineInput(event, { mapping: true });
  endPreviewInteraction(event);
}

function endPreviewDocumentInteraction(event) {
  if ((event.originalEvent || event) === state.lastSurfaceEndEvent) return;
  recordRefineInput(event, { mapping: true });
  if (!state.drawing && !(state.refineInteraction && state.refineInteraction.mode !== "idle") && state.pendingPaintPointerId === null) return;
  endPreviewInteraction(event);
}

function endActivePreviewInteraction() {
  if (state.drawing || state.pendingPaintPointerId !== null) endPaint();
  state.pendingPaintPointerId = null;
  if (state.refineInteraction) state.refineInteraction.reset();
  syncPreviewPanClasses();
  state.previewPointerInside = false;
  hideBrushCursor();
}

function continuePreviewInteraction(event) {
  if (!state.refineInteraction) return;
  const action = state.refineInteraction.move(event);
  if (action && action.kind === "pan") {
    const frame = element("canvas-frame");
    if (frame) {
      frame.scrollLeft += action.scrollDeltaX;
      frame.scrollTop += action.scrollDeltaY;
    }
    hideBrushCursor();
    return;
  }
  if (action && action.kind === "paint") continuePaint(event);
  else updateBrushCursor(event);
}

function endPreviewInteraction(event) {
  if (!state.refineInteraction) return;
  const action = state.refineInteraction.end(event);
  if (state.tool === "hand") state.refineInteraction.setSpacePressed(false);
  syncPreviewPanClasses();
  if (action && action.kind === "pan-end") {
    hideBrushCursor();
    return;
  }
  if (action && action.kind === "paint-end") endPaint(event);
}

function retryLastOperation() {
  if (state.busy) return;
  const retry = element("retry-compute");
  if (!state.retryPendingConfirmation) {
    state.retryPendingConfirmation = true;
    if (retry) retry.textContent = "确认重试（可能计费）";
    const acceptedWarning = state.lastError && state.lastError.accepted
      ? "服务可能已接受上一次请求。"
      : "重试会提交一个新的 AI 请求。";
    setMessage(`${acceptedWarning} 再次点击确认重试，可能产生重复费用。`, true);
    return;
  }
  clearErrorActions();
  if (state.lastOperation === "auto") return autoCutout();
  if (state.lastOperation === "compute") return computeMask();
}

function switchToLocalEngine() {
  clearErrorActions();
  const mode = element("engine-mode");
  if (mode) mode.value = "algorithm";
  selectEngineMode("algorithm");
}

function selectionLayerKey(layer) {
  if (!layer || !layer.bounds) return null;
  const bounds = layer.bounds;
  return [
    Number(layer.documentID),
    Number(layer.layerID),
    Number(bounds.left),
    Number(bounds.top),
    Number(bounds.width),
    Number(bounds.height)
  ].join(":");
}

function inspectPhotoshopSelection() {
  let selection;
  try {
    selection = host.getSelectedPixelLayers();
  } catch (error) {
    return { status: "unavailable", error };
  }
  const layers = Array.isArray(selection.layers) ? selection.layers : [];
  const skipped = Array.isArray(selection.skipped) ? selection.skipped : [];
  const total = layers.length + skipped.length;
  if (total > 1) return { status: "multiple", count: total, layers, skipped };
  if (layers.length !== 1 || skipped.length) return { status: "unsupported", count: total, layers, skipped };
  return { status: "ready", key: selectionLayerKey(layers[0]), layer: layers[0] };
}

function isAutoSelectionBlocked(inspection) {
  const loadedKey = selectionLayerKey(state.layer);
  const contextChanged = Boolean(inspection && inspection.status === "ready" && loadedKey && inspection.key !== loadedKey);
  const cancelableWork = state.busy && ["compute", "auto"].includes(state.busyOperation);
  return Boolean(
    !state.mounted
    || !state.mainMounted
    || (state.busy && !(contextChanged && cancelableWork))
    || state.lifecycleWaiting
    || state.restoreFailed
    || (!contextChanged && (
      state.previewActive
      || state.previewPromise
      || state.workDirty
      || refineEditSession.active
    ))
  );
}

function discardLoadedStateForUnavailableSelection() {
  if (state.busy && !abortCancelableWorkForReload()) {
    state.selectionRefreshPending = true;
    return false;
  }
  state.selectionRefreshPending = false;
  if (refineEditSession.active) refineEditSession.cancel();
  state.refineBaselinePreviewActive = false;
  closeRefineDialog("selection-change");
  resetRefineInteractionState();
  // Current releases never write a temporary preview. If an older in-memory
  // flag survives a reload, an ambiguous selection must not target that layer.
  state.previewActive = false;
  state.previewPromise = null;
  state.restoreFailed = false;
  clearErrorActions();
  clearLoadedLayerState();
  return true;
}

function showSelectionState(inspection) {
  if (!inspection || inspection.status === "ready" || inspection.status === "current") return;
  discardLoadedStateForUnavailableSelection();
  const status = element("layer-status");
  const refineStatus = element("refine-layer-status");
  if (inspection.status === "multiple") {
    if (status) status.textContent = `已选择 ${inspection.count} 个图层`;
    if (refineStatus) refineStatus.textContent = `已选择 ${inspection.count} 个图层；精修仅支持单图层`;
    setMessage(`已选择 ${inspection.count} 个图层，可直接点击“批量抠图所选图层”。`);
    return;
  }
  if (inspection.status === "unsupported") {
    const name = inspection.skipped && inspection.skipped[0] && inspection.skipped[0].name;
    const reason = inspection.skipped && inspection.skipped[0] && inspection.skipped[0].reason
      || "请选择一个可写入蒙版的普通像素图层。";
    if (status) status.textContent = name ? `${name} · 不支持的图层类型` : "请选择像素图层";
    if (refineStatus) refineStatus.textContent = name ? `${name} · 不支持的图层类型` : "请选择像素图层";
    setMessage(reason, true);
    return;
  }
  if (inspection.status === "unavailable") {
    if (status) status.textContent = "暂时无法读取 Photoshop 图层";
    if (refineStatus) refineStatus.textContent = "暂时无法读取 Photoshop 图层";
    showLayerReadError(inspection.error);
    return;
  }
  if (status) status.textContent = "等待 Photoshop 图层";
  if (refineStatus) refineStatus.textContent = "等待 Photoshop 图层";
  setMessage("打开文档并选择一个像素图层后，插件会自动读取。", false);
}

function initializeSelectionSync() {
  if (state.selectionSync) state.selectionSync.dispose();
  state.selectionSync = createSelectionSync({
    inspectSelection: inspectPhotoshopSelection,
    shouldBlock: isAutoSelectionBlocked,
    getLoadedKey: () => selectionLayerKey(state.layer),
    load: (layer, options) => trackOperation(loadLayer({ ...options, layer })),
    onSelection: showSelectionState,
    onBlocked: (inspection) => {
      const loadedKey = selectionLayerKey(state.layer);
      if (inspection && inspection.status === "ready" && inspection.key !== loadedKey) {
        state.selectionRefreshPending = true;
      }
    },
    onError: showSelectionSyncError
  });
}

function registerPhotoshopNotifications() {
  if (!action || typeof action.addNotificationListener !== "function") return;
  const token = state.notificationToken + 1;
  state.notificationToken = token;
  const events = ["select", "open", "close", "delete"].map((event) => ({ event }));
  const handler = () => {
    if (state.mounted && state.selectionSync) state.selectionSync.schedule("photoshop-notification");
  };
  state.notificationEvents = events;
  state.notificationHandler = handler;
  state.notificationRegistered = false;
  Promise.resolve(action.addNotificationListener(events, handler))
    .then(() => {
      if (!state.mounted || token !== state.notificationToken) {
        if (typeof action.removeNotificationListener === "function") {
          return action.removeNotificationListener(events, handler);
        }
        return undefined;
      }
      state.notificationRegistered = true;
      return undefined;
    })
    .catch(() => {});
}

function unregisterPhotoshopNotifications() {
  state.notificationToken += 1;
  const events = state.notificationEvents;
  const handler = state.notificationHandler;
  const registered = state.notificationRegistered;
  state.notificationEvents = null;
  state.notificationHandler = null;
  state.notificationRegistered = false;
  if (registered && action && typeof action.removeNotificationListener === "function" && events && handler) {
    Promise.resolve(action.removeNotificationListener(events, handler)).catch(() => {});
  }
}

function initializeWorkspace() {
  if (state.mounted) return;
  state.mounted = true;
  state.panelGeneration += 1;
  initializeSelectionSync();
  registerPhotoshopNotifications();
}

function resolvePanelRoot(rootNodeOrEvent) {
  return rootNodeOrEvent && rootNodeOrEvent.node
    ? rootNodeOrEvent.node
    : rootNodeOrEvent;
}

function ensureRefineSession(entryMode = "refine") {
  if (refineEditSession.active) return Promise.resolve(true);
  if (state.refineSessionPromise) return state.refineSessionPromise;
  const operation = trackOperation(beginRefineSession(entryMode));
  state.refineSessionPromise = operation;
  const settled = () => {
    if (state.refineSessionPromise === operation) state.refineSessionPromise = null;
  };
  operation.then(settled, settled);
  return operation;
}

function closeRefineDialog(returnValue = "cancel") {
  const dialog = element("refine-dialog");
  state.refineDialogOpen = false;
  resetRefineInteractionState();
  if (!dialog || typeof dialog.close !== "function") return false;
  try {
    dialog.close(returnValue);
    return true;
  } catch (error) {
    return false;
  }
}

async function settleRefineDialog(token, rejected = false) {
  if (token !== state.refineDialogToken) return false;
  const actionName = state.refineDialogAction || "cancel";
  state.refineDialogAction = null;
  state.refineDialogOpen = false;
  state.refineDialogPromise = null;
  resetRefineInteractionState();
  releaseBrushCursorCanvas();
  if (refineEditSession.active && state.busy) {
    if (!abortCancelableWorkForReload()) await settleActiveOperations();
  }
  if (token !== state.refineDialogToken) return false;
  if (refineEditSession.active) {
    if (actionName === "apply") {
      const applied = await applyRefineSession();
      if (!applied) setMessage("蒙版未应用；精修内容仍保留，重新打开精修窗口即可继续。", true);
    } else {
      await cancelRefineSession();
    }
  }
  if (rejected && actionName !== "apply") setMessage("精修窗口已关闭，未应用的修改已取消。", false);
  if (state.selectionSync) state.selectionSync.schedule("refine-dialog-close", 0);
  return true;
}

async function dismissRefineDialog(actionName = "cancel") {
  if (!refineEditSession.active || state.busy || !state.refineDialogOpen) return false;
  state.refineDialogAction = actionName === "apply" ? "apply" : "cancel";
  if (closeRefineDialog(state.refineDialogAction)) return true;
  state.refineDialogAction = null;
  setMessage("关闭精修窗口失败，请重试。", true);
  return false;
}

function showRefineModal(dialog) {
  const options = {
    title: "抠图精修",
    titleVisibility: "show",
    resize: "both",
    size: { width: 1100, height: 820 },
    minSize: { width: 640, height: 480 },
    maxSize: { width: 1600, height: 1200 },
    lockDocumentFocus: true
  };
  if (typeof dialog.uxpShowModal === "function") return dialog.uxpShowModal(options);
  return dialog.showModal(options);
}

async function openRefineDialog(entryMode = "refine") {
  const generation = state.panelGeneration;
  if (!canUseMainPanel(generation)) return false;
  if (!state.refineMounted && !mountRefineDialog()) return false;
  const dialog = element("refine-dialog");
  if (!dialog || (typeof dialog.uxpShowModal !== "function" && typeof dialog.showModal !== "function")) {
    setMessage("当前 Photoshop 版本无法打开精修窗口。", true);
    return false;
  }
  if (state.refineDialogOpen) return true;
  if (state.refineDialogSettlement) {
    try { await state.refineDialogSettlement; } catch (error) { /* close cleanup still completes */ }
  }
  if (!canUseMainPanel(generation)) return false;
  if (state.refineDialogOpen) return true;
  if (state.refineDialogPromise) {
    try { await state.refineDialogPromise; } catch (error) { /* a dismissed dialog is expected */ }
  }
  if (!canUseMainPanel(generation)) return false;
  if (state.refineDialogOpen) return true;
  const ready = await ensureRefineSession(entryMode);
  if (!canUseMainPanel(generation)) return false;
  if (!ready) return false;
  state.viewMode = entryMode === "view" && state.alpha ? "cutout-transparent" : "mark";
  state.workspaceReadOnly = entryMode === "view";
  if (entryMode === "refine") {
    const paintTool = state.lastPaintTool || "unknown";
    const paintButton = state.refineRoot && state.refineRoot.querySelector(`[data-tool="${paintTool}"]`);
    if (paintButton) selectToolButton(paintTool, paintButton);
  }
  setBusy(state.busy, state.busyOperation);
  const viewMode = element("view-mode");
  if (viewMode) viewMode.value = state.viewMode;
  const modeLabel = element("workspace-mode-label");
  if (modeLabel) modeLabel.textContent = entryMode === "view" ? "查看" : "精修";
  if (state.refineDialogOpen) return true;
  startRefineInputProbe();

  const token = state.refineDialogToken + 1;
  state.refineDialogToken = token;
  state.refineDialogAction = null;
  state.refineDialogOpen = true;
  let showPromise;
  try {
    showPromise = showRefineModal(dialog);
  } catch (error) {
    state.refineDialogOpen = false;
    await settleRefineDialog(token, true);
    setMessage(error.message || "打开精修窗口失败。", true);
    return false;
  }

  const pending = Promise.resolve(showPromise);
  state.refineDialogPromise = pending;
  const settlement = pending.then(
    () => settleRefineDialog(token, false),
    () => settleRefineDialog(token, true)
  );
  state.refineDialogSettlement = settlement;
  const clearSettlement = () => {
    if (state.refineDialogSettlement === settlement) state.refineDialogSettlement = null;
  };
  settlement.then(clearSettlement, clearSettlement);
  Promise.resolve().then(() => {
    draw();
    fitZoomToWindow();
    const frame = element("canvas-frame");
    if (frame && typeof frame.focus === "function") {
      try { frame.focus(); } catch (error) { /* mouse input remains available */ }
    }
  });
  setMessage("抠图精修窗口已打开；选择画笔后直接在图像上涂抹。", false);
  return true;
}

function folderEntryLabel(entry) {
  if (!entry) return "尚未选择";
  return String(entry.name || "已授权目录");
}

function updateFolderBatchUI() {
  const sourcePath = element("folder-source-path");
  const outputPath = element("folder-output-path");
  const start = element("folder-batch-start");
  const stop = element("folder-batch-stop");
  const dialogBusy = state.busyOperation === "folder-batch";
  if (sourcePath) sourcePath.textContent = folderEntryLabel(state.folderSource);
  if (outputPath) outputPath.textContent = folderEntryLabel(state.folderOutput);
  if (start) start.disabled = state.busy || !state.folderSource || !state.folderOutput || !folderHost;
  if (stop) stop.disabled = state.busyOperation !== "folder-batch" || !state.folderBatchController;
  ["folder-source-pick", "folder-output-pick", "folder-recursive", "folder-preset", "folder-batch-cancel"]
    .map((id) => element(id))
    .filter(Boolean)
    .forEach((control) => { control.disabled = dialogBusy; });
}

function setFolderBatchProgress({ status, percent, current, succeeded, failed, skipped, canceled } = {}) {
  const setText = (id, value) => {
    const node = element(id);
    if (node && value !== undefined) node.textContent = String(value);
  };
  setText("folder-batch-status", status);
  setText("folder-current-file", current);
  setText("folder-success-count", succeeded);
  setText("folder-failure-count", failed);
  setText("folder-skipped-count", skipped);
  setText("folder-canceled-count", canceled);
  const progress = element("folder-progress");
  if (progress && percent !== undefined) progress.value = Math.max(0, Math.min(100, Number(percent) || 0));
}

async function pickFolder(kind) {
  if (!folderHost || state.busy) return false;
  try {
    const selected = await folderHost.pickFolder();
    if (!selected) return false;
    if (kind === "source") state.folderSource = selected;
    else state.folderOutput = selected;
    await folderHost.rememberFolder(`ps-offline-mask-folder-${kind}`, selected).catch(() => undefined);
    updateFolderBatchUI();
    await refreshFolderBatchScan();
    return true;
  } catch (error) {
    setFolderBatchProgress({ status: `目录选择失败：${error.message || error}` });
    return false;
  }
}

async function refreshFolderBatchScan() {
  const token = state.folderScanToken + 1;
  state.folderScanToken = token;
  const count = element("folder-file-count");
  if (!state.folderSource || !state.folderOutput) {
    if (count) count.textContent = "0 个文件";
    return null;
  }
  const recursive = Boolean(element("folder-recursive") && element("folder-recursive").checked);
  setFolderBatchProgress({ status: "正在扫描…", current: "读取目录内容" });
  try {
    const scanned = await scanSourceFolder({
      sourceFolder: state.folderSource,
      outputFolder: state.folderOutput,
      recursive
    });
    if (token !== state.folderScanToken) return null;
    if (count) count.textContent = `${scanned.items.length} 个文件`;
    setFolderBatchProgress({
      status: "等待开始",
      current: `可处理 ${scanned.items.length} 个文件`,
      succeeded: 0,
      failed: 0,
      skipped: scanned.skipped.length,
      canceled: 0,
      percent: 0
    });
    return scanned;
  } catch (error) {
    if (token !== state.folderScanToken) return null;
    if (count) count.textContent = "0 个文件";
    setFolderBatchProgress({
      status: "扫描失败",
      current: "无法读取所选目录，请重新授权或检查文件权限。"
    });
    return null;
  }
}

async function restoreFolderBatchChoices() {
  if (!folderHost) return;
  const [source, output] = await Promise.all([
    folderHost.restoreFolder("ps-offline-mask-folder-source"),
    folderHost.restoreFolder("ps-offline-mask-folder-output")
  ]);
  if (source) state.folderSource = source;
  if (output) state.folderOutput = output;
  updateFolderBatchUI();
}

function closeFolderBatchDialog() {
  const dialog = element("folder-batch-dialog");
  if (!dialog || state.busyOperation === "folder-batch") return false;
  state.folderBatchDialogOpen = false;
  try {
    if (typeof dialog.close === "function") dialog.close("close");
  } catch (error) {
    return false;
  }
  return true;
}

async function openFolderBatchDialog() {
  const dialog = element("folder-batch-dialog");
  if (!dialog || !folderHost) {
    setMessage("当前 Photoshop 无法使用文件夹授权或透明 PNG 导出。", true);
    return false;
  }
  if (state.folderBatchDialogOpen) return true;
  await restoreFolderBatchChoices();
  updateFolderBatchUI();
  state.folderBatchDialogOpen = true;
  void refreshFolderBatchScan();
  try {
    const shown = typeof dialog.uxpShowModal === "function"
      ? dialog.uxpShowModal({
        title: "文件夹批量抠图",
        titleVisibility: "show",
        resize: "both",
        size: { width: 560, height: 640 },
        minSize: { width: 480, height: 520 },
        maxSize: { width: 900, height: 900 }
      })
      : dialog.showModal();
    Promise.resolve(shown).finally(() => { state.folderBatchDialogOpen = false; });
    return true;
  } catch (error) {
    state.folderBatchDialogOpen = false;
    setMessage(`打开文件夹批量窗口失败：${error.message || error}`, true);
    return false;
  }
}

async function reserveBatchReportFile(outputFolder) {
  if (!outputFolder || typeof outputFolder.getEntries !== "function"
    || typeof outputFolder.createFile !== "function") {
    throw new TypeError("输出目录不能创建批量报告");
  }
  const existing = new Set((await outputFolder.getEntries())
    .map((entry) => String(entry && entry.name || "").toLowerCase()));
  for (let sequence = 1; sequence < 1000; sequence += 1) {
    const name = sequence === 1 ? "ps-mask-report.json" : `ps-mask-report_${sequence}.json`;
    if (existing.has(name.toLowerCase())) continue;
    try {
      return await outputFolder.createFile(name, { overwrite: false });
    } catch (error) {
      const detail = `${String(error && error.name || "")} ${String(error && error.code || "")} ${String(error && error.message || "")}`;
      if (!/entryexists|already exists|alreadyexists/i.test(detail)) throw error;
    }
  }
  throw new Error("无法为批量报告分配唯一文件名");
}

async function writeFolderBatchReport(report) {
  const file = await reserveBatchReportFile(state.folderOutput);
  if (!file || typeof file.write !== "function") throw new TypeError("批量报告文件不可写");
  try {
    await file.write(JSON.stringify(report, null, 2));
    return file.name;
  } catch (error) {
    if (typeof file.delete === "function") {
      try { await file.delete(); } catch (cleanupError) { /* preserve the original report failure */ }
    }
    throw error;
  }
}

async function processFolderSource(source, signal, batchOptions) {
  const generated = await autoTrimapAsync({
    pixels: source.pixels,
    width: source.width,
    height: source.height,
    components: source.components,
    ...(signal ? { signal } : {})
  });
  const confidence = Number(generated && generated.diagnostics && generated.diagnostics.confidence);
  if (Number.isFinite(confidence) && confidence < 0.55) {
    const error = new Error(`本地算法置信度不足（${Math.round(confidence * 100)}%），需要精修`);
    error.stage = "quality";
    error.code = "low-confidence";
    throw error;
  }
  let prepared;
  try {
    prepared = prepareAutoTrimapForEngine(generated, "algorithm");
  } catch (error) {
    error.stage = error.stage || "quality";
    throw error;
  }
  const context = algorithmContext(prepared);
  const response = await folderBatchEngine.compute({
    pixels: source.pixels,
    width: source.width,
    height: source.height,
    components: source.components,
    trimap: prepared.trimap.data,
    ...context,
    requestId: createRequestId(),
    ...(signal ? { signal } : {}),
    options: {
      ...batchOptions,
      ...(context.background ? { decontaminate: true } : {})
    }
  });
  const warnings = [
    ...(Array.isArray(generated && generated.diagnostics && generated.diagnostics.warnings)
      ? generated.diagnostics.warnings : []),
    ...(Array.isArray(response && response.diagnostics && response.diagnostics.warnings)
      ? response.diagnostics.warnings : []),
    ...(response && response.diagnostics && response.diagnostics.warning
      ? [response.diagnostics.warning] : [])
  ].filter((value, index, all) => typeof value === "string" && all.indexOf(value) === index);
  return {
    alpha: response.alpha,
    foreground: response.foreground,
    engine: String(response && response.diagnostics && response.diagnostics.strategy
      || (folderBatchEngine.kind === "native" ? "native-algorithm" : "fallback-algorithm")),
    warnings
  };
}

async function startFolderBatch() {
  if (!folderHost || !state.folderSource || !state.folderOutput || state.busy) return false;
  const recursive = Boolean(element("folder-recursive") && element("folder-recursive").checked);
  const preset = element("folder-preset") ? element("folder-preset").value : "current";
  const configuredOptions = folderBatchOptionsForPreset(preset, state.maskOptions);
  const batchOptions = { ...configuredOptions, ...normalizeEdgeSettings(configuredOptions) };
  const controller = typeof AbortController === "function" ? new AbortController() : null;
  state.folderBatchController = controller;
  setBusy(true, "folder-batch");
  updateFolderBatchUI();
  setFolderBatchProgress({ status: "扫描文件…", percent: 0, current: "正在扫描源目录", succeeded: 0, failed: 0, skipped: 0, canceled: 0 });
  try {
    const scanned = await scanSourceFolder({
      sourceFolder: state.folderSource,
      outputFolder: state.folderOutput,
      recursive,
      signal: controller && controller.signal
    });
    const count = element("folder-file-count");
    if (count) count.textContent = `${scanned.items.length} 个文件`;
    const result = await runFolderBatch({
      items: scanned.items,
      skipped: scanned.skipped,
      signal: controller && controller.signal,
      processItem: async (item, context) => {
        const targetFolder = await ensureOutputFolder(state.folderOutput, item.relativeDirectories);
        const outputEntry = await createNumberedOutputFile(targetFolder, item.sourceEntry.name);
        const processed = await folderHost.processFile({
          sourceEntry: item.sourceEntry,
          outputEntry,
          signal: context.signal,
          processPixels: (source, options) => processFolderSource(source, options.signal, batchOptions)
        });
        return {
          outputRelativePath: [...item.relativeDirectories, processed.outputName].join("/"),
          engine: processed.engine,
          warnings: processed.warnings
        };
      },
      onProgress(event) {
        const completed = Number(event.completed) || 0;
        const total = Math.max(1, Number(event.total) || 1);
        setFolderBatchProgress({
          status: event.phase === "failed" ? "部分文件失败，继续处理" : "处理中",
          percent: Math.round((completed / total) * 100),
          current: event.item && event.item.relativePath || "",
          succeeded: event.succeeded,
          failed: event.failed,
          skipped: event.skipped,
          canceled: event.canceled
        });
      }
    });
    state.folderBatchReport = buildFolderBatchReport(result);
    let reportName = null;
    let reportFailed = false;
    try { reportName = await writeFolderBatchReport(state.folderBatchReport); } catch (error) { reportFailed = true; }
    const status = result.canceled ? "已停止" : result.failed.length ? "完成，有失败项" : "完成";
    setFolderBatchProgress({
      status,
      percent: result.canceled ? Math.round(((result.succeeded.length + result.failed.length) / Math.max(1, result.total)) * 100) : 100,
      current: reportName ? `报告：${reportName}` : "处理完成",
      succeeded: result.succeeded.length,
      failed: result.failed.length,
      skipped: result.skipped.length,
      canceled: result.canceledItems.length
    });
    setMessage(`文件夹批量${status}：成功 ${result.succeeded.length}，失败 ${result.failed.length}，跳过 ${result.skipped.length}，取消 ${result.canceledItems.length}。${reportFailed ? " 报告写入失败。" : ""}`, result.failed.length > 0 || reportFailed);
    return result.failed.length === 0 && !result.canceled;
  } catch (error) {
    setFolderBatchProgress({ status: `失败：${error.message || error}` });
    setMessage(`文件夹批量失败：${error.message || error}`, true);
    return false;
  } finally {
    state.folderBatchController = null;
    setBusy(false);
    updateFolderBatchUI();
    if (state.selectionSync) state.selectionSync.schedule("folder-batch-finished", 0);
  }
}

function stopFolderBatch() {
  if (!state.folderBatchController) return false;
  state.folderBatchController.abort();
  setFolderBatchProgress({ status: "正在安全停止…" });
  updateFolderBatchUI();
  return true;
}

function mountMainPanel(rootNode) {
  initializeWorkspace();
  const mainRoot = document.getElementById("mask-panel-root");
  if (rootNode && mainRoot && mainRoot.parentNode !== rootNode && typeof rootNode.appendChild === "function") {
    rootNode.appendChild(mainRoot);
  }
  if (state.mainListenerRegistry) state.mainListenerRegistry.clear();
  state.mainListenerRegistry = createListenerRegistry();
  state.activeListenerRegistry = state.mainListenerRegistry;
  state.mainMounted = true;
  listen(element("load-layer"), "click", () => { void trackOperation(loadLayer()); });
  listen(element("auto-cutout"), "click", () => { void trackOperation(autoCutout()); });
  listen(element("batch-cutout"), "click", () => { void trackOperation(batchCutout()); });
  listen(element("folder-batch"), "click", () => { void trackOperation(openFolderBatchDialog()); });
  listen(element("open-refine"), "click", () => { void trackOperation(openRefineDialog("refine")); });
  listen(element("quick-preview-expand"), "click", () => { void trackOperation(openRefineDialog("view")); });
  listen(element("quick-apply"), "click", () => { void trackOperation(applyMask()); });
  listen(element("quick-cancel"), "click", () => { void trackOperation(handleResetAction()); });
  listen(element("reset-options"), "click", resetOptions);
  ["edge-shift", "feather", "hard-threshold"].forEach((id) => {
    listen(element(id), "input", handleEdgeOptionInput);
  });
  listen(element("invert-mask"), "change", handleInvertOptionChange);
  listen(element("folder-source-pick"), "click", () => { void trackOperation(pickFolder("source")); });
  listen(element("folder-output-pick"), "click", () => { void trackOperation(pickFolder("output")); });
  listen(element("folder-recursive"), "change", () => { void refreshFolderBatchScan(); });
  listen(element("folder-batch-start"), "click", () => { void trackOperation(startFolderBatch()); });
  listen(element("folder-batch-stop"), "click", stopFolderBatch);
  listen(element("folder-batch-cancel"), "click", closeFolderBatchDialog);
  listen(element("folder-batch-form"), "submit", (event) => {
    if (event && typeof event.preventDefault === "function") event.preventDefault();
  });
  const engineMode = element("engine-mode");
  if (engineMode) listen(engineMode, "change", (event) => selectEngineMode(event.target.value));
  const consent = element("vision-consent");
  if (consent) listen(consent, "change", () => {
    if (consent.checked && engineMode && engineMode.value === "vision-api") selectEngineMode("vision-api");
    if (!consent.checked && state.engineMode === "vision-api") {
      if (engineMode) engineMode.value = "algorithm";
      selectEngineMode("algorithm");
    }
    updateEngineUI();
  });
  const retry = element("retry-compute");
  if (retry) listen(retry, "click", () => { void trackOperation(retryLastOperation()); });
  const useLocal = element("use-local-engine");
  if (useLocal) listen(useLocal, "click", switchToLocalEngine);
  state.activeListenerRegistry = null;
  mountRefineDialog();
  try {
    const invert = element("invert-mask");
    state.maskOptions = { ...state.maskOptions, ...normalizeEdgeSettings(state.maskOptions) };
    syncEdgeOptionsUI();
    if (invert) invert.checked = state.maskOptions.invert;
    const layerStatus = element("layer-status");
    if (layerStatus && state.layer && state.source) {
      layerStatus.textContent = `${state.layer.name} · ${state.source.width} × ${state.source.height}`;
    }
    setResultState(state.alpha
      ? state.previewActive || state.panelPreviewActive ? "蒙版结果待确认" : "蒙版已生成"
      : "还没有生成蒙版", Boolean(state.alpha));
    updateEngineUI();
    setBusy(state.busy, state.busyOperation);
    draw();
    if (state.selectionSync) state.selectionSync.schedule("main-panel-open", 0);
  } catch (error) {
    setMessage(`主面板初始化失败：${error.message || "请重新加载插件。"}`, true);
  }
}

function mountRefineDialog() {
  initializeWorkspace();
  const dialog = element("refine-dialog");
  const root = element("refine-panel-root");
  if (state.refineMounted && state.refineRoot === root && state.refineListenerRegistry) return true;
  cleanupRefineDialog();
  if (!dialog || !root || !dialog.isConnected) {
    setMessage("精修窗口初始化失败，请重新加载插件。", true);
    return false;
  }
  state.refineRoot = root;
  state.refineMounted = Boolean(state.refineRoot);
  if (!state.refineMounted) {
    setMessage("精修窗口创建失败，请重新加载插件。", true);
    return false;
  }
  state.refineListenerRegistry = createListenerRegistry();
  state.activeListenerRegistry = state.refineListenerRegistry;
  state.paintScheduler = createFrameScheduler(() => {
    if (state.refineMounted) draw();
  });
  const previewStack = element("preview-stack");
  const previewCanvas = element("preview-canvas");
  const canvasFrame = element("canvas-frame");
  state.refineInteraction = createRefineInteraction();
  state.wheelInputRouter = createWheelInputRouter({
    isActive: () => Boolean(state.refineMounted && state.source && !state.busy),
    onWheel(event) {
      recordRefineInput(event, { mapping: true });
      handlePreviewWheel(event);
    }
  });

  listen(element("compute-mask"), "click", () => { void trackOperation(computeMask()); });
  listen(element("apply-mask"), "click", () => { void trackOperation(dismissRefineDialog("apply")); });
  listen(element("cancel-refine"), "click", () => { void trackOperation(dismissRefineDialog("cancel")); });
  listen(element("reset-mark"), "click", () => {
    if (!state.workspaceReadOnly) void trackOperation(resetMark());
  });
  listen(element("reset-all"), "click", () => {
    if (!state.workspaceReadOnly) void trackOperation(handleResetAction());
  });
  listen(element("refine-undo"), "click", undoTrimapStroke);
  listen(element("refine-redo"), "click", redoTrimapStroke);
  listen(element("view-mode"), "change", (event) => {
    if (state.busy) return;
    state.viewMode = event.target.value;
    if (state.viewMode === "cutout-custom") {
      delete state.cutoutPreviewUrls["cutout-custom"];
    }
    ensurePreviewForView(state.viewMode);
    hideBrushCursor();
    draw();
  });
  listen(element("preview-background-color"), "input", (event) => {
    if (state.busy) return;
    state.previewBackgroundColor = String(event.target.value || "#808080");
    delete state.cutoutPreviewUrls["cutout-custom"];
    if (state.viewMode === "cutout-custom") {
      ensurePreviewForView(state.viewMode);
      draw();
    }
  });
  listen(element("brush-size"), "input", (event) => {
    if (!state.busy) setBrushSize(event.target.value);
  });
  listen(element("brush-softness"), "input", (event) => {
    if (!state.busy) setBrushSoftness(event.target.value);
  });
  ["refine-edge-shift", "refine-feather", "refine-hard-threshold"].forEach((id) => {
    const control = element(id);
    listen(control, "pointerdown", beginEdgeOptionGesture);
    listen(control, "mousedown", beginEdgeOptionGesture);
    listen(control, "input", handleEdgeOptionInput);
    listen(control, "change", commitEdgeOptionGesture);
    listen(control, "pointerup", commitEdgeOptionGesture);
    listen(control, "mouseup", commitEdgeOptionGesture);
    listen(control, "blur", commitEdgeOptionGesture);
  });
  listen(element("refine-invert-mask"), "change", handleInvertOptionChange);
  listen(element("refine-reset-options"), "click", () => resetOptions(true));
  listen(element("zoom-range"), "input", (event) => setZoom(Number(event.target.value) / 100));
  listen(element("zoom-out"), "click", () => setZoom(state.zoom * 0.8));
  listen(element("zoom-in"), "click", () => setZoom(state.zoom * 1.25));
  listen(element("zoom-fit"), "click", fitZoomToWindow);
  state.refineRoot.querySelectorAll(".tool-button").forEach((button) => {
    listen(button, "click", () => {
      const tool = button.dataset && button.dataset.tool
        ? button.dataset.tool
        : button.getAttribute("data-tool");
      if (["hand", "zoom"].includes(tool)) {
        selectToolButton(tool, button);
        hideBrushCursor();
        return;
      }
      void trackOperation(activatePaintTool(tool, button));
    });
  });
  // Bind the actual painted canvas. In Photoshop UXP, pointer events from an
  // interactive child are not guaranteed to bubble to preview-stack.
  listen(previewCanvas, "mousedown", (event) => beginPreviewInteraction(normalizeRefineEvent(event)));
  listen(previewCanvas, "pointerdown", (event) => beginPreviewInteraction(normalizeRefineEvent(event)));
  listen(canvasFrame, "mousedown", beginPreviewFrameInteraction);
  listen(canvasFrame, "pointerdown", beginPreviewFrameInteraction);
  listen(previewCanvas, "mouseenter", (event) => enterPreview(normalizeRefineEvent(event)));
  listen(previewCanvas, "pointerenter", (event) => enterPreview(normalizeRefineEvent(event)));
  listen(previewCanvas, "mousemove", (event) => continuePreviewSurfaceInteraction(normalizeRefineEvent(event)));
  listen(previewCanvas, "pointermove", (event) => continuePreviewSurfaceInteraction(normalizeRefineEvent(event)));
  listen(previewCanvas, "mouseup", (event) => endPreviewSurfaceInteraction(normalizeRefineEvent(event)));
  listen(previewCanvas, "pointerup", (event) => endPreviewSurfaceInteraction(normalizeRefineEvent(event)));
  listen(previewCanvas, "pointercancel", (event) => endPreviewSurfaceInteraction(normalizeRefineEvent(event)));
  listen(previewCanvas, "mouseleave", (event) => leavePreview(normalizeRefineEvent(event)));
  listen(previewCanvas, "pointerleave", (event) => leavePreview(normalizeRefineEvent(event)));
  // Photoshop 24.4 may expose either the modern or legacy wheel event. Bind
  // the viewport itself so zoom still works over blank canvas margins.
  listen(canvasFrame, "wheel", state.wheelInputRouter.handleSurface);
  listen(canvasFrame, "mousewheel", state.wheelInputRouter.handleSurface);
  listen(canvasFrame, "DOMMouseScroll", state.wheelInputRouter.handleSurface);
  listen(document, "mousemove", (event) => continuePreviewDocumentInteraction(normalizeRefineEvent(event)));
  listen(document, "pointermove", (event) => continuePreviewDocumentInteraction(normalizeRefineEvent(event)));
  listen(document, "mouseup", (event) => endPreviewDocumentInteraction(normalizeRefineEvent(event)));
  listen(document, "pointerup", (event) => endPreviewDocumentInteraction(normalizeRefineEvent(event)));
  listen(document, "pointercancel", (event) => endPreviewDocumentInteraction(normalizeRefineEvent(event)));
  listen(document, "mouseleave", endActivePreviewInteraction);
  listen(window, "blur", endActivePreviewInteraction);
  // Photoshop 24.4 does not always forward bracket keys to the same global
  // target. Listen on both levels and deduplicate the shared event object.
  listen(canvasFrame, "keydown", handlePreviewKeyDown);
  listen(canvasFrame, "keyup", handlePreviewKeyUp);
  listen(document, "keydown", handlePreviewKeyDown);
  listen(document, "keyup", handlePreviewKeyUp);
  listen(window, "keydown", handlePreviewKeyDown);
  listen(window, "keyup", handlePreviewKeyUp);
  listen(document, "wheel", (event) => {
    if (state.previewPointerInside && state.wheelInputRouter) state.wheelInputRouter.handleDocument(event);
  });
  listen(document, "mousewheel", (event) => {
    if (state.previewPointerInside && state.wheelInputRouter) state.wheelInputRouter.handleDocument(event);
  });
  listen(document, "DOMMouseScroll", (event) => {
    if (state.previewPointerInside && state.wheelInputRouter) state.wheelInputRouter.handleDocument(event);
  });
  try {
    if (typeof ResizeObserver === "function") {
      state.resizeObserver = new ResizeObserver(() => {
        if (state.refineMounted && state.zoomMode === "fit") fitZoomToWindow();
      });
      const frame = element("canvas-frame");
      if (frame) state.resizeObserver.observe(frame);
    }
  } catch (error) {
    state.resizeObserver = null;
  }
  state.activeListenerRegistry = null;
  setBrushSize(state.brushSize);
  setBrushSoftness(state.brushSoftness * 100);
  syncEdgeOptionsUI();
  const previewBackgroundColor = element("preview-background-color");
  if (previewBackgroundColor) previewBackgroundColor.value = state.previewBackgroundColor;
  const viewMode = element("view-mode");
  if (viewMode) viewMode.value = state.viewMode;
  const refineStatus = element("refine-layer-status");
  if (refineStatus && state.layer && state.source) {
    refineStatus.textContent = `${state.layer.name} · ${state.source.width} × ${state.source.height}`;
  }
  setBusy(state.busy, state.busyOperation);
  updateTrimapHistoryUI();
  draw();
  return true;
}

try {
  entrypoints.setup({
    plugin: {
      create() {
        initializeWorkspace();
      },
      destroy() {
        return shutdownWithinLifecycleDeadline();
      }
    },
    panels: {
      maskPanel: {
        create(rootNodeOrEvent) {
          mountMainPanel(resolvePanelRoot(rootNodeOrEvent));
        },
        destroy() {
          return destroyMainPanel();
        }
      }
    }
  });
  mountMainPanel(document.body);
} catch (error) {
  state.mounted = true;
  setMessage(`插件初始化失败：${error.message || "请在 UXP Developer Tool 中重新加载。"}`, true);
}
