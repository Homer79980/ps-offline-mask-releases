function selectQuickPreview(state = {}) {
  if (!state.source) {
    return {
      url: null,
      label: "等待图层",
      emptyText: "读取图层后显示缩略图"
    };
  }

  if (state.alpha && state.cutoutPreviewImageUrl) {
    return {
      url: state.cutoutPreviewImageUrl,
      label: "抠图结果",
      emptyText: "抠图缩略图不可用"
    };
  }

  if (state.alpha && state.maskPreviewImageUrl) {
    return {
      url: state.maskPreviewImageUrl,
      label: "蒙版结果",
      emptyText: "蒙版缩略图不可用"
    };
  }

  return {
    url: state.sourcePreviewImageUrl || null,
    label: "当前图层",
    emptyText: "当前图层缩略图不可用"
  };
}

module.exports = { selectQuickPreview };
