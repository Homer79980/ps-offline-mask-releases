function isPrimaryPointer(event) {
  return !event || event.button === undefined || Number(event.button) === 0;
}

function createPreviewPanController({ frame, target, onChange = () => {} } = {}) {
  let spacePressed = false;
  let panning = false;
  let pointerId = null;
  let startX = 0;
  let startY = 0;
  let startScrollLeft = 0;
  let startScrollTop = 0;

  function snapshot() {
    return { spacePressed, panning };
  }

  function notify() {
    onChange(snapshot());
  }

  function setSpacePressed(value) {
    const next = Boolean(value);
    if (spacePressed === next) return false;
    spacePressed = next;
    notify();
    return true;
  }

  function begin(event) {
    if (!spacePressed || panning || !frame) return false;
    if (!isPrimaryPointer(event)) return false;
    panning = true;
    pointerId = event && event.pointerId;
    startX = Number(event && event.clientX) || 0;
    startY = Number(event && event.clientY) || 0;
    startScrollLeft = Number(frame.scrollLeft) || 0;
    startScrollTop = Number(frame.scrollTop) || 0;
    if (target && typeof target.setPointerCapture === "function" && pointerId !== undefined) {
      try { target.setPointerCapture(pointerId); } catch (error) { /* document listeners remain active */ }
    }
    if (event && typeof event.preventDefault === "function") event.preventDefault();
    notify();
    return true;
  }

  function move(event) {
    if (!panning || !frame) return false;
    if (pointerId !== undefined && event && event.pointerId !== undefined && event.pointerId !== pointerId) return false;
    const currentX = Number(event && event.clientX) || 0;
    const currentY = Number(event && event.clientY) || 0;
    frame.scrollLeft = Math.max(0, startScrollLeft - (currentX - startX));
    frame.scrollTop = Math.max(0, startScrollTop - (currentY - startY));
    if (event && typeof event.preventDefault === "function") event.preventDefault();
    return true;
  }

  function end(event) {
    if (!panning) return false;
    if (pointerId !== undefined && event && event.pointerId !== undefined && event.pointerId !== pointerId) return false;
    if (target && typeof target.releasePointerCapture === "function" && pointerId !== undefined) {
      try { target.releasePointerCapture(pointerId); } catch (error) { /* capture is optional */ }
    }
    panning = false;
    pointerId = null;
    notify();
    return true;
  }

  function reset() {
    panning = false;
    pointerId = null;
    spacePressed = false;
    notify();
  }

  return Object.freeze({
    begin,
    end,
    move,
    reset,
    setSpacePressed,
    get panning() { return panning; },
    get spacePressed() { return spacePressed; }
  });
}

module.exports = { createPreviewPanController, isPrimaryPointer };
