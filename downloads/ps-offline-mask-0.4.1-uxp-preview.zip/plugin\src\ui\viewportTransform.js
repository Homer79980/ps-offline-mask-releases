function finiteNumber(value, fallback = 0) {
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : fallback;
}

function clamp(value, minimum, maximum) {
  return Math.min(maximum, Math.max(minimum, value));
}

function zoomAtPoint(options = {}) {
  const zoom = Math.max(Number.EPSILON, finiteNumber(options.zoom, 1));
  const nextZoom = Math.max(Number.EPSILON, finiteNumber(options.nextZoom, zoom));
  const pointerX = finiteNumber(options.pointerX);
  const pointerY = finiteNumber(options.pointerY);
  const scrollLeft = finiteNumber(options.scrollLeft);
  const scrollTop = finiteNumber(options.scrollTop);
  const contentOffsetX = finiteNumber(options.contentOffsetX);
  const contentOffsetY = finiteNumber(options.contentOffsetY);
  const nextContentOffsetX = finiteNumber(options.nextContentOffsetX);
  const nextContentOffsetY = finiteNumber(options.nextContentOffsetY);
  const imageX = (scrollLeft + pointerX - contentOffsetX) / zoom;
  const imageY = (scrollTop + pointerY - contentOffsetY) / zoom;
  const configuredMaxScrollLeft = Number(options.maxScrollLeft);
  const configuredMaxScrollTop = Number(options.maxScrollTop);
  const maxScrollLeft = Number.isFinite(configuredMaxScrollLeft)
    ? Math.max(0, configuredMaxScrollLeft)
    : Math.max(0,
      finiteNumber(options.contentWidth) * nextZoom - finiteNumber(options.viewportWidth));
  const maxScrollTop = Number.isFinite(configuredMaxScrollTop)
    ? Math.max(0, configuredMaxScrollTop)
    : Math.max(0,
      finiteNumber(options.contentHeight) * nextZoom - finiteNumber(options.viewportHeight));

  return {
    zoom: nextZoom,
    scrollLeft: clamp(nextContentOffsetX + imageX * nextZoom - pointerX, 0, maxScrollLeft),
    scrollTop: clamp(nextContentOffsetY + imageY * nextZoom - pointerY, 0, maxScrollTop)
  };
}

module.exports = { zoomAtPoint };
