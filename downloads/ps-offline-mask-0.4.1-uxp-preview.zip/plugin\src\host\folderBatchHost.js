function canonicalPath(value, platform) {
  let path = String(value || "").replace(/\\/g, "/");
  while (path.length > 1 && path.endsWith("/")) path = path.slice(0, -1);
  const windowsPath = platform === "win32" || /^[a-z]:\//i.test(path);
  return windowsPath ? path.toLocaleLowerCase("en-US") : path;
}

function documentValues(documents) {
  if (!documents) return [];
  if (Array.isArray(documents)) return [...documents];
  const values = [];
  const length = Math.max(0, Number(documents.length) || 0);
  for (let index = 0; index < length; index += 1) {
    if (documents[index]) values.push(documents[index]);
  }
  return values;
}

function abortError() {
  const error = new Error("folder batch canceled");
  error.name = "AbortError";
  error.code = "canceled";
  return error;
}

function assertNotAborted(signal) {
  if (signal && signal.aborted) throw abortError();
}

function createRgba(source, processed) {
  const width = Number(source && source.width);
  const height = Number(source && source.height);
  const components = Number(source && source.components);
  const pixels = source && source.pixels;
  const alpha = processed && processed.alpha;
  const foreground = processed && processed.foreground;
  const pixelCount = width * height;
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1
    || ![3, 4].includes(components) || !(pixels instanceof Uint8Array)
    || pixels.length !== pixelCount * components) {
    throw new Error("source pixel data is invalid");
  }
  if (!(alpha instanceof Uint8Array) || alpha.length !== pixelCount) {
    throw new Error("cutout alpha does not match the source dimensions");
  }
  if (foreground !== undefined
    && (!(foreground instanceof Uint8Array)
      || (foreground.length !== pixelCount * 3 && foreground.length !== pixelCount * 4))) {
    throw new Error("cutout foreground does not match the source dimensions");
  }
  const foregroundComponents = foreground ? foreground.length / pixelCount : 0;
  const rgba = new Uint8Array(pixelCount * 4);
  for (let index = 0; index < pixelCount; index += 1) {
    const sourceOffset = index * components;
    const foregroundOffset = index * foregroundComponents;
    const outputOffset = index * 4;
    rgba[outputOffset] = foreground ? foreground[foregroundOffset] : pixels[sourceOffset];
    rgba[outputOffset + 1] = foreground ? foreground[foregroundOffset + 1] : pixels[sourceOffset + 1];
    rgba[outputOffset + 2] = foreground ? foreground[foregroundOffset + 2] : pixels[sourceOffset + 2];
    const sourceAlpha = components === 4 ? pixels[sourceOffset + 3] : 255;
    rgba[outputOffset + 3] = Math.min(sourceAlpha, alpha[index]);
  }
  return rgba;
}

function stagedError(stage, error) {
  const detail = error && error.message ? error.message : String(error || "unknown error");
  const normalized = new Error(`${stage}: ${detail}`);
  normalized.stage = stage;
  normalized.originalError = error;
  return normalized;
}

function isModalScopeRequired(error) {
  const detail = String(error && (error.message || error.description || error.reason) || error || "")
    .toLocaleLowerCase("en-US");
  return detail.includes("ps_executeasmodal")
    || (detail.includes("modal scope") && /(only allowed|must|required|requires)/.test(detail));
}

function createPhotoshopFolderBatchDocumentAdapter({ app, imaging, core, constants } = {}) {
  if (!app || !imaging || !core || typeof core.executeAsModal !== "function") {
    throw new TypeError("Photoshop app, imaging and modal core APIs are required");
  }
  const discardOption = constants && constants.SaveOptions
    ? constants.SaveOptions.DONOTSAVECHANGES
    : undefined;
  if (discardOption === undefined) throw new TypeError("Photoshop DONOTSAVECHANGES is required");

  const runModal = (work, commandName) => core.executeAsModal(work, { commandName });

  function listOpenDocuments() {
    return documentValues(app.documents);
  }

  function getActiveDocument() {
    return listOpenDocuments().length ? app.activeDocument : null;
  }

  async function openSource(entry) {
    try {
      return await runModal(() => app.open(entry), "Open folder batch source");
    } catch (error) {
      throw stagedError("open", error);
    }
  }

  async function readSource(document) {
    const width = Math.round(Number(document && document.width));
    const height = Math.round(Number(document && document.height));
    if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1
      || !Number.isSafeInteger(width * height) || width * height > 16_777_216) {
      throw stagedError("read", new Error("source dimensions exceed the local processing limit"));
    }
    const pixelOptions = {
      documentID: document.id,
      sourceBounds: { left: 0, top: 0, right: width, bottom: height },
      colorSpace: "RGB",
      componentSize: 8,
      applyAlpha: false
    };
    let result;
    try {
      result = await imaging.getPixels(pixelOptions);
    } catch (error) {
      if (!isModalScopeRequired(error)) throw stagedError("read", error);
      try {
        result = await runModal(() => imaging.getPixels(pixelOptions), "Read folder batch pixels");
      } catch (modalError) {
        throw stagedError("read", modalError);
      }
    }
    const imageData = result && result.imageData;
    if (!imageData) throw stagedError("read", new Error("Photoshop returned no composite pixels"));
    try {
      const components = Number(imageData.components);
      const imageWidth = Number(imageData.width);
      const imageHeight = Number(imageData.height);
      if (![3, 4].includes(components) || Number(imageData.componentSize) !== 8
        || !Number.isInteger(imageWidth) || !Number.isInteger(imageHeight)
        || imageWidth < 1 || imageHeight < 1) {
        throw new Error("Photoshop returned an unsupported composite pixel format");
      }
      const data = await imageData.getData({ chunky: true });
      if (!(data instanceof Uint8Array) || data.length !== imageWidth * imageHeight * components) {
        throw new Error("Photoshop returned an invalid composite pixel buffer");
      }
      const bounds = result.sourceBounds || {};
      const left = Math.round(Number(bounds.left) || 0);
      const top = Math.round(Number(bounds.top) || 0);
      if (left < 0 || top < 0 || left + imageWidth > width || top + imageHeight > height) {
        throw new Error("Photoshop returned composite pixels outside the document canvas");
      }
      const pixels = new Uint8Array(width * height * 4);
      for (let y = 0; y < imageHeight; y += 1) {
        for (let x = 0; x < imageWidth; x += 1) {
          const sourceOffset = (y * imageWidth + x) * components;
          const targetOffset = ((top + y) * width + left + x) * 4;
          pixels[targetOffset] = data[sourceOffset];
          pixels[targetOffset + 1] = data[sourceOffset + 1];
          pixels[targetOffset + 2] = data[sourceOffset + 2];
          pixels[targetOffset + 3] = components === 4 ? data[sourceOffset + 3] : 255;
        }
      }
      return {
        width,
        height,
        components: 4,
        pixels,
        resolution: Number(document.resolution) || 72,
        colorProfile: String(imageData.colorProfile || "")
      };
    } catch (error) {
      if (error && error.stage) throw error;
      throw stagedError("read", error);
    } finally {
      if (typeof imageData.dispose === "function") imageData.dispose();
    }
  }

  async function closeWithoutSaving(document) {
    try {
      await runModal(() => document.close(discardOption), "Close folder batch document");
    } catch (error) {
      throw stagedError("close", error);
    }
  }

  async function activateDocument(document) {
    if (!document || !listOpenDocuments().some((candidate) => Number(candidate.id) === Number(document.id))) return;
    try {
      await runModal(() => { app.activeDocument = document; }, "Restore active document");
    } catch (error) {
      throw stagedError("restore", error);
    }
  }

  async function writeTransparentPng({ outputEntry, rgba, width, height, resolution, colorProfile } = {}) {
    if (!(rgba instanceof Uint8Array) || rgba.length !== width * height * 4) {
      throw stagedError("export", new Error("RGBA output does not match its dimensions"));
    }
    let outputDocument = null;
    let outputImageData = null;
    let primaryError = null;
    try {
      await runModal(async () => {
        const documentOptions = {
          width,
          height,
          resolution: Number(resolution) || 72,
          mode: constants.NewDocumentMode && constants.NewDocumentMode.RGB
            ? constants.NewDocumentMode.RGB
            : "RGBColorMode",
          fill: constants.DocumentFill && constants.DocumentFill.TRANSPARENT
            ? constants.DocumentFill.TRANSPARENT
            : "transparent",
          depth: 8
        };
        if (String(colorProfile || "").trim()) documentOptions.profile = String(colorProfile).trim();
        outputDocument = await app.documents.add(documentOptions);
        let layer = documentValues(outputDocument.activeLayers)[0]
          || documentValues(outputDocument.layers)[0];
        if (!layer && typeof outputDocument.createPixelLayer === "function") {
          layer = await outputDocument.createPixelLayer({ name: "Cutout" });
        }
        if (!layer || !Number.isFinite(Number(layer.id))) {
          throw new Error("Photoshop could not create a transparent pixel layer");
        }
        outputImageData = await imaging.createImageDataFromBuffer(rgba, {
          width,
          height,
          components: 4,
          chunky: true,
          colorSpace: "RGB",
          ...(String(colorProfile || "").trim() ? { colorProfile: String(colorProfile).trim() } : {})
        });
        await imaging.putPixels({
          documentID: outputDocument.id,
          layerID: layer.id,
          imageData: outputImageData,
          replace: true,
          targetBounds: { left: 0, top: 0 },
          commandName: "Write folder batch cutout"
        });
        if (!outputDocument.saveAs || typeof outputDocument.saveAs.png !== "function") {
          throw new Error("Photoshop PNG export is unavailable");
        }
        await outputDocument.saveAs.png(outputEntry, {}, true);
      }, "Export folder batch PNG");
    } catch (error) {
      primaryError = stagedError("export", error);
    } finally {
      if (outputImageData && typeof outputImageData.dispose === "function") outputImageData.dispose();
      if (outputDocument) {
        try {
          await closeWithoutSaving(outputDocument);
        } catch (closeError) {
          if (primaryError) primaryError.closeError = closeError;
          else primaryError = closeError;
        }
      }
    }
    if (primaryError) throw primaryError;
  }

  return {
    activateDocument,
    closeWithoutSaving,
    getActiveDocument,
    listOpenDocuments,
    openSource,
    readSource,
    writeTransparentPng
  };
}

function createFolderBatchHost({ storage, documentAdapter, tokenStore, platform } = {}) {
  if (!documentAdapter || typeof documentAdapter !== "object") {
    throw new TypeError("documentAdapter is required");
  }

  const persistentStore = tokenStore
    || (typeof globalThis !== "undefined" && globalThis.localStorage ? globalThis.localStorage : null);

  async function pickFolder() {
    if (!storage || typeof storage.getFolder !== "function") {
      throw new Error("UXP folder picker is unavailable");
    }
    const selected = await storage.getFolder();
    if (selected === null || selected === undefined) return null;
    if (selected.isFolder !== true) throw new Error("folder picker did not return a folder");
    return selected;
  }

  async function rememberFolder(key, entry) {
    if (!persistentStore || typeof persistentStore.setItem !== "function") {
      throw new Error("persistent token storage is unavailable");
    }
    if (!storage || typeof storage.createPersistentToken !== "function") {
      throw new Error("UXP persistent folder authorization is unavailable");
    }
    if (!entry || entry.isFolder !== true) throw new TypeError("entry must be a UXP folder entry");
    const token = await storage.createPersistentToken(entry);
    persistentStore.setItem(String(key), String(token));
    return token;
  }

  async function restoreFolder(key) {
    if (!persistentStore || typeof persistentStore.getItem !== "function"
      || !storage || typeof storage.getEntryForPersistentToken !== "function") return null;
    const storageKey = String(key);
    const token = persistentStore.getItem(storageKey);
    if (!token) return null;
    try {
      const entry = await storage.getEntryForPersistentToken(token);
      if (!entry || entry.isFolder !== true) throw new Error("persistent token is not a folder");
      return entry;
    } catch (error) {
      if (typeof persistentStore.removeItem === "function") persistentStore.removeItem(storageKey);
      return null;
    }
  }

  async function processFile({ sourceEntry, outputEntry, processPixels, signal } = {}) {
    if (!sourceEntry || sourceEntry.isFile !== true) throw new TypeError("sourceEntry must be a UXP file entry");
    if (!outputEntry || outputEntry.isFile !== true) throw new TypeError("outputEntry must be a UXP file entry");
    if (typeof processPixels !== "function") throw new TypeError("processPixels must be a function");
    for (const method of ["listOpenDocuments", "getActiveDocument", "openSource", "readSource",
      "writeTransparentPng", "closeWithoutSaving", "activateDocument"]) {
      if (typeof documentAdapter[method] !== "function") {
        throw new TypeError(`documentAdapter.${method} must be a function`);
      }
    }

    let previousActive = null;
    let sourceDocument = null;
    let closeSource = false;
    let primaryError = null;
    let result = null;
    try {
      assertNotAborted(signal);
      const openBefore = documentValues(await documentAdapter.listOpenDocuments());
      previousActive = await documentAdapter.getActiveDocument();
      const sourcePath = canonicalPath(sourceEntry.nativePath || sourceEntry.url, platform);
      if (sourcePath
        && openBefore.some((document) => canonicalPath(document && document.path, platform) === sourcePath)) {
        const error = new Error("source file is already open in Photoshop");
        error.code = "source-already-open";
        throw error;
      }
      const openDocumentIDs = new Set(openBefore.map((document) => Number(document && document.id)));
      sourceDocument = await documentAdapter.openSource(sourceEntry);
      if (!sourceDocument || !Number.isFinite(Number(sourceDocument.id))) {
        throw new Error("Photoshop did not return an opened source document");
      }
      if (openDocumentIDs.has(Number(sourceDocument.id))) {
        const error = new Error("Photoshop reused a document that was already open");
        error.code = "source-already-open";
        throw error;
      }
      closeSource = true;
      assertNotAborted(signal);
      const source = await documentAdapter.readSource(sourceDocument);
      assertNotAborted(signal);
      const processed = await processPixels(source, { signal });
      assertNotAborted(signal);
      const rgba = createRgba(source, processed);
      await documentAdapter.writeTransparentPng({
        outputEntry,
        rgba,
        width: source.width,
        height: source.height,
        resolution: source.resolution,
        colorProfile: source.colorProfile
      });
      result = {
        outputName: String(outputEntry.name || ""),
        width: source.width,
        height: source.height,
        engine: String(processed && processed.engine || "local-algorithm"),
        warnings: Array.isArray(processed && processed.warnings)
          ? processed.warnings.map((value) => String(value))
          : []
      };
    } catch (error) {
      primaryError = error;
    } finally {
      if (closeSource && sourceDocument) {
        try {
          await documentAdapter.closeWithoutSaving(sourceDocument);
        } catch (closeError) {
          if (primaryError) primaryError.closeError = closeError;
          else primaryError = closeError;
        }
      }
      if (previousActive) {
        try {
          await documentAdapter.activateDocument(previousActive);
        } catch (activateError) {
          if (primaryError) primaryError.activateError = activateError;
          else primaryError = activateError;
        }
      }
    }
    if (primaryError && outputEntry && typeof outputEntry.delete === "function") {
      try {
        await outputEntry.delete();
      } catch (cleanupError) {
        primaryError.outputCleanupError = cleanupError;
      }
    }
    if (primaryError) throw primaryError;
    return result;
  }

  return { pickFolder, processFile, rememberFolder, restoreFolder };
}

module.exports = {
  createFolderBatchHost,
  createPhotoshopFolderBatchDocumentAdapter,
  createRgba
};
