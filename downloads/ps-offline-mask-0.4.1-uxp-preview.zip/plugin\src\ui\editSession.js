function createEditSession({ clone } = {}) {
  if (typeof clone !== "function") {
    throw new TypeError("Edit session requires a clone function");
  }

  // Keep the snapshot taken when the workspace opens separate from the
  // latest automatic result.  A reset of manual marks should use the latter,
  // while cancel still needs the former to discard the whole session.
  let sessionOpenBaseline = null;
  let automaticDraftBaseline = null;
  let working = null;
  let active = false;
  let dirty = false;
  let status = "idle";

  function baselineKind(kind = "session-open") {
    const value = String(kind || "session-open").toLowerCase();
    if (["session-open", "sessionopen", "open", "initial", "baseline"].includes(value)) {
      return "session-open";
    }
    if (["automatic-draft", "automaticdraft", "draft", "automatic", "auto"].includes(value)) {
      return "automatic-draft";
    }
    throw new RangeError(`Unknown edit-session baseline: ${kind}`);
  }

  function begin(value, options = {}) {
    sessionOpenBaseline = clone(value);
    const hasAutomaticDraft = options && typeof options === "object"
      && Object.prototype.hasOwnProperty.call(options, "automaticDraft");
    // The two baselines are immutable internally, so they can initially share
    // one snapshot. setAutomaticDraft replaces only the draft reference.
    automaticDraftBaseline = hasAutomaticDraft
      ? clone(options.automaticDraft)
      : sessionOpenBaseline;
    working = clone(value);
    active = true;
    dirty = false;
    status = "editing";
    return working;
  }

  function markChanged() {
    if (!active) return false;
    dirty = true;
    return true;
  }

  function getBaseline(kind = "session-open") {
    const selected = baselineKind(kind) === "session-open"
      ? sessionOpenBaseline
      : automaticDraftBaseline;
    return selected === null ? null : clone(selected);
  }

  function setAutomaticDraft(value) {
    if (!active) return false;
    automaticDraftBaseline = clone(value);
    return true;
  }

  function restore(kind = "automatic-draft") {
    if (!active) return null;
    const selected = baselineKind(kind) === "session-open"
      ? sessionOpenBaseline
      : automaticDraftBaseline;
    if (selected === null) return null;
    working = clone(selected);
    dirty = false;
    status = "editing";
    return clone(working);
  }

  function cancel() {
    if (!active) return null;
    const restored = clone(sessionOpenBaseline);
    working = null;
    sessionOpenBaseline = null;
    automaticDraftBaseline = null;
    active = false;
    dirty = false;
    status = "cancelled";
    return restored;
  }

  function apply() {
    if (!active) return null;
    const committed = clone(working);
    working = null;
    sessionOpenBaseline = null;
    automaticDraftBaseline = null;
    active = false;
    dirty = false;
    status = "applied";
    return committed;
  }

  // Legacy reset() has always meant “return to the automatic draft”.
  function reset() { return restore("automatic-draft"); }

  function resetAll() { return restore("session-open"); }

  return Object.freeze({
    apply,
    begin,
    cancel,
    markChanged,
    getBaseline,
    setAutomaticDraft,
    restore,
    resetAll,
    reset,
    restoreAutomaticDraft: () => restore("automatic-draft"),
    restoreSessionOpen: () => restore("session-open"),
    getAutomaticDraft: () => getBaseline("automatic-draft"),
    getSessionOpenBaseline: () => getBaseline("session-open"),
    get active() { return active; },
    get dirty() { return dirty; },
    get status() { return status; },
    get automaticDraftBaseline() { return getBaseline("automatic-draft"); },
    get sessionOpenBaseline() { return getBaseline("session-open"); },
    get working() { return working; }
  });
}

module.exports = { createEditSession };
