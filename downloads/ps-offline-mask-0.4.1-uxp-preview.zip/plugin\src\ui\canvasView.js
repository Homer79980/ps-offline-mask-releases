const { calculateFitZoom, clampZoom } = require("./zoom");
const { normalizeWheelDirection } = require("./previewInput");
const { zoomAtPoint } = require("./viewportTransform");

const LIVE_STROKE_COLORS = Object.freeze({
  keep: "rgba(70, 225, 120, 0.43)",
  cut: "rgba(240, 90, 90, 0.45)",
  unknown: "rgba(80, 155, 255, 0.27)"
});
const MAX_LIVE_STROKE_DABS = 512;

function createCanvasView({ element, state }) {
  function updateZoomUI() {
    const range = element("zoom-range");
    const output = element("zoom-value");
    const percent = Math.round(state.zoom * 100);
    if (range) range.value = String(percent);
    if (output) output.textContent = `${percent}%`;
    ["zoom-out", "zoom-in", "zoom-fit"].forEach((id) => {
      const control = element(id);
      if (control) control.disabled = state.busy || !state.source;
    });
  }

  function applyZoom() {
    const surface = element("preview-surface");
    const stack = element("preview-stack");
    if (!surface || !stack || !state.source) return;
    const width = Math.max(1, Math.round(state.source.width * state.zoom));
    const height = Math.max(1, Math.round(state.source.height * state.zoom));
    stack.style.width = `${width}px`;
    stack.style.height = `${height}px`;
    const compareImage = element("preview-compare-image");
    if (compareImage) {
      compareImage.style.width = `${width}px`;
      compareImage.style.height = `${height}px`;
    }
  }

  function setZoom(value, mode = "manual") {
    if (state.busy || !state.source) return state.zoom;
    state.zoom = clampZoom(value, state.zoom);
    state.zoomMode = mode;
    applyZoom();
    updateZoomUI();
    return state.zoom;
  }

  function fitZoom() {
    if (!state.source || state.busy) return;
    const frame = element("canvas-frame");
    if (!frame || Number(frame.clientWidth) <= 0 || Number(frame.clientHeight) <= 0) return;
    setZoom(calculateFitZoom(
      state.source.width,
      state.source.height,
      frame.clientWidth,
      frame.clientHeight
    ), "fit");
  }

  function handleWheel(event) {
    if (!state.source || state.busy) return;
    if (event && typeof event.preventDefault === "function") event.preventDefault();
    const direction = normalizeWheelDirection(event);
    if (direction === 0) return;
    const frame = element("canvas-frame");
    const stack = element("preview-stack");
    const nextZoom = clampZoom(state.zoom * (direction < 0 ? 1.15 : 0.85), state.zoom);
    if (!frame || !stack) {
      setZoom(nextZoom);
      return;
    }
    const rect = typeof frame.getBoundingClientRect === "function"
      ? frame.getBoundingClientRect()
      : { left: 0, top: 0, width: frame.clientWidth, height: frame.clientHeight };
    const pointerX = Number.isFinite(Number(event && event.clientX))
      ? Number(event.clientX) - Number(rect.left || 0)
      : Number(frame.clientWidth || rect.width || 0) / 2;
    const pointerY = Number.isFinite(Number(event && event.clientY))
      ? Number(event.clientY) - Number(rect.top || 0)
      : Number(frame.clientHeight || rect.height || 0) / 2;
    const currentZoom = state.zoom;
    const currentScrollLeft = Number(frame.scrollLeft) || 0;
    const currentScrollTop = Number(frame.scrollTop) || 0;
    const currentStackRect = typeof stack.getBoundingClientRect === "function"
      ? stack.getBoundingClientRect()
      : { left: rect.left, top: rect.top };
    const contentOffsetX = Number(currentStackRect.left || 0) - Number(rect.left || 0) + currentScrollLeft;
    const contentOffsetY = Number(currentStackRect.top || 0) - Number(rect.top || 0) + currentScrollTop;
    setZoom(nextZoom);
    const nextStackRect = typeof stack.getBoundingClientRect === "function"
      ? stack.getBoundingClientRect()
      : currentStackRect;
    const layoutScrollLeft = Number(frame.scrollLeft) || 0;
    const layoutScrollTop = Number(frame.scrollTop) || 0;
    const nextContentOffsetX = Number(nextStackRect.left || 0) - Number(rect.left || 0) + layoutScrollLeft;
    const nextContentOffsetY = Number(nextStackRect.top || 0) - Number(rect.top || 0) + layoutScrollTop;
    const scrollWidth = Number(frame.scrollWidth);
    const scrollHeight = Number(frame.scrollHeight);
    const transformed = zoomAtPoint({
      zoom: currentZoom,
      nextZoom,
      scrollLeft: currentScrollLeft,
      scrollTop: currentScrollTop,
      pointerX,
      pointerY,
      contentOffsetX,
      contentOffsetY,
      nextContentOffsetX,
      nextContentOffsetY,
      contentWidth: state.source.width,
      contentHeight: state.source.height,
      viewportWidth: frame.clientWidth || rect.width,
      viewportHeight: frame.clientHeight || rect.height,
      ...(Number.isFinite(scrollWidth) && scrollWidth > 0
        ? { maxScrollLeft: Math.max(0, scrollWidth - Number(frame.clientWidth || rect.width || 0)) }
        : {}),
      ...(Number.isFinite(scrollHeight) && scrollHeight > 0
        ? { maxScrollTop: Math.max(0, scrollHeight - Number(frame.clientHeight || rect.height || 0)) }
        : {})
    });
    frame.scrollLeft = transformed.scrollLeft;
    frame.scrollTop = transformed.scrollTop;
  }

  function getPoint(event, surface) {
    const rect = surface.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left) * (state.source.width / Math.max(1, rect.width)),
      y: (event.clientY - rect.top) * (state.source.height / Math.max(1, rect.height))
    };
  }

  function clearLiveStroke() {
    const layer = element("live-stroke-layer");
    if (!layer) return;
    while (layer.firstChild) layer.removeChild(layer.firstChild);
  }

  function appendDab(layer, point, diameter, color, opacity = 1) {
    const ownerDocument = layer.ownerDocument || (typeof document !== "undefined" ? document : null);
    if (!ownerDocument || typeof ownerDocument.createElement !== "function") return;
    const dab = ownerDocument.createElement("span");
    dab.className = "live-stroke-dab";
    dab.style.left = `${point.x * state.zoom - diameter / 2}px`;
    dab.style.top = `${point.y * state.zoom - diameter / 2}px`;
    dab.style.width = `${diameter}px`;
    dab.style.height = `${diameter}px`;
    dab.style.backgroundColor = color;
    dab.style.opacity = String(opacity);
    layer.appendChild(dab);
    while (layer.childNodes && layer.childNodes.length > MAX_LIVE_STROKE_DABS && layer.firstChild) {
      layer.removeChild(layer.firstChild);
    }
  }

  function drawLiveStroke(from, to) {
    const layer = element("live-stroke-layer");
    if (!layer || !from || !to || !state.source) return;
    const color = LIVE_STROKE_COLORS[state.tool] || LIVE_STROKE_COLORS.unknown;
    const diameter = Math.max(2, state.brushSize * state.zoom);
    const distance = Math.hypot(to.x - from.x, to.y - from.y);
    const steps = Math.min(
      MAX_LIVE_STROKE_DABS,
      Math.max(1, Math.ceil(distance / Math.max(1, state.brushSize / 4)))
    );
    for (let step = 1; step <= steps; step += 1) {
      const t = step / steps;
      const point = {
        x: from.x + (to.x - from.x) * t,
        y: from.y + (to.y - from.y) * t
      };
      appendDab(layer, point, diameter, color, 1);
    }
  }

  function draw() {
    const surface = element("preview-surface");
    const image = element("preview-image");
    const overlay = element("trimap-overlay-image");
    const compareLayer = element("preview-compare-layer");
    const compareImage = element("preview-compare-image");
    const compareDivider = element("preview-compare-divider");
    const stack = element("preview-stack");
    const placeholder = element("canvas-placeholder");
    if (!surface || !placeholder) return;
    if (!state.source) {
      placeholder.textContent = "请选择一个像素图层";
      placeholder.style.display = "block";
      if (image) image.style.display = "none";
      if (overlay) overlay.style.display = "none";
      if (compareLayer) compareLayer.style.display = "none";
      if (compareDivider) compareDivider.style.display = "none";
      if (stack) {
        stack.style.width = "1px";
        stack.style.height = "1px";
      }
      clearLiveStroke();
      updateZoomUI();
      return;
    }

    const viewMode = String(state.viewMode || "");
    const cutoutPreviewUrls = state.cutoutPreviewUrls || {};
    const compareResultUrl = state.cutoutPreviewImageUrl
      || cutoutPreviewUrls["cutout-transparent"]
      || cutoutPreviewUrls.transparent;
    const selectedCutoutUrl = viewMode.startsWith("cutout-")
      ? cutoutPreviewUrls[viewMode] || cutoutPreviewUrls[viewMode.slice("cutout-".length)]
      : null;
    const previewImageUrl = viewMode === "mask"
      ? state.maskPreviewImageUrl
      : viewMode === "result" || viewMode === "compare"
        ? compareResultUrl
        : selectedCutoutUrl || state.sourcePreviewImageUrl || state.previewImageUrl;
    const hasRaster = typeof previewImageUrl === "string" && previewImageUrl.length > 0;
    placeholder.textContent = hasRaster
      ? ""
      : "当前 UXP 主机未生成预览图，结果仍显示在 Photoshop 画布";
    placeholder.style.display = hasRaster ? "none" : "block";
    if (image) {
      if (image.src !== previewImageUrl) image.src = previewImageUrl || "";
      image.style.display = hasRaster ? "block" : "none";
    }
    if (overlay) {
      const showOverlay = viewMode === "mark" && Boolean(state.trimapOverlayImageUrl);
      if (showOverlay && overlay.src !== state.trimapOverlayImageUrl) overlay.src = state.trimapOverlayImageUrl;
      overlay.style.display = showOverlay ? "block" : "none";
    }
    const compareSourceUrl = state.sourcePreviewImageUrl || state.previewImageUrl;
    const showCompare = viewMode === "compare" && hasRaster && Boolean(compareSourceUrl);
    if (compareLayer) compareLayer.style.display = showCompare ? "block" : "none";
    if (compareImage) {
      if (compareImage.src !== compareSourceUrl) compareImage.src = compareSourceUrl || "";
      compareImage.style.display = showCompare ? "block" : "none";
    }
    if (compareDivider) compareDivider.style.display = showCompare ? "block" : "none";
    applyZoom();
  }

  return Object.freeze({
    clearLiveStroke,
    draw,
    drawLiveStroke,
    fitZoom,
    getPoint,
    handleWheel,
    setZoom,
    updateZoomUI
  });
}

module.exports = { createCanvasView, MAX_LIVE_STROKE_DABS };
