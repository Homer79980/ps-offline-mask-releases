const { throwIfAborted } = require("./stepRunner");

class LocalModelUnavailableError extends Error {
  constructor(message = "Local model runtime is not available", details = {}) {
    super(message);
    this.name = "LocalModelUnavailableError";
    this.code = "local-model-unavailable";
    this.category = "configuration";
    this.retryable = false;
    if (details.cause !== undefined) this.cause = details.cause;
  }
}

function runtimeAvailable(runtime) {
  if (!runtime || typeof runtime.compute !== "function") return false;
  if (typeof runtime.available !== "function") return true;
  try {
    return runtime.available() === true;
  } catch (error) {
    return false;
  }
}

function createLocalModelAdapter({ runtime, model } = {}) {
  return {
    kind: "local-model",
    available() {
      return runtimeAvailable(runtime);
    },
    describe() {
      if (!runtimeAvailable(runtime)) return "Local model unavailable";
      if (typeof runtime.describe === "function") {
        const description = runtime.describe();
        if (typeof description === "string" && description.trim()) return description;
      }
      return "Local model";
    },
    async compute(request = {}) {
      throwIfAborted(request.signal);
      if (!runtimeAvailable(runtime)) throw new LocalModelUnavailableError();
      const result = await runtime.compute({
        ...request,
        model: model && typeof model === "object" ? { ...model } : model,
        options: {
          ...(request.options && typeof request.options === "object" ? request.options : {}),
          postProcessLocally: true
        }
      });
      throwIfAborted(request.signal);
      return result;
    }
  };
}

module.exports = {
  LocalModelUnavailableError,
  createLocalModelAdapter
};
