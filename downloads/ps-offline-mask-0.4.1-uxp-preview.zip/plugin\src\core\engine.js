const {
  applyAlphaPostProcessingAsync,
  applySourceAlphaLimitAsync,
  computeFallbackRawAlphaAsync
} = require("./alpha");
const { decontaminateForegroundAsync } = require("./foreground");
const { createLocalModelAdapter, LocalModelUnavailableError } = require("./localModelAdapter");
const { computeSolidBackgroundMatteAsync } = require("./solidBackgroundMatte");
const { createVisionApiClient, ERROR_CATEGORIES, VisionApiError } = require("./visionApi");

function loadNativeAddon(requireFn = require) {
  try {
    return requireFn("ps-mask-engine.uxpaddon");
  } catch (error) {
    return null;
  }
}

function validateResponse(response, width, height) {
  if (!response || !(response.alpha instanceof Uint8Array) || response.alpha.length !== width * height) {
    throw new Error("Native mask engine returned an invalid alpha buffer");
  }
  if (response.foreground !== undefined
    && (!(response.foreground instanceof Uint8Array) || response.foreground.length !== width * height * 3)) {
    throw new Error("Mask engine returned an invalid foreground buffer");
  }
  const fringeMode = response.diagnostics && response.diagnostics.fringeMode;
  if (fringeMode !== undefined && fringeMode !== "mask-only" && fringeMode !== "foreground-corrected") {
    throw new Error("Mask engine returned an invalid fringeMode");
  }
  if (fringeMode === "foreground-corrected" && !response.foreground) {
    throw new Error("Mask engine claimed foreground correction without foreground data");
  }
  if (response.foreground && fringeMode !== "foreground-corrected") {
    throw new Error("Mask engine foreground data requires fringeMode=foreground-corrected");
  }
  return response;
}

function inferenceRequest(request) {
  return {
    ...request,
    options: {
      ...(request && request.options && typeof request.options === "object" ? request.options : {}),
      postProcessLocally: true
    }
  };
}

function appendWarning(diagnostics, warning) {
  const warnings = Array.isArray(diagnostics.warnings)
    ? diagnostics.warnings.filter((value) => typeof value === "string")
    : [];
  if (!warnings.includes(warning)) warnings.push(warning);
  return { ...diagnostics, warnings };
}

function normalizedDiagnostics(response) {
  const diagnostics = response.diagnostics && typeof response.diagnostics === "object"
    ? { ...response.diagnostics }
    : {};
  if (!response.foreground) diagnostics.fringeMode = "mask-only";
  else if (!diagnostics.fringeMode) diagnostics.fringeMode = "mask-only";
  return diagnostics;
}

function mergeDiagnostics(primary, secondary) {
  const left = primary && typeof primary === "object" ? primary : {};
  const right = secondary && typeof secondary === "object" ? secondary : {};
  const warnings = [
    ...(Array.isArray(left.warnings) ? left.warnings : []),
    ...(Array.isArray(right.warnings) ? right.warnings : [])
  ].filter((value, index, all) => typeof value === "string" && all.indexOf(value) === index);
  return { ...left, ...right, warnings };
}

function alphaBuffersEqual(left, right) {
  if (left === right) return true;
  if (!(left instanceof Uint8Array) || !(right instanceof Uint8Array) || left.length !== right.length) return false;
  for (let index = 0; index < left.length; index += 1) {
    if (left[index] !== right[index]) return false;
  }
  return true;
}

async function finalizeResponse(response, request, alphaIsFinal = false) {
  const validated = validateResponse(response, request.width, request.height);
  let alpha = validated.alpha;
  let correctionAlpha = validated.alpha;
  let baseAlpha;
  if (!alphaIsFinal) {
    correctionAlpha = await applySourceAlphaLimitAsync(
      new Uint8Array(validated.alpha),
      request.pixels,
      request.width,
      request.height,
      request.components,
      request.signal,
      request.onProgress
    );
    baseAlpha = new Uint8Array(correctionAlpha);
    alpha = await applyAlphaPostProcessingAsync(
      alpha,
      request.width,
      request.height,
      request.options,
      request.signal,
      request.onProgress
    );
    alpha = await applySourceAlphaLimitAsync(
      alpha,
      request.pixels,
      request.width,
      request.height,
      request.components,
      request.signal,
      request.onProgress
    );
  } else {
    baseAlpha = new Uint8Array(correctionAlpha);
  }

  let foreground = validated.foreground;
  let foregroundSource = foreground ? "provider" : null;
  let diagnostics = normalizedDiagnostics(validated);
  if (foreground && !alphaBuffersEqual(validated.alpha, alpha)) {
    foreground = undefined;
    foregroundSource = null;
    diagnostics = appendWarning(
      { ...diagnostics, fringeMode: "mask-only" },
      "foreground-alpha-postprocessed"
    );
  }
  const decontaminateOption = request.options && request.options.decontaminate;
  const hasConfiguredBackground = Boolean(
    request.background && Array.isArray(request.background.color)
  );
  const correctionBlocked = decontaminateOption === true
    && !hasConfiguredBackground
    && request.strategy !== "solid-background";
  if (correctionBlocked) {
    foreground = undefined;
    foregroundSource = null;
    diagnostics = appendWarning(
      { ...diagnostics, fringeMode: "mask-only" },
      "foreground-background-unavailable"
    );
  }
  const shouldDecontaminate = (decontaminateOption === true && hasConfiguredBackground)
    || (decontaminateOption !== false && request.strategy === "solid-background");
  if (shouldDecontaminate) {
    try {
      const corrected = await decontaminateForegroundAsync({
        pixels: request.pixels,
        width: request.width,
        height: request.height,
        components: request.components,
        alpha: correctionAlpha,
        background: request.background,
        signal: request.signal,
        onProgress: request.onProgress
      });
      foreground = corrected.foreground;
      foregroundSource = "local-decontamination";
      diagnostics = {
        ...diagnostics,
        ...corrected.diagnostics,
        fringeMode: "foreground-corrected"
      };
    } catch (error) {
      if (error && error.code === "canceled") throw error;
      if (!foreground || diagnostics.fringeMode !== "foreground-corrected") {
        foreground = undefined;
        foregroundSource = null;
        diagnostics = appendWarning(
          { ...diagnostics, fringeMode: "mask-only" },
          error && error.code === "foreground-background-unavailable"
            ? error.code
            : "foreground-correction-failed"
        );
      }
    }
  }

  const result = { ...validated, alpha, baseAlpha, diagnostics };
  if (foreground) {
    result.foreground = foreground;
    result.foregroundSource = foregroundSource;
  } else {
    delete result.foreground;
    delete result.foregroundSource;
  }
  return result;
}

function createEngine(options = {}) {
  const nativeAddon = options.nativeAddon || loadNativeAddon(options.requireFn);
  const algorithmEngine = nativeAddon && typeof nativeAddon.compute === "function"
    ? {
      kind: "native",
      describe() {
        return "原生算法引擎";
      },
      async compute(request) {
        const response = await nativeAddon.compute(inferenceRequest(request));
        return finalizeResponse(response, request);
      }
    }
    : {
      kind: "fallback",
      describe() {
        return "降级预览引擎";
      },
      async compute(request) {
        return finalizeResponse({
          alpha: await computeFallbackRawAlphaAsync(request),
          diagnostics: {
            engine: "fallback",
            warning: "Native algorithm addon is not installed; this result is only for integration testing."
          }
        }, request);
      }
    };
  let visionClient = options.visionClient || null;
  // Accept either a ready client or runtime-only API configuration. No endpoint
  // is inferred here, which keeps the algorithm mode strictly offline by default.
  if (!visionClient && options.visionApi && typeof options.visionApi === "object") {
    visionClient = createVisionApiClient(options.visionApi);
  }
  const localModelAdapter = options.localModelAdapter
    || (options.localModel && typeof options.localModel === "object"
      ? createLocalModelAdapter(options.localModel)
      : null);
  const localModelAvailable = Boolean(localModelAdapter
    && typeof localModelAdapter.compute === "function"
    && (typeof localModelAdapter.available !== "function" || localModelAdapter.available()));
  const requestedMode = options.mode || "algorithm";
  if (requestedMode !== "algorithm" && requestedMode !== "vision-api" && requestedMode !== "local-model") {
    throw new Error(`Unknown mask engine mode: ${requestedMode}`);
  }
  if (requestedMode === "vision-api" && !visionClient) {
    throw new VisionApiError("Vision API is not configured", {
      code: ERROR_CATEGORIES.CONFIGURATION,
      category: ERROR_CATEGORIES.CONFIGURATION,
      retryable: false
    });
  }
  if (requestedMode === "local-model" && !localModelAvailable) {
    throw new LocalModelUnavailableError();
  }
  let mode = requestedMode;

  return {
    get kind() {
      if (mode === "vision-api") return "vision-api";
      if (mode === "local-model") return "local-model";
      return algorithmEngine.kind;
    },
    describe() {
      if (mode === "vision-api") return visionClient.describe();
      if (mode === "local-model") return localModelAdapter.describe();
      return algorithmEngine.describe();
    },
    availableModes() {
      const modes = {
        algorithm: true,
        visionApi: Boolean(visionClient)
      };
      if (localModelAdapter) modes.localModel = localModelAvailable;
      return modes;
    },
    setMode(nextMode) {
      if (nextMode !== "algorithm" && nextMode !== "vision-api" && nextMode !== "local-model") {
        throw new Error(`Unknown mask engine mode: ${nextMode}`);
      }
      if (nextMode === "vision-api" && !visionClient) {
        throw new VisionApiError("Vision API is not configured", {
          code: ERROR_CATEGORIES.CONFIGURATION,
          category: ERROR_CATEGORIES.CONFIGURATION,
          retryable: false
        });
      }
      if (nextMode === "local-model" && !localModelAvailable) {
        throw new LocalModelUnavailableError();
      }
      mode = nextMode;
    },
    async compute(request) {
      if (mode === "vision-api") {
        const response = await visionClient.compute(inferenceRequest(request), { signal: request && request.signal });
        return finalizeResponse(response, request);
      }
      if (mode === "local-model") {
        const response = await localModelAdapter.compute(inferenceRequest(request));
        return finalizeResponse(response, request);
      }
      if (request && request.strategy === "solid-background") {
        const response = await computeSolidBackgroundMatteAsync({
          ...request,
          background: request.background && request.background.color,
          backgroundSpread: request.background && request.background.spread
        });
        return finalizeResponse({
          ...response,
          diagnostics: mergeDiagnostics(request.autoTrimapDiagnostics, response.diagnostics)
        }, request);
      }
      return algorithmEngine.compute(request);
    }
  };
}

module.exports = { createEngine, inferenceRequest, loadNativeAddon, validateResponse };
