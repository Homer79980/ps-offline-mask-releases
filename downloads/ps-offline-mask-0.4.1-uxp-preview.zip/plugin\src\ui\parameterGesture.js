function createParameterGesture(options = {}) {
  const clone = options.clone === undefined ? (value) => value : options.clone;
  const equals = options.equals === undefined ? Object.is : options.equals;
  if (typeof clone !== "function") throw new TypeError("Parameter gesture clone must be a function");
  if (typeof equals !== "function") throw new TypeError("Parameter gesture equals must be a function");

  let current = null;

  function clear() {
    current = null;
  }

  function begin(key, before) {
    if (typeof key !== "string" || key.trim().length === 0) {
      throw new TypeError("Parameter key is required");
    }
    if (current) throw new Error("A parameter gesture is already active");
    const baseline = clone(before);
    current = {
      key,
      before: baseline,
      after: clone(baseline)
    };
    return clone(current.after);
  }

  function update(after) {
    if (!current) throw new Error("An active parameter gesture is required before update");
    current.after = clone(after);
    return clone(current.after);
  }

  function commit() {
    if (!current) return null;
    const command = {
      key: current.key,
      before: clone(current.before),
      after: clone(current.after)
    };
    clear();
    if (equals(command.before, command.after)) return null;
    return command;
  }

  function cancel() {
    if (!current) return null;
    const baseline = clone(current.before);
    clear();
    return baseline;
  }

  return Object.freeze({
    begin,
    cancel,
    commit,
    update,
    get active() { return current !== null; },
    get key() { return current ? current.key : null; }
  });
}

module.exports = { createParameterGesture };
