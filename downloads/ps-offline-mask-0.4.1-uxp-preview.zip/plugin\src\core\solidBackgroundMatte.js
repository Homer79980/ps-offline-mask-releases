const { runStepsAsync, runStepsSync } = require("./stepRunner");
const { LABELS } = require("./trimap");

const YIELD_INTERVAL = 4096;

function clamp(value, minimum, maximum) {
  return Math.min(maximum, Math.max(minimum, value));
}

function colorDistance(pixels, components, index, background) {
  const offset = index * components;
  const red = pixels[offset] - background[0];
  const green = pixels[offset + 1] - background[1];
  const blue = pixels[offset + 2] - background[2];
  return Math.sqrt(red * red + green * green + blue * blue);
}

function backgroundSeparation(pixels, components, index, background, allowDeepShade = false) {
  const distance = colorDistance(pixels, components, index, background);
  const chroma = Math.max(...background) - Math.min(...background);
  if (chroma < 32) return distance;

  const offset = index * components;
  const backgroundLengthSquared = background[0] * background[0]
    + background[1] * background[1]
    + background[2] * background[2];
  if (backgroundLengthSquared < 1) return distance;
  const dot = (
    pixels[offset] * background[0]
      + pixels[offset + 1] * background[1]
      + pixels[offset + 2] * background[2]
  );
  const scale = dot / backgroundLengthSquared;
  if (scale > 1.05) return distance;
  if (scale < 0.2) {
    const pixelChroma = Math.max(
      pixels[offset],
      pixels[offset + 1],
      pixels[offset + 2]
    ) - Math.min(
      pixels[offset],
      pixels[offset + 1],
      pixels[offset + 2]
    );
    if (!allowDeepShade || scale < 0.05 || pixelChroma < Math.max(8, chroma * 0.08)) {
      return distance;
    }
  }

  const red = pixels[offset] - background[0] * scale;
  const green = pixels[offset + 1] - background[1] * scale;
  const blue = pixels[offset + 2] - background[2] * scale;
  const directionalDistance = Math.sqrt(red * red + green * green + blue * blue);
  const pixelLengthSquared = pixels[offset] * pixels[offset]
    + pixels[offset + 1] * pixels[offset + 1]
    + pixels[offset + 2] * pixels[offset + 2];
  const directionSimilarity = pixelLengthSquared > 0
    ? dot / Math.sqrt(pixelLengthSquared * backgroundLengthSquared)
    : 0;
  const toleranceRate = directionSimilarity >= 0.97 ? 0.16 : 0.08;
  const shadeTolerance = allowDeepShade ? Math.max(6, chroma * toleranceRate) : 0;
  return Math.min(distance, Math.max(0, directionalDistance - shadeTolerance));
}

function validateRequest(request) {
  const {
    pixels,
    width,
    height,
    components = 3,
    trimap,
    background
  } = request || {};
  const size = width * height;
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1) {
    throw new RangeError("Solid-background matte dimensions are invalid");
  }
  if ((components !== 3 && components !== 4)
    || !(pixels instanceof Uint8Array) || pixels.length < size * components) {
    throw new TypeError("Solid-background matte requires RGB/RGBA Uint8Array pixels");
  }
  if (!(trimap instanceof Uint8Array) || trimap.length !== size) {
    throw new RangeError("Solid-background matte requires a matching trimap");
  }
  if (!Array.isArray(background) || background.length !== 3
    || background.some((value) => !Number.isFinite(value))) {
    throw new TypeError("Solid-background matte requires an RGB background color");
  }
}

function pushMaximum(deque, values, head, tail, index) {
  while (tail > head && values[deque[tail - 1]] <= values[index]) tail -= 1;
  deque[tail] = index;
  return tail + 1;
}

function* exteriorNonKeepSteps(width, height, trimap) {
  const size = width * height;
  const exterior = new Uint8Array(size);
  const queue = new Int32Array(size);
  let head = 0;
  let tail = 0;
  let completed = 0;
  const enqueue = (index) => {
    if (exterior[index] || trimap[index] === LABELS.KEEP) return;
    exterior[index] = 1;
    queue[tail] = index;
    tail += 1;
  };

  for (let x = 0; x < width; x += 1) {
    enqueue(x);
    enqueue((height - 1) * width + x);
  }
  for (let y = 0; y < height; y += 1) {
    enqueue(y * width);
    enqueue(y * width + width - 1);
  }

  while (head < tail) {
    const index = queue[head];
    head += 1;
    const x = index % width;
    const y = Math.floor(index / width);
    if (x > 0) enqueue(index - 1);
    if (x + 1 < width) enqueue(index + 1);
    if (y > 0) enqueue(index - width);
    if (y + 1 < height) enqueue(index + width);
    completed += 1;
    if (completed % YIELD_INTERVAL === 0) {
      yield { phase: "solid-background-exterior", completed, total: size * 3 };
    }
  }
  return { exterior, pixels: tail };
}

function* solidBackgroundMatteSteps(request) {
  validateRequest(request);
  const {
    pixels,
    width,
    height,
    components = 3,
    trimap,
    background,
    backgroundSpread = 0
  } = request;
  const size = width * height;
  const radius = clamp(Math.round(Number(request.localRadius) || 3), 1, 16);
  const noiseFloor = clamp(Number(backgroundSpread) * 3, 0, 32);
  const exteriorResult = yield* exteriorNonKeepSteps(width, height, trimap);
  const exteriorNonKeep = exteriorResult.exterior;
  const horizontalMaximum = new Float32Array(size);
  const horizontalKeep = new Uint8Array(size);
  const rowDistances = new Float32Array(width);
  const rowDeque = new Int32Array(width);
  const rowKeep = new Uint8Array(width);
  const rowKeepDeque = new Int32Array(width);
  let reliableForegroundDistance = 0;
  let completed = 0;

  for (let y = 0; y < height; y += 1) {
    const rowStart = y * width;
    for (let x = 0; x < width; x += 1) {
      const index = rowStart + x;
      rowDistances[x] = backgroundSeparation(
        pixels,
        components,
        index,
        background,
        trimap[index] === LABELS.UNKNOWN
      );
      rowKeep[x] = trimap[index] === LABELS.KEEP ? 1 : 0;
      if (rowKeep[x]) reliableForegroundDistance = Math.max(reliableForegroundDistance, rowDistances[x]);
    }
    let head = 0;
    let tail = 0;
    let next = 0;
    let keepHead = 0;
    let keepTail = 0;
    let keepNext = 0;
    for (let x = 0; x < width; x += 1) {
      const right = Math.min(width - 1, x + radius);
      while (next <= right) {
        tail = pushMaximum(rowDeque, rowDistances, head, tail, next);
        next += 1;
      }
      while (keepNext <= right) {
        keepTail = pushMaximum(rowKeepDeque, rowKeep, keepHead, keepTail, keepNext);
        keepNext += 1;
      }
      const left = Math.max(0, x - radius);
      while (head < tail && rowDeque[head] < left) head += 1;
      while (keepHead < keepTail && rowKeepDeque[keepHead] < left) keepHead += 1;
      horizontalMaximum[rowStart + x] = rowDistances[rowDeque[head]];
      horizontalKeep[rowStart + x] = rowKeep[rowKeepDeque[keepHead]];
      completed += 1;
      if (completed % YIELD_INTERVAL === 0) {
        yield { phase: "solid-background-horizontal", completed: size + completed, total: size * 3 };
      }
    }
  }

  const alpha = new Uint8Array(size);
  const columnDeque = new Int32Array(height);
  const columnKeepDeque = new Int32Array(height);
  let keepPixels = 0;
  let cutPixels = 0;
  let unknownPixels = 0;
  let softPixels = 0;
  for (let x = 0; x < width; x += 1) {
    let head = 0;
    let tail = 0;
    let next = 0;
    let keepHead = 0;
    let keepTail = 0;
    let keepNext = 0;
    for (let y = 0; y < height; y += 1) {
      const bottom = Math.min(height - 1, y + radius);
      while (next <= bottom) {
        const sourceIndex = next * width + x;
        while (tail > head) {
          const previousIndex = columnDeque[tail - 1] * width + x;
          if (horizontalMaximum[previousIndex] > horizontalMaximum[sourceIndex]) break;
          tail -= 1;
        }
        columnDeque[tail] = next;
        tail += 1;
        next += 1;
      }
      while (keepNext <= bottom) {
        const sourceIndex = keepNext * width + x;
        while (keepTail > keepHead) {
          const previousIndex = columnKeepDeque[keepTail - 1] * width + x;
          if (horizontalKeep[previousIndex] > horizontalKeep[sourceIndex]) break;
          keepTail -= 1;
        }
        columnKeepDeque[keepTail] = keepNext;
        keepTail += 1;
        keepNext += 1;
      }
      const top = Math.max(0, y - radius);
      while (head < tail && columnDeque[head] < top) head += 1;
      while (keepHead < keepTail && columnKeepDeque[keepHead] < top) keepHead += 1;

      const index = y * width + x;
      if (trimap[index] === LABELS.KEEP) {
        alpha[index] = 255;
        keepPixels += 1;
      } else if (trimap[index] === LABELS.CUT) {
        alpha[index] = 0;
        cutPixels += 1;
      } else if (trimap[index] === LABELS.UNKNOWN) {
        const localMaximum = horizontalMaximum[columnDeque[head] * width + x];
        const hasLocalKeep = horizontalKeep[columnKeepDeque[keepHead] * width + x] === 1;
        const distance = backgroundSeparation(
          pixels,
          components,
        index,
          background,
          true
        );
        const directionalBackgroundShade = distance
          < colorDistance(pixels, components, index, background) * 0.5;
        const useGlobalReference = reliableForegroundDistance > noiseFloor
          && (directionalBackgroundShade || (exteriorNonKeep[index] === 1 && !hasLocalKeep));
        const referenceDistance = useGlobalReference ? reliableForegroundDistance : localMaximum;
        const normalized = (distance - noiseFloor) / Math.max(1, referenceDistance - noiseFloor);
        alpha[index] = Math.round(clamp(normalized, 0, 1) * 255);
        unknownPixels += 1;
        if (alpha[index] > 0 && alpha[index] < 255) softPixels += 1;
      } else {
        throw new RangeError("Trimap labels must be unknown (0), keep (1), or cut (2)");
      }
      completed += 1;
      if (completed % YIELD_INTERVAL === 0) {
        yield { phase: "solid-background-alpha", completed: size + completed, total: size * 3 };
      }
    }
  }

  return {
    alpha,
    diagnostics: {
      strategy: "solid-background",
      background: background.slice(),
      backgroundSpread: Number(backgroundSpread) || 0,
      keepPixels,
      cutPixels,
      unknownPixels,
      softPixels,
      exteriorNonKeepPixels: exteriorResult.pixels,
      fringeMode: "mask-only",
      warnings: []
    }
  };
}

function computeSolidBackgroundMatte(request) {
  return runStepsSync(solidBackgroundMatteSteps(request));
}

function computeSolidBackgroundMatteAsync(request) {
  return runStepsAsync(
    solidBackgroundMatteSteps(request),
    request && request.signal,
    request && request.onProgress
  );
}

module.exports = { computeSolidBackgroundMatte, computeSolidBackgroundMatteAsync };
