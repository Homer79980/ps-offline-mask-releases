const OVERLAY_COLORS = Object.freeze({
  keep: Object.freeze([70, 225, 120, 110]),
  cut: Object.freeze([240, 90, 90, 115]),
  unknown: Object.freeze([80, 155, 255, 69])
});

function colorForLabel(label, labels) {
  if (label === labels.KEEP) return OVERLAY_COLORS.keep;
  if (label === labels.CUT) return OVERLAY_COLORS.cut;
  if (label === labels.UNKNOWN) return OVERLAY_COLORS.unknown;
  return null;
}

function createTrimapOverlayPixels(trimap, { maxDimension = 1024, labels } = {}) {
  if (!trimap || !Number.isInteger(trimap.width) || !Number.isInteger(trimap.height)) {
    throw new TypeError("trimap dimensions are required");
  }
  const resolvedLabels = labels || require("../core/trimap").LABELS;
  const maximum = Math.max(1, Math.round(Number(maxDimension) || 1024));
  const scale = Math.min(1, maximum / Math.max(trimap.width, trimap.height));
  const width = Math.max(1, Math.round(trimap.width * scale));
  const height = Math.max(1, Math.round(trimap.height * scale));
  const pixels = new Uint8Array(width * height * 4);

  for (let y = 0; y < height; y += 1) {
    const sourceY = Math.min(trimap.height - 1, Math.floor(y / scale));
    for (let x = 0; x < width; x += 1) {
      const sourceX = Math.min(trimap.width - 1, Math.floor(x / scale));
      const sourceIndex = sourceY * trimap.width + sourceX;
      if (!trimap.painted[sourceIndex]) continue;
      const color = colorForLabel(trimap.data[sourceIndex], resolvedLabels);
      if (!color) continue;
      const targetIndex = (y * width + x) * 4;
      pixels[targetIndex] = color[0];
      pixels[targetIndex + 1] = color[1];
      pixels[targetIndex + 2] = color[2];
      pixels[targetIndex + 3] = color[3];
    }
  }

  return { width, height, components: 4, pixels };
}

module.exports = { createTrimapOverlayPixels, OVERLAY_COLORS };
