function finite(value) {
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : null;
}

function eventFamily(event) {
  const type = String(event && event.type || "").toLowerCase();
  if (type.startsWith("pointer")) return "pointer";
  if (type.startsWith("mouse")) return "mouse";
  return "unknown";
}

function normalizePointerEvent(event = {}, target, activeButtons = 0) {
  const rect = target && typeof target.getBoundingClientRect === "function"
    ? target.getBoundingClientRect()
    : { left: 0, top: 0 };
  const clientX = finite(event.clientX)
    ?? (finite(event.offsetX) === null ? finite(event.pageX) : Number(rect.left || 0) + Number(event.offsetX));
  const clientY = finite(event.clientY)
    ?? (finite(event.offsetY) === null ? finite(event.pageY) : Number(rect.top || 0) + Number(event.offsetY));

  return {
    type: String(event.type || ""),
    family: eventFamily(event),
    clientX: clientX ?? 0,
    clientY: clientY ?? 0,
    button: finite(event.button) ?? 0,
    buttons: finite(event.buttons) ?? Number(activeButtons || 0),
    pointerId: event.pointerId,
    originalEvent: event
  };
}

function isEditableTarget(target) {
  const tagName = String(target && target.tagName || "").toLowerCase();
  return Boolean(target && (target.isContentEditable
    || ["button", "input", "select", "textarea"].includes(tagName)));
}

function bracketDirection(event) {
  const key = String(event && event.key || "");
  const code = String(event && event.code || "");
  const legacy = Number(event && (event.keyCode ?? event.which));
  if (key === "[" || code === "BracketLeft" || legacy === 219) return -1;
  if (key === "]" || code === "BracketRight" || legacy === 221) return 1;
  return 0;
}

function shortcutFromKeyboard(event = {}) {
  if (isEditableTarget(event.target)) return null;
  const type = String(event.type || "keydown").toLowerCase();
  const key = String(event.key || "").toLowerCase();
  const code = String(event.code || "");
  const space = key === " " || key === "spacebar" || code === "Space";
  if (space) return { kind: "space", pressed: type !== "keyup" };
  if (type === "keyup") return null;

  if (key === "escape" || code === "Escape") return { kind: "cancel-stroke" };

  const bracket = bracketDirection(event);
  if (bracket !== 0) {
    return {
      kind: event.shiftKey ? "brush-softness" : "brush-size",
      delta: bracket
    };
  }

  const primaryModifier = Boolean(event.ctrlKey || event.metaKey);
  const isZ = key === "z" || code === "KeyZ";
  if (primaryModifier && isZ) return { kind: event.shiftKey ? "redo" : "undo" };
  if (primaryModifier || event.altKey) return null;
  if (key === "h" || code === "KeyH") return { kind: "tool", tool: "hand" };
  if (isZ) return { kind: "tool", tool: "zoom" };
  return null;
}

module.exports = { normalizePointerEvent, shortcutFromKeyboard };
