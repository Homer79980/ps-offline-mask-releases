const MAX_LOCAL_PIXELS = 16_777_216;
const MAX_LOCAL_SOURCE_BYTES = 64 * 1024 * 1024;

function formatHostErrorBase(error) {
  if (typeof error === "string" || typeof error === "number" || typeof error === "boolean") {
    const value = String(error).trim();
    if (value) return value;
  }
  if (error && typeof error === "object") {
    const fields = [error.message, error.description, error.reason];
    const detail = fields.find((value) => value !== undefined && value !== null && String(value).trim());
    const code = [error.code, error.number, error.result]
      .find((value) => value !== undefined && value !== null && String(value).trim());
    const codeText = code === undefined ? null : String(code).trim();
    if (detail !== undefined) {
      const text = String(detail).trim();
      if (codeText && !text.includes(codeText)) {
        return `${text}（Photoshop 错误代码 ${codeText}）`;
      }
      return text;
    }
    if (codeText) return `Photoshop 错误代码 ${codeText}`;
    if (error.name && String(error.name).trim() && error.name !== "Error") return String(error.name).trim();
  }
  return "Photoshop 未返回详细错误";
}

function formatHostError(error) {
  const primary = formatHostErrorBase(error);
  if (!error || typeof error !== "object" || !error.restoreError) return primary;
  return `${primary}；原蒙版恢复失败：${formatHostErrorBase(error.restoreError)}`;
}

function stageHostError(stage, error) {
  const detail = formatHostError(error);
  const normalized = new Error(`${stage}失败：${detail}`);
  normalized.originalError = error;
  return normalized;
}

function isModalScopeRequiredError(error) {
  const detail = formatHostErrorBase(error).toLowerCase();
  if (detail.includes("ps_executeasmodal")) return true;
  if (detail.includes("modal scope") && /(only allowed|must|required|requires)/.test(detail)) return true;
  return detail.includes("模态") && /(仅允许|只允许|必须|需要)/.test(detail);
}

function pixelReadHostError(error) {
  const detail = formatHostError(error);
  if (/无法更新智能对象文件|unable to update (?:the )?smart object file/i.test(detail)) {
    const normalized = new Error(
      `读取 Photoshop 图层像素失败：Photoshop 返回了智能对象文件更新错误。` +
      `若文档包含智能对象，请检查其链接资源；也可将需要抠图的内容复制到普通像素图层后再试。` +
      `原始错误：${detail}`
    );
    normalized.originalError = error;
    return normalized;
  }
  return stageHostError("读取 Photoshop 图层像素", error);
}

function photoshopMajorVersion(hostVersion, app, photoshop) {
  const raw = hostVersion !== undefined && hostVersion !== null
    ? hostVersion
    : app && app.version !== undefined
      ? app.version
      : photoshop && photoshop.version !== undefined
        ? photoshop.version
        : null;
  const match = String(raw || "").match(/(\d+)/);
  return match ? Number(match[1]) : null;
}

function toBounds(bounds) {
  if (!bounds) throw new Error("图层没有有效边界");
  const left = Math.round(Number(bounds.left) || 0);
  const top = Math.round(Number(bounds.top) || 0);
  const width = Math.max(1, Math.round(Number(bounds.width) || (Number(bounds.right) - left)));
  const height = Math.max(1, Math.round(Number(bounds.height) || (Number(bounds.bottom) - top)));
  return { left, top, width, height, right: left + width, bottom: top + height };
}

function copy8BitData(data, expectedLength, errorMessage) {
  if (data === null || data === undefined) throw new Error(errorMessage);
  if (ArrayBuffer.isView(data) && data.BYTES_PER_ELEMENT !== 1) {
    throw new Error(errorMessage);
  }
  if (Array.isArray(data) && data.some((value) => !Number.isInteger(value) || value < 0 || value > 255)) {
    throw new Error(errorMessage);
  }
  let copy;
  try {
    copy = new Uint8Array(data);
  } catch (error) {
    throw new Error(errorMessage);
  }
  if (copy.length !== expectedLength) throw new Error(errorMessage);
  return copy;
}

function normalizePixelDataTo8Bit(data, componentSize, expectedLength, errorMessage) {
  const depth = Number(componentSize);
  if (depth === 8) return copy8BitData(data, expectedLength, errorMessage);
  if (!ArrayBuffer.isView(data) || data.length !== expectedLength) {
    throw new Error(errorMessage);
  }

  const expectedBytes = depth === 16 ? 2 : depth === 32 ? 4 : 0;
  const expectedType = depth === 16 ? "[object Uint16Array]" : "[object Float32Array]";
  if (
    !expectedBytes
    || data.BYTES_PER_ELEMENT !== expectedBytes
    || Object.prototype.toString.call(data) !== expectedType
  ) {
    throw new Error(errorMessage);
  }

  const maximum = depth === 16 ? 32768 : 1;
  const output = new Uint8Array(expectedLength);
  for (let index = 0; index < expectedLength; index += 1) {
    const value = Number(data[index]);
    if (!Number.isFinite(value)) throw new Error(errorMessage);
    output[index] = Math.round((Math.min(maximum, Math.max(0, value)) / maximum) * 255);
  }
  return output;
}

function layerCollectionValues(collection) {
  if (!collection) return [];
  if (Array.isArray(collection)) return [...collection];
  const values = [];
  if (typeof collection.forEach === "function") {
    collection.forEach((layer) => { values.push(layer); });
    return values;
  }
  const length = Math.max(0, Number(collection.length) || 0);
  for (let index = 0; index < length; index += 1) {
    if (collection[index]) values.push(collection[index]);
  }
  return values;
}

/**
 * Build the small Photoshop-facing adapter used by the panel.
 *
 * `action`/`batchPlay` are optional because older callers only injected the
 * four dependencies used by the first version of this adapter. They are used
 * solely for removing a mask that did not exist before a temporary preview.
 */
function createPhotoshopHost({ app, constants, imaging, core, action, batchPlay, photoshop, hostVersion } = {}) {
  const play = typeof batchPlay === "function"
    ? batchPlay
    : action && typeof action.batchPlay === "function"
      ? action.batchPlay.bind(action)
      : photoshop && photoshop.action && typeof photoshop.action.batchPlay === "function"
        ? photoshop.action.batchPlay.bind(photoshop.action)
        : null;
  const layerRefs = new Map();
  const maskSnapshots = new Map();
  let activePreviewKey = null;
  let activePreviewLayerInfo = null;

  function layerKey(layerInfo) {
    if (!layerInfo || !Number.isFinite(Number(layerInfo.documentID)) || !Number.isFinite(Number(layerInfo.layerID))) {
      throw new Error("图层信息不完整。");
    }
    return `${layerInfo.documentID}:${layerInfo.layerID}`;
  }

  function normalizedLayerInfo(layerInfo) {
    layerKey(layerInfo);
    const bounds = toBounds(layerInfo.bounds);
    return {
      ...layerInfo,
      bounds
    };
  }

  function copyAlpha(alpha, layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    const expectedLength = normalized.bounds.width * normalized.bounds.height;
    if (!(alpha instanceof Uint8Array) || alpha.length !== expectedLength) {
      throw new Error("蒙版尺寸与图层边界不一致。");
    }
    return new Uint8Array(alpha);
  }

  function layerReference(layerInfo) {
    return layerRefs.get(layerKey(layerInfo)) || layerInfo.layer || layerInfo.layerRef || null;
  }

  function assertDocumentIsActive(layerInfo) {
    const activeDocument = app && app.activeDocument;
    if (!activeDocument) {
      throw new Error("当前 Photoshop 文档不可用，请重新读取图层。");
    }
    if (activeDocument.id !== undefined && Number(activeDocument.id) !== Number(layerInfo.documentID)) {
      throw new Error("当前 Photoshop 文档已切换，请重新读取图层。");
    }
  }

  function assertLayerIsSelected(layerInfo) {
    assertDocumentIsActive(layerInfo);
    const activeDocument = app && app.activeDocument;
    // Explicit Imaging layer IDs can address any currently selected pixel
    // layer. This keeps Photoshop's multi-selection intact during a batch.
    if (!activeDocument.activeLayers) return layerReference(layerInfo);
    const activeLayers = layerCollectionValues(activeDocument.activeLayers);
    if (Array.isArray(layerInfo.selectionLayerIDs)) {
      const currentIDs = activeLayers.map((layer) => Number(layer.id)).sort((a, b) => a - b);
      const expectedIDs = layerInfo.selectionLayerIDs.map(Number).sort((a, b) => a - b);
      if (currentIDs.length !== expectedIDs.length || currentIDs.some((id, index) => id !== expectedIDs[index])) {
        throw new Error("Photoshop 图层选择已变化，已停止批量抠图。");
      }
    }
    const selectedLayer = activeLayers.find((layer) => Number(layer.id) === Number(layerInfo.layerID));
    if (!selectedLayer) {
      throw new Error("当前 Photoshop 图层已切换，请重新读取图层。");
    }
    const currentBoundsSource = selectedLayer.boundsNoEffects || selectedLayer.bounds;
    if (currentBoundsSource && layerInfo.bounds) {
      const currentBounds = toBounds(currentBoundsSource);
      const expectedBounds = toBounds(layerInfo.bounds);
      const changed = ["left", "top", "width", "height"]
        .some((key) => currentBounds[key] !== expectedBounds[key]);
      if (changed) throw new Error("当前 Photoshop 图层边界已变化，请重新读取图层。");
    }
    return selectedLayer;
  }

  function isBackgroundLayer(document, layer) {
    if (!layer) return false;
    if (layer.isBackgroundLayer === true) return true;
    try {
      const background = document && document.backgroundLayer;
      return Boolean(background && Number(background.id) === Number(layer.id));
    } catch (error) {
      return false;
    }
  }

  function maskWriteBlockReason(document, layer) {
    if (isBackgroundLayer(document, layer)) {
      return "背景图层不能直接应用蒙版；请先双击“背景”将其转换为普通像素图层，然后重新读取。";
    }
    if (layer && layer.allLocked === true) {
      return `图层“${layer.name || "未命名图层"}”已完全锁定；请先解锁图层，然后重新读取。`;
    }
    return null;
  }

  function unsupportedPixelLayerReason(layer) {
    const layerKind = constants && constants.LayerKind;
    if (layerKind && layerKind.SMARTOBJECT !== undefined && layer.kind === layerKind.SMARTOBJECT) {
      return "当前图层是智能对象，暂不支持直接抠图；请修复智能对象链接，或复制后栅格化为普通像素图层。";
    }
    if (!layerKind || layer.kind !== layerKind.NORMAL) {
      return "第一版只支持普通像素图层。";
    }
    return null;
  }

  function assertLayerCanAcceptMask(layerInfo) {
    const layer = assertLayerIsSelected(layerInfo);
    const pixelBlockReason = unsupportedPixelLayerReason(layer || layerReference(layerInfo));
    if (pixelBlockReason) throw new Error(pixelBlockReason);
    const reason = maskWriteBlockReason(app && app.activeDocument, layer || layerReference(layerInfo));
    if (reason) throw new Error(reason);
    return layer;
  }

  function hasKnownMissingMask(layerInfo) {
    const candidate = layerReference(layerInfo);
    const userMaskValues = [
      layerInfo && layerInfo.hasUserMask,
      layerInfo && layerInfo.pixelMask && layerInfo.pixelMask.hasMask,
      layerInfo && layerInfo.userMask && layerInfo.userMask.hasMask,
      candidate && candidate.hasUserMask,
      candidate && candidate.pixelMask && candidate.pixelMask.hasMask,
      candidate && candidate.userMask && candidate.userMask.hasMask
    ];
    if (userMaskValues.some((value) => value === true)) return false;
    if (userMaskValues.some((value) => value === false)) return true;

    // Generic `hasMask` may include a vector mask, so only consult it when no
    // user/pixel-mask-specific metadata exists.
    const genericValues = [layerInfo && layerInfo.hasMask, candidate && candidate.hasMask];
    if (genericValues.some((value) => value === true)) return false;
    return genericValues.some((value) => value === false);
  }

  function isMissingMaskError(error) {
    const message = String(error && error.message || error || "").toLowerCase();
    const code = String(error && (error.code || error.number || error.name) || "").toLowerCase();
    const combined = `${message} ${code}`;
    return /(mask|channel|蒙版)/.test(combined)
      && /(not found|does not exist|doesn't exist|no such|missing|absent|not available|no .*mask|without .*mask|invalid .*channel|channel .*invalid|蒙版不存在|没有.*蒙版)/.test(combined);
  }

  function isMessageLessMaskError(error) {
    if (error === null || error === undefined) return true;
    const message = String(error && error.message || "").trim();
    const code = error && (error.code ?? error.number);
    return message.length === 0 && (code === null || code === undefined || String(code).trim() === "");
  }

  function maskBounds(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    return {
      left: normalized.bounds.left,
      top: normalized.bounds.top,
      right: normalized.bounds.right,
      bottom: normalized.bounds.bottom
    };
  }

  function maskSnapshotCopy(snapshot) {
    return {
      documentID: snapshot.documentID,
      layerID: snapshot.layerID,
      width: snapshot.width,
      height: snapshot.height,
      bounds: { ...snapshot.bounds },
      present: snapshot.present === true,
      hasMask: snapshot.present === true,
      alpha: snapshot.alpha ? new Uint8Array(snapshot.alpha) : null,
      mask: snapshot.alpha ? new Uint8Array(snapshot.alpha) : null
    };
  }

  function canRemoveLayerMask(layerInfo) {
    if (play) return true;
    const layer = layerReference(layerInfo);
    if (!layer) return false;
    const masks = [layer.pixelMask, layer.userMask].filter(Boolean);
    return typeof layer.removeLayerMask === "function"
      || typeof layer.deleteLayerMask === "function"
      || masks.some((mask) => typeof mask.remove === "function" || typeof mask.delete === "function");
  }

  function emptyMaskSnapshot(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    return {
      documentID: normalized.documentID,
      layerID: normalized.layerID,
      width: normalized.bounds.width,
      height: normalized.bounds.height,
      bounds: { ...normalized.bounds },
      present: false,
      hasMask: false,
      alpha: null,
      mask: null
    };
  }

  function resolvedActionError(result) {
    const descriptor = Array.isArray(result)
      ? result.find((item) => item && String(item._obj || "").toLowerCase() === "error")
      : null;
    if (!descriptor || String(descriptor._obj || "").toLowerCase() !== "error") return null;
    return stageHostError("Photoshop 操作", descriptor);
  }

  async function playActions(commands, stage) {
    if (!play) throw new Error(`${stage}失败：Photoshop action.batchPlay API 不可用。`);
    let result;
    try {
      result = await play(commands, {});
    } catch (error) {
      throw stageHostError(stage, error);
    }
    const actionError = resolvedActionError(result);
    if (actionError) throw stageHostError(stage, actionError.originalError || actionError);
    return result;
  }

  async function queryLayerHasUserMask(layerInfo, { required = false } = {}) {
    if (!play) {
      if (required) {
        const failure = new Error("检测图层蒙版失败：Photoshop action.batchPlay API 不可用。");
        failure.maskPresenceQueryFailed = true;
        throw failure;
      }
      return null;
    }
    try {
      const result = await play([{
        _obj: "get",
        _target: [
          { _property: "hasUserMask" },
          { _ref: "layer", _id: layerInfo.layerID },
          { _ref: "document", _id: layerInfo.documentID }
        ]
      }], {});
      const actionError = resolvedActionError(result);
      if (actionError) throw actionError;
      const descriptor = Array.isArray(result) ? result[0] : null;
      if (descriptor && typeof descriptor.hasUserMask === "boolean") return descriptor.hasUserMask;
      if (required) throw new Error("检测图层蒙版失败：Photoshop 未返回 hasUserMask 状态。");
      return null;
    } catch (error) {
      if (required) {
        const failure = stageHostError("检测图层蒙版", error);
        failure.maskPresenceQueryFailed = true;
        throw failure;
      }
      return null;
    }
  }

  async function executeModal(work, commandName) {
    if (!core || typeof core.executeAsModal !== "function") {
      throw new Error("Photoshop executeAsModal API 不可用。");
    }
    return core.executeAsModal(work, { commandName });
  }

  function currentSelectedLayerIDs() {
    const document = app && app.activeDocument;
    return layerCollectionValues(document && document.activeLayers)
      .map((layer) => Number(layer && layer.id))
      .filter(Number.isFinite);
  }

  function selectLayerCommands(layerIDs) {
    return layerIDs.map((layerID, index) => ({
      _obj: "select",
      _target: [{ _ref: "layer", _id: layerID }],
      ...(index === 0 ? {} : {
        selectionModifier: { _enum: "selectionModifierType", _value: "addToSelection" }
      }),
      makeVisible: false,
      _options: { dialogOptions: "dontDisplay" }
    }));
  }

  async function selectLayers(layerIDs, stage) {
    if (!Array.isArray(layerIDs) || layerIDs.length === 0) return;
    await playActions(selectLayerCommands(layerIDs), stage);
  }

  async function ensureTargetLayerActive(layerInfo) {
    const targetID = Number(layerInfo.layerID);
    const currentIDs = currentSelectedLayerIDs();
    const selectionChanged = currentIDs.length !== 1 || currentIDs[0] !== targetID;
    if (selectionChanged) await selectLayers([targetID], "定位目标图层");
    const result = await playActions([{
      _obj: "get",
      _target: [
        { _property: "layerID" },
        { _ref: "layer", _enum: "ordinal", _value: "targetEnum" },
        { _ref: "document", _id: layerInfo.documentID }
      ]
    }], "验证目标图层");
    const descriptor = Array.isArray(result) ? result[0] : null;
    if (!descriptor || Number(descriptor.layerID) !== targetID) {
      throw new Error("验证目标图层失败：Photoshop 当前活动图层与目标图层不一致。");
    }
    return selectionChanged;
  }

  function isMissingSelectionError(error) {
    const text = formatHostError(error).toLowerCase();
    return /(no|without|missing|empty|not found|does not exist|not available).{0,18}selection/.test(text)
      || /selection.{0,18}(no|missing|empty|not found|does not exist|not available)/.test(text)
      || /(没有|不存在|空).{0,8}选区|选区.{0,8}(没有|不存在|为空)/.test(text);
  }

  async function captureDocumentSelection(documentID) {
    if (!imaging || typeof imaging.getSelection !== "function") {
      throw new Error("保存原选区失败：Photoshop imaging.getSelection API 不可用。");
    }
    try {
      const result = await imaging.getSelection({ documentID });
      if (!result || !result.imageData) return { present: false, imageData: null, bounds: null };
      const bounds = result.sourceBounds ? toBounds(result.sourceBounds) : { left: 0, top: 0 };
      return { present: true, imageData: result.imageData, bounds };
    } catch (error) {
      if (isMissingSelectionError(error)) return { present: false, imageData: null, bounds: null };
      throw stageHostError("保存原选区", error);
    }
  }

  async function restoreDocumentSelection(documentID, snapshot) {
    if (snapshot && snapshot.present) {
      try {
        await imaging.putSelection({
          documentID,
          imageData: snapshot.imageData,
          replace: true,
          targetBounds: {
            left: snapshot.bounds.left,
            top: snapshot.bounds.top
          },
          commandName: "恢复抠图前选区"
        });
      } catch (error) {
        throw stageHostError("恢复原选区", error);
      }
      return;
    }
    await playActions([{
      _obj: "set",
      _target: [{ _ref: "channel", _property: "selection" }],
      to: { _enum: "ordinal", _value: "none" },
      _options: { dialogOptions: "dontDisplay" }
    }], "清除临时选区");
  }

  function disposeImageData(imageData) {
    if (imageData && typeof imageData.dispose === "function") imageData.dispose();
  }

  function makeMaskDescriptor(mode) {
    return {
      _obj: "make",
      new: { _class: "channel" },
      at: { _ref: "channel", _enum: "channel", _value: "mask" },
      using: { _enum: "userMaskEnabled", _value: mode },
      _options: { dialogOptions: "dontDisplay" }
    };
  }

  function maskCreationMode(alpha) {
    let allHidden = true;
    let allVisible = true;
    for (let index = 0; index < alpha.length; index += 1) {
      if (alpha[index] !== 0) allHidden = false;
      if (alpha[index] !== 255) allVisible = false;
      if (!allHidden && !allVisible) return "revealSelection";
    }
    if (allHidden) return "hideAll";
    if (allVisible) return "revealAll";
    return "revealSelection";
  }

  function deleteMaskDescriptor(layerID) {
    return {
      _obj: "delete",
      _target: [
        { _ref: "channel", _enum: "channel", _value: "mask" },
        { _ref: "layer", _id: layerID }
      ],
      _options: { dialogOptions: "dontDisplay" }
    };
  }

  function deleteLayerDescriptor(layerID) {
    return {
      _obj: "delete",
      _target: [{ _ref: "layer", _id: layerID }],
      _options: { dialogOptions: "dontDisplay" }
    };
  }

  async function writeLayerMaskThroughSelection(normalized, copy) {
    if (!play || !imaging || typeof imaging.putSelection !== "function") {
      throw new Error("Photoshop 24.x 兼容写入不可用：需要 imaging.putSelection 和 action.batchPlay。");
    }
    const originalLayerIDs = currentSelectedLayerIDs();
    await executeModal(async () => {
      let originalSelection = null;
      let maskData = null;
      let operationError = null;
      let cleanupError = null;
      let layerSelectionChanged = false;
      const creationMode = maskCreationMode(copy);
      try {
        layerSelectionChanged = originalLayerIDs.length !== 1
          || originalLayerIDs[0] !== Number(normalized.layerID);
        await ensureTargetLayerActive(normalized);
        const hasUserMask = await queryLayerHasUserMask(normalized, { required: true });
        if (creationMode === "revealSelection") {
          originalSelection = await captureDocumentSelection(normalized.documentID);
          try {
            maskData = await imaging.createImageDataFromBuffer(copy, {
              width: normalized.bounds.width,
              height: normalized.bounds.height,
              components: 1,
              chunky: false,
              colorProfile: "Gray Gamma 2.2",
              colorSpace: "Grayscale"
            });
          } catch (error) {
            throw stageHostError("创建灰度蒙版数据", error);
          }
          try {
            await imaging.putSelection({
              documentID: normalized.documentID,
              imageData: maskData,
              replace: true,
              targetBounds: {
                left: normalized.bounds.left,
                top: normalized.bounds.top
              },
              commandName: "准备离线抠图蒙版"
            });
          } catch (error) {
            throw stageHostError("写入临时选区", error);
          }
        }

        if (hasUserMask) {
          await playActions([deleteMaskDescriptor(normalized.layerID)], "替换现有图层蒙版");
        }
        await playActions([makeMaskDescriptor(creationMode)], "创建图层蒙版");
        const created = await queryLayerHasUserMask(normalized, { required: true });
        if (!created) throw new Error("创建图层蒙版失败：Photoshop 未生成用户蒙版。");
      } catch (error) {
        operationError = error instanceof Error && String(error.message || "").trim()
          ? error
          : stageHostError("应用图层蒙版", error);
      } finally {
        disposeImageData(maskData);
        if (originalSelection) {
          try {
            await restoreDocumentSelection(normalized.documentID, originalSelection);
          } catch (error) {
            cleanupError = error;
          }
        }
        if (layerSelectionChanged) {
          try {
            await selectLayers(originalLayerIDs, "恢复图层选择");
          } catch (error) {
            cleanupError = cleanupError || error;
          }
        }
        disposeImageData(originalSelection && originalSelection.imageData);
      }
      if (operationError) {
        if (cleanupError) operationError.restoreError = cleanupError;
        throw operationError;
      }
      if (cleanupError) throw cleanupError;
    }, "兼容应用离线抠图蒙版");
  }

  async function removeLayerUserMask(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    assertLayerIsSelected(normalized);
    const layerID = normalized.layerID;
    const originalLayerIDs = currentSelectedLayerIDs();
    await executeModal(async () => {
      if (play) {
        let layerSelectionChanged = false;
        let operationError = null;
        let cleanupError = null;
        try {
          layerSelectionChanged = originalLayerIDs.length !== 1
            || originalLayerIDs[0] !== Number(normalized.layerID);
          await ensureTargetLayerActive(normalized);
          const hasUserMask = await queryLayerHasUserMask(normalized, { required: true });
          if (hasUserMask) {
            await playActions([deleteMaskDescriptor(layerID)], "删除图层蒙版");
          }
        } catch (error) {
          operationError = error;
        } finally {
          if (layerSelectionChanged) {
            try {
              await selectLayers(originalLayerIDs, "恢复图层选择");
            } catch (error) {
              cleanupError = error;
            }
          }
        }
        if (operationError) {
          if (cleanupError) operationError.restoreError = cleanupError;
          throw operationError;
        }
        if (cleanupError) throw cleanupError;
        return;
      }

      const layer = layerReference(normalized);
      const mask = layer && (layer.pixelMask || layer.userMask);
      const remove = layer && (layer.removeLayerMask || layer.deleteLayerMask);
      if (typeof remove === "function") {
        await remove.call(layer);
        return;
      }
      if (mask && typeof mask.remove === "function") {
        await mask.remove();
        return;
      }
      if (mask && typeof mask.delete === "function") {
        await mask.delete();
        return;
      }
      throw new Error("Photoshop 无法删除临时图层蒙版，请注入 action.batchPlay。");
    }, "取消离线抠图蒙版预览");
  }

  async function readLayerMask(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    assertLayerIsSelected(normalized);
    const expectedWidth = normalized.bounds.width;
    const expectedHeight = normalized.bounds.height;
    const emptySnapshot = emptyMaskSnapshot(normalized);

    if (hasKnownMissingMask(normalized)) return emptySnapshot;

    let result;
    try {
      // Photoshop 27.x can enforce the modal scope for Imaging reads even
      // though older builds allowed getLayerMask outside it.
      const outcome = await executeModal(async () => {
        const hasUserMask = play
          ? await queryLayerHasUserMask(normalized, { required: true })
          : null;
        if (hasUserMask === false) return { missing: true, result: null };
        if (!imaging || typeof imaging.getLayerMask !== "function") {
          throw new Error("Photoshop imaging.getLayerMask API 不可用。");
        }
        return {
          missing: false,
          result: await imaging.getLayerMask({
            documentID: normalized.documentID,
            layerID: normalized.layerID,
            kind: "user",
            sourceBounds: maskBounds(normalized)
          })
        };
      }, "读取 Photoshop 图层蒙版");
      if (outcome.missing) return emptySnapshot;
      result = outcome.result;
    } catch (error) {
      if (error && error.maskPresenceQueryFailed) throw error;
      if (hasKnownMissingMask(normalized) || isMissingMaskError(error)) return emptySnapshot;
      throw error;
    }

    if (!result || !result.imageData) {
      if (hasKnownMissingMask(normalized)) return emptySnapshot;
      throw new Error("Photoshop 返回了无效的图层蒙版数据。");
    }
    const imageData = result.imageData;
    try {
      const width = Number(imageData.width);
      const height = Number(imageData.height);
      const components = Number(imageData.components);
      const componentSize = imageData.componentSize ?? imageData.bitsPerChannel;
      if (componentSize !== undefined && Number(componentSize) !== 8) {
        throw new Error("Photoshop 图层蒙版必须是 8-bit 数据。");
      }
      if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1) {
        throw new Error("Photoshop 返回了无效的图层蒙版尺寸。");
      }
      if (components !== 1) {
        throw new Error("Photoshop 图层蒙版必须是单通道灰度数据。");
      }
      if (width !== expectedWidth || height !== expectedHeight) {
        throw new Error("Photoshop 图层蒙版尺寸与图层边界不一致。");
      }
      const data = await imageData.getData({ chunky: true });
      const alpha = copy8BitData(data, expectedWidth * expectedHeight, "Photoshop 图层蒙版数据长度不正确。");
      const snapshot = {
        documentID: normalized.documentID,
        layerID: normalized.layerID,
        width: expectedWidth,
        height: expectedHeight,
        bounds: { ...normalized.bounds },
        present: true,
        hasMask: true,
        alpha,
        mask: new Uint8Array(alpha),
        sourceBounds: toBounds(result.sourceBounds || normalized.bounds)
      };
      return snapshot;
    } finally {
      if (typeof imageData.dispose === "function") imageData.dispose();
    }
  }

  async function saveLayerMask(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    const key = layerKey(normalized);
    if (maskSnapshots.has(key)) return maskSnapshotCopy(maskSnapshots.get(key));
    let snapshot;
    try {
      snapshot = await readLayerMask(normalized);
    } catch (error) {
      // Some Photoshop builds reject a missing user mask without a useful
      // error. Only accept that ambiguity when batchPlay can remove a mask
      // again if the following write fails.
      if (!isMessageLessMaskError(error) || !canRemoveLayerMask(normalized)) throw error;
      snapshot = emptyMaskSnapshot(normalized);
    }
    const copy = maskSnapshotCopy(snapshot);
    maskSnapshots.set(key, copy);
    return maskSnapshotCopy(copy);
  }

  async function writeLayerMask(layerInfo, alpha) {
    const normalized = normalizedLayerInfo(layerInfo);
    assertLayerCanAcceptMask(normalized);
    if (!imaging || typeof imaging.createImageDataFromBuffer !== "function") {
      throw new Error("Photoshop imaging.createImageDataFromBuffer API 不可用。");
    }
    const copy = copyAlpha(alpha, normalized);
    const majorVersion = photoshopMajorVersion(hostVersion, app, photoshop);
    if ((majorVersion !== null && majorVersion < 25) || typeof imaging.putLayerMask !== "function") {
      await writeLayerMaskThroughSelection(normalized, copy);
      return copy;
    }
    await executeModal(async () => {
      let maskData;
      try {
        maskData = await imaging.createImageDataFromBuffer(copy, {
          width: normalized.bounds.width,
          height: normalized.bounds.height,
          components: 1,
          chunky: false,
          colorProfile: "Gray Gamma 2.2",
          colorSpace: "Grayscale"
        });
      } catch (error) {
        throw stageHostError("创建灰度蒙版数据", error);
      }

      try {
        try {
          await imaging.putLayerMask({
            documentID: normalized.documentID,
            layerID: normalized.layerID,
            kind: "user",
            imageData: maskData,
            replace: true,
            targetBounds: {
              left: normalized.bounds.left,
              top: normalized.bounds.top
            },
            commandName: "应用离线抠图蒙版"
          });
        } catch (error) {
          throw stageHostError("写入图层蒙版", error);
        }
      } finally {
        disposeImageData(maskData);
      }
    }, "应用离线抠图蒙版");
    return copy;
  }

  async function restoreLayerMask(layerInfo, snapshot) {
    const normalized = normalizedLayerInfo(layerInfo);
    if (!snapshot || snapshot.present !== true) {
      await removeLayerUserMask(normalized);
      return;
    }
    await writeLayerMask(normalized, snapshot.alpha || snapshot.mask);
  }
  function getActivePixelLayer() {
    if (!app.documents || app.documents.length === 0) {
      throw new Error("请先打开一个 Photoshop 文档。");
    }

    const document = app.activeDocument;
    const layer = layerCollectionValues(document.activeLayers)[0];
    if (!layer) {
      throw new Error("请先选择一个图层。");
    }
    const pixelBlockReason = unsupportedPixelLayerReason(layer);
    if (pixelBlockReason) throw new Error(pixelBlockReason);
    const blockReason = maskWriteBlockReason(document, layer);
    if (blockReason) throw new Error(blockReason);

    const layerInfo = {
      documentID: document.id,
      layerID: layer.id,
      name: layer.name,
      bounds: toBounds(layer.boundsNoEffects || layer.bounds)
    };
    layerRefs.set(layerKey(layerInfo), layer);
    return { ...layerInfo };
  }

  function getSelectedPixelLayers() {
    if (!app.documents || app.documents.length === 0) {
      throw new Error("请先打开一个 Photoshop 文档。");
    }
    const document = app.activeDocument;
    const selected = layerCollectionValues(document.activeLayers);
    if (selected.length === 0) throw new Error("请先在图层面板选择至少一个图层。");
    const selectionLayerIDs = selected.map((layer) => Number(layer.id));
    const layers = [];
    const skipped = [];
    selected.forEach((layer) => {
      const pixelBlockReason = layer && unsupportedPixelLayerReason(layer);
      if (!layer || pixelBlockReason) {
        skipped.push({
          layerID: layer && layer.id,
          name: layer && layer.name ? layer.name : "未命名图层",
          reason: pixelBlockReason || "仅支持普通像素图层"
        });
        return;
      }
      const blockReason = maskWriteBlockReason(document, layer);
      if (blockReason) {
        skipped.push({
          layerID: layer.id,
          name: layer.name || "未命名图层",
          reason: blockReason
        });
        return;
      }
      try {
        const layerInfo = {
          documentID: document.id,
          layerID: layer.id,
          name: layer.name,
          selectionLayerIDs: [...selectionLayerIDs],
          bounds: toBounds(layer.boundsNoEffects || layer.bounds)
        };
        layerRefs.set(layerKey(layerInfo), layer);
        layers.push(layerInfo);
      } catch (error) {
        skipped.push({
          layerID: layer.id,
          name: layer.name || "未命名图层",
          reason: error.message || "图层边界不可用"
        });
      }
    });
    return { documentID: document.id, layers, skipped };
  }

  async function readLayerPixels(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo);
    const selectedLayer = assertLayerIsSelected(normalized);
    const pixelBlockReason = unsupportedPixelLayerReason(selectedLayer || layerReference(normalized));
    if (pixelBlockReason) throw new Error(pixelBlockReason);
    if (!imaging || typeof imaging.getPixels !== "function") {
      throw new Error("Photoshop imaging.getPixels API 不可用。");
    }
    const pixelOptions = {
      documentID: normalized.documentID,
      layerID: normalized.layerID,
      sourceBounds: {
        left: normalized.bounds.left,
        top: normalized.bounds.top,
        right: normalized.bounds.right,
        bottom: normalized.bounds.bottom
      },
      applyAlpha: false
    };

    // Pixel acquisition is read-only. Avoid opening a modal transaction unless
    // this Photoshop build explicitly rejects the direct Imaging call.
    let result;
    try {
      result = await imaging.getPixels(pixelOptions);
    } catch (error) {
      if (!isModalScopeRequiredError(error)) throw pixelReadHostError(error);
      try {
        result = await executeModal(() => imaging.getPixels(pixelOptions), "读取 Photoshop 图层像素");
      } catch (modalError) {
        throw pixelReadHostError(modalError);
      }
    }
    if (!result || !result.imageData) {
      throw new Error("Photoshop 返回了无效的图层像素数据。");
    }
    const imageData = result.imageData;
    try {
      const width = Number(imageData.width);
      const height = Number(imageData.height);
      const components = Number(imageData.components);
      const componentSize = imageData.componentSize ?? imageData.bitsPerChannel;
      const colorSpace = String(imageData.colorSpace || "").trim().toUpperCase();
      if (componentSize === undefined || componentSize === null || componentSize === "") {
        throw new Error("Photoshop 未返回图层像素位深；为避免误读，已停止处理。");
      }
      const pixelDepth = Number(componentSize);
      if (![8, 16, 32].includes(pixelDepth)) {
        throw new Error(`Photoshop 返回了不受支持的图层像素位深：${String(componentSize)}-bit；仅支持 8/16/32-bit RGB 数据。`);
      }
      if (!colorSpace) {
        throw new Error("Photoshop 未返回图层像素色彩空间；为避免误读，已停止处理。");
      }
      if (colorSpace !== "RGB") {
        throw new Error(`当前图层是 ${imageData.colorSpace} 色彩空间；当前版本仅支持 RGB 图层。`);
      }
      if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1) {
        throw new Error("Photoshop 返回了无效的图层像素尺寸。");
      }
      if (!Number.isSafeInteger(width * height) || width * height > MAX_LOCAL_PIXELS) {
        throw new Error("当前图层超过 16,777,216 像素的本地处理上限，请先缩小图层或分区处理。");
      }
      if (components !== 3 && components !== 4) {
        throw new Error("Photoshop 图层像素必须是 RGB 或 RGBA 数据。");
      }
      const componentCount = width * height * components;
      const sourceByteLength = componentCount * (pixelDepth / 8);
      if (!Number.isSafeInteger(sourceByteLength) || sourceByteLength > MAX_LOCAL_SOURCE_BYTES) {
        throw new Error("当前图层原生像素数据超过 64 MiB 的本地内存处理上限，请先缩小图层或分区处理。");
      }
      let data;
      try {
        data = await imageData.getData({ chunky: true });
      } catch (error) {
        throw stageHostError("复制 Photoshop 图层像素数据", error);
      }
      const copy = normalizePixelDataTo8Bit(
        data,
        pixelDepth,
        componentCount,
        `Photoshop ${pixelDepth}-bit 图层像素缓冲格式或长度不正确。`
      );
      if (!result.sourceBounds) {
        throw new Error("Photoshop 未返回图层像素来源边界；为避免错位，已停止处理。");
      }
      const bounds = toBounds(result.sourceBounds);
      const sourceRegionChanged = ["left", "top", "right", "bottom"]
        .some((key) => bounds[key] !== normalized.bounds[key]);
      if (bounds.width !== width || bounds.height !== height || sourceRegionChanged) {
        throw new Error("Photoshop 图层像素尺寸与来源边界不一致。");
      }
      return {
        pixels: copy,
        width,
        height,
        components,
        bounds
      };
    } finally {
      if (typeof imageData.dispose === "function") imageData.dispose();
    }
  }

  // Keep the original method name as a committed-write API while routing it
  // through the validated writer used by temporary previews.
  async function putLayerMask(layerInfo, alpha) {
    const normalized = normalizedLayerInfo(layerInfo);
    const copy = await writeLayerMask(normalized, alpha);
    const key = layerKey(normalized);
    maskSnapshots.delete(key);
    if (activePreviewKey === key) {
      activePreviewKey = null;
      activePreviewLayerInfo = null;
    }
    return copy;
  }

  async function previewLayerMask(layerInfo, alpha) {
    const normalized = normalizedLayerInfo(layerInfo);
    const copy = copyAlpha(alpha, normalized);
    const key = layerKey(normalized);
    let snapshot = maskSnapshots.get(key);
    let createdSnapshot = false;
    if (!snapshot) {
      try {
        snapshot = await readLayerMask(normalized);
      } catch (error) {
        // Some Photoshop builds return an empty, message-less rejection for
        // getLayerMask when a layer has no user mask. If batchPlay can remove
        // a mask, treat that result as an absent original and continue with a
        // reversible preview instead of reporting a generic host failure.
        if (!isMessageLessMaskError(error) || !canRemoveLayerMask(normalized)) throw error;
        snapshot = emptyMaskSnapshot(normalized);
      }
      snapshot = maskSnapshotCopy(snapshot);
      maskSnapshots.set(key, snapshot);
      createdSnapshot = true;
    }
    // A layer without a mask needs a reversible remove operation after the
    // preview creates one. Refuse to write if no such operation was injected.
    if (!snapshot.present && !canRemoveLayerMask(normalized)) {
      if (createdSnapshot) maskSnapshots.delete(key);
      throw new Error("无法安全预览无原始图层蒙版的图层，请注入 action.batchPlay。");
    }

    try {
      await writeLayerMask(normalized, copy);
    } catch (error) {
      const failure = error instanceof Error && String(error.message || "").trim()
        ? error
        : stageHostError("预览图层蒙版", error);
      if (failure.rollbackCompleted !== true) {
        try {
          await restoreLayerMask(normalized, snapshot);
          failure.rollbackCompleted = true;
        } catch (restoreError) {
          failure.restoreError = restoreError instanceof Error
            ? restoreError
            : stageHostError("恢复原图层蒙版", restoreError);
        }
      }
      if (createdSnapshot) maskSnapshots.delete(key);
      throw failure;
    }
    activePreviewKey = key;
    activePreviewLayerInfo = normalized;
    return {
      previewing: true,
      documentID: normalized.documentID,
      layerID: normalized.layerID,
      width: normalized.bounds.width,
      height: normalized.bounds.height,
      bounds: { ...normalized.bounds },
      alpha: new Uint8Array(copy),
      original: maskSnapshotCopy(snapshot)
    };
  }

  async function cancelMaskPreview(layerInfo) {
    const normalized = normalizedLayerInfo(layerInfo || activePreviewLayerInfo);
    const key = layerKey(normalized);
    const snapshot = maskSnapshots.get(key);
    if (!snapshot) {
      if (activePreviewKey === key) {
        activePreviewKey = null;
        activePreviewLayerInfo = null;
      }
      return {
        restored: false,
        previewing: false,
        documentID: normalized.documentID,
        layerID: normalized.layerID
      };
    }
    await restoreLayerMask(normalized, snapshot);
    maskSnapshots.delete(key);
    if (activePreviewKey === key) {
      activePreviewKey = null;
      activePreviewLayerInfo = null;
    }
    return { restored: true, previewing: false, original: maskSnapshotCopy(snapshot) };
  }

  async function restoreLayerMaskSnapshot(layerInfo, snapshot) {
    const normalized = normalizedLayerInfo(layerInfo);
    await restoreLayerMask(normalized, snapshot);
    const key = layerKey(normalized);
    maskSnapshots.delete(key);
    if (activePreviewKey === key) {
      activePreviewKey = null;
      activePreviewLayerInfo = null;
    }
    return { restored: true, original: maskSnapshotCopy(snapshot) };
  }

  async function applyLayerMask(layerInfo, alpha) {
    const normalized = normalizedLayerInfo(layerInfo);
    const key = layerKey(normalized);
    let snapshot = maskSnapshots.get(key);
    if (!snapshot) snapshot = await saveLayerMask(normalized);
    let copy;
    try {
      copy = await writeLayerMask(normalized, alpha);
    } catch (error) {
      const failure = error instanceof Error && String(error.message || "").trim()
        ? error
        : stageHostError("应用图层蒙版", error);
      if (failure.rollbackCompleted === true) {
        maskSnapshots.delete(key);
        throw failure;
      }
      try {
        await restoreLayerMask(normalized, snapshot);
        maskSnapshots.delete(key);
        failure.rollbackCompleted = true;
      } catch (restoreError) {
        failure.rollbackCompleted = false;
        failure.restoreError = restoreError instanceof Error
          ? restoreError
          : stageHostError("恢复原图层蒙版", restoreError);
      }
      throw failure;
    }
    maskSnapshots.delete(key);
    if (activePreviewKey === key) {
      activePreviewKey = null;
      activePreviewLayerInfo = null;
    }
    return {
      applied: true,
      documentID: normalized.documentID,
      layerID: normalized.layerID,
      width: normalized.bounds.width,
      height: normalized.bounds.height,
      bounds: { ...normalized.bounds },
      alpha: new Uint8Array(copy)
    };
  }

  function getForegroundResultCapability() {
    const document = app && app.activeDocument;
    const majorVersion = photoshopMajorVersion(hostVersion, app, photoshop);
    let reason = null;
    if (!document) reason = "No active Photoshop document is available.";
    else if (majorVersion === null || majorVersion < 25) {
      reason = "Foreground pixel-layer output requires Photoshop 25 or newer.";
    } else if (typeof document.createLayer !== "function") {
      reason = "Photoshop document.createLayer is unavailable; cannot create a pixel layer safely.";
    } else if (!imaging || typeof imaging.createImageDataFromBuffer !== "function") {
      reason = "Photoshop imaging.createImageDataFromBuffer is unavailable.";
    } else if (typeof imaging.putPixels !== "function") {
      reason = "Photoshop imaging.putPixels is unavailable.";
    } else if (typeof imaging.putLayerMask !== "function") {
      reason = "Photoshop imaging.putLayerMask is unavailable.";
    } else if (!play) {
      reason = "Photoshop action.batchPlay is unavailable; a failed new-layer write cannot be rolled back safely.";
    } else if (!core || typeof core.executeAsModal !== "function") {
      reason = "Photoshop executeAsModal is unavailable.";
    }
    return {
      supported: reason === null,
      reason,
      hostVerification: "mock-only"
    };
  }

  function normalizeForegroundResult(layerInfo, result) {
    const normalized = normalizedLayerInfo(layerInfo);
    if (!result || typeof result !== "object") {
      throw new TypeError("Foreground result is required.");
    }
    const width = Number(result.width);
    const height = Number(result.height);
    if (!Number.isInteger(width) || !Number.isInteger(height)
      || width !== normalized.bounds.width || height !== normalized.bounds.height) {
      throw new Error("Foreground result dimensions must match the source layer bounds.");
    }
    const foreground = copy8BitData(
      result.foreground,
      width * height * 3,
      "Foreground RGB buffer length must equal width * height * 3."
    );
    const alpha = copyAlpha(result.alpha, normalized);
    const requestedName = String(result.name || "").trim();
    return {
      normalized,
      foreground,
      alpha,
      width,
      height,
      name: requestedName || `${normalized.name || "Subject"} - Foreground`,
      preserveSelection: result.preserveSelection === true
    };
  }

  function setLayerVisibility(layer, visible, stage) {
    if (!layer || typeof layer.visible !== "boolean") {
      throw new Error(`${stage} failed: Photoshop did not expose a readable layer visibility state.`);
    }
    try {
      layer.visible = visible;
    } catch (error) {
      throw stageHostError(stage, error);
    }
    if (layer.visible !== visible) {
      throw new Error(`${stage} failed: Photoshop did not apply the requested layer visibility state.`);
    }
  }

  async function applyForegroundResult(layerInfo, result) {
    const prepared = normalizeForegroundResult(layerInfo, result);
    const selectedLayer = assertLayerIsSelected(prepared.normalized);
    const pixelBlockReason = unsupportedPixelLayerReason(selectedLayer || layerReference(prepared.normalized));
    if (pixelBlockReason) throw new Error(pixelBlockReason);
    const capability = getForegroundResultCapability();
    if (!capability.supported) {
      const failure = new Error(capability.reason);
      failure.diagnostics = { hostVerification: "mock-only" };
      throw failure;
    }

    const document = app.activeDocument;
    const originalLayerIDs = currentSelectedLayerIDs();
    return executeModal(async (executionContext) => {
      const hostControl = executionContext && executionContext.hostControl;
      if (!hostControl
        || typeof hostControl.suspendHistory !== "function"
        || typeof hostControl.resumeHistory !== "function") {
        const failure = new Error(
          "Photoshop history control is unavailable; foreground output was not started."
        );
        failure.diagnostics = { hostVerification: "mock-only" };
        throw failure;
      }

      let suspension = null;
      let createdLayer = null;
      let foregroundData = null;
      let maskData = null;
      let historyClosed = false;
      let sourceLayer = null;
      let sourceWasVisible = null;
      let sourceVisibilityCaptured = false;
      try {
        suspension = await hostControl.suspendHistory({
          documentID: prepared.normalized.documentID,
          name: "Apply offline cutout foreground"
        });
        assertDocumentIsActive(prepared.normalized);
        sourceLayer = assertLayerCanAcceptMask(prepared.normalized);
        if (!sourceLayer || typeof sourceLayer.visible !== "boolean") {
          throw new Error(
            "Photoshop did not expose the source layer visibility state; foreground output was not started."
          );
        }
        sourceWasVisible = sourceLayer.visible;
        sourceVisibilityCaptured = true;
        createdLayer = await document.createLayer({ name: prepared.name });
        if (!createdLayer || !Number.isFinite(Number(createdLayer.id))) {
          throw new Error("Photoshop did not return a valid new pixel layer.");
        }

        foregroundData = await imaging.createImageDataFromBuffer(prepared.foreground, {
          width: prepared.width,
          height: prepared.height,
          components: 3,
          chunky: true,
          colorProfile: "sRGB IEC61966-2.1",
          colorSpace: "RGB"
        });
        try {
          await imaging.putPixels({
            documentID: prepared.normalized.documentID,
            layerID: Number(createdLayer.id),
            imageData: foregroundData,
            replace: true,
            targetBounds: {
              left: prepared.normalized.bounds.left,
              top: prepared.normalized.bounds.top
            },
            commandName: "Write offline cutout foreground"
          });
        } catch (error) {
          throw stageHostError("Foreground pixel write", error);
        }

        maskData = await imaging.createImageDataFromBuffer(prepared.alpha, {
          width: prepared.width,
          height: prepared.height,
          components: 1,
          chunky: false,
          colorProfile: "Gray Gamma 2.2",
          colorSpace: "Grayscale"
        });
        try {
          await imaging.putLayerMask({
            documentID: prepared.normalized.documentID,
            layerID: Number(createdLayer.id),
            kind: "user",
            imageData: maskData,
            replace: true,
            targetBounds: {
              left: prepared.normalized.bounds.left,
              top: prepared.normalized.bounds.top
            },
            commandName: "Write offline cutout alpha mask"
          });
        } catch (error) {
          throw stageHostError("Foreground mask write", error);
        }

        if (sourceWasVisible) setLayerVisibility(sourceLayer, false, "Hide source layer");
        if (prepared.preserveSelection && originalLayerIDs.length > 0) {
          await selectLayers(originalLayerIDs, "Restore batch layer selection");
        }

        await hostControl.resumeHistory(suspension, true);
        historyClosed = true;
        return {
          applied: true,
          documentID: prepared.normalized.documentID,
          sourceLayerID: prepared.normalized.layerID,
          layerID: Number(createdLayer.id),
          width: prepared.width,
          height: prepared.height,
          bounds: { ...prepared.normalized.bounds },
          diagnostics: {
            output: "new-pixel-layer-with-mask",
            sourcePreserved: true,
            sourceWasVisible,
            hostVerification: "mock-only"
          }
        };
      } catch (error) {
        const failure = error instanceof Error && String(error.message || "").trim()
          ? error
          : stageHostError("Apply foreground result", error);
        let layerDeleted = createdLayer === null;
        let historyRolledBack = suspension === null;
        let visibilityRestored = !sourceVisibilityCaptured;
        let rollbackError = null;

        if (sourceVisibilityCaptured) {
          try {
            if (sourceLayer.visible !== sourceWasVisible) {
              setLayerVisibility(sourceLayer, sourceWasVisible, "Restore source layer visibility");
            }
            visibilityRestored = sourceLayer.visible === sourceWasVisible;
          } catch (visibilityError) {
            rollbackError = visibilityError;
          }
        }
        if (createdLayer && Number.isFinite(Number(createdLayer.id))) {
          try {
            await playActions([deleteLayerDescriptor(Number(createdLayer.id))], "Delete failed foreground layer");
            layerDeleted = true;
          } catch (deleteError) {
            rollbackError = deleteError;
          }
        }
        if (suspension !== null && !historyClosed) {
          try {
            await hostControl.resumeHistory(suspension, false);
            historyRolledBack = true;
          } catch (historyError) {
            rollbackError = rollbackError || historyError;
          }
        }
        if (originalLayerIDs.length > 0 && historyRolledBack) {
          try {
            await selectLayers(originalLayerIDs, "Restore source layer selection");
          } catch (selectionError) {
            rollbackError = rollbackError || selectionError;
          }
        }
        failure.rollbackCompleted = layerDeleted && historyRolledBack && visibilityRestored && !rollbackError;
        failure.diagnostics = {
          hostVerification: "mock-only",
          sourcePreserved: failure.rollbackCompleted
        };
        if (rollbackError) failure.restoreError = rollbackError;
        throw failure;
      } finally {
        disposeImageData(maskData);
        disposeImageData(foregroundData);
      }
    }, "Apply offline cutout foreground");
  }

  return {
    getActivePixelLayer,
    getSelectedPixelLayers,
    readLayerPixels,
    putLayerMask,
    readLayerMask,
    saveLayerMask,
    previewLayerMask,
    cancelMaskPreview,
    restoreLayerMaskSnapshot,
    applyLayerMask,
    getForegroundResultCapability,
    applyForegroundResult,
    readUserMask: readLayerMask,
    saveOriginalLayerMask: saveLayerMask,
    previewAlpha: previewLayerMask,
    cancelPreview: cancelMaskPreview,
    applyMask: applyLayerMask
  };
}

module.exports = {
  MAX_LOCAL_PIXELS,
  createPhotoshopHost,
  formatHostError,
  photoshopMajorVersion,
  toBounds
};
