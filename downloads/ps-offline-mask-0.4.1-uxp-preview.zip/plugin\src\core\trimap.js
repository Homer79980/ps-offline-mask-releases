const LABELS = Object.freeze({
  UNKNOWN: 0,
  KEEP: 1,
  CUT: 2
});

function assertSize(width, height) {
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1) {
    throw new RangeError("Trimap dimensions must be positive integers");
  }
}

function clampSoftness(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return 0;
  return Math.min(1, Math.max(0, numeric));
}

class TrimapRaster {
  constructor(width, height, data) {
    assertSize(width, height);
    this.width = width;
    this.height = height;
    this.data = data ? new Uint8Array(data) : new Uint8Array(width * height);
    this.painted = new Uint8Array(width * height);
    if (this.data.length !== width * height) {
      throw new RangeError("Trimap data length does not match dimensions");
    }
  }

  clear(label = LABELS.UNKNOWN) {
    this.data.fill(label);
    this.painted.fill(0);
    return this;
  }

  paintSolidCircle(x, y, radius, label) {
    const safeRadius = Math.max(0, Number(radius) || 0);
    const centerX = Number(x) || 0;
    const centerY = Number(y) || 0;
    const left = Math.max(0, Math.floor(centerX - safeRadius));
    const right = Math.min(this.width - 1, Math.ceil(centerX + safeRadius));
    const top = Math.max(0, Math.floor(centerY - safeRadius));
    const bottom = Math.min(this.height - 1, Math.ceil(centerY + safeRadius));
    const radiusSquared = safeRadius * safeRadius;

    for (let py = top; py <= bottom; py += 1) {
      for (let px = left; px <= right; px += 1) {
        const dx = px - centerX;
        const dy = py - centerY;
        if (dx * dx + dy * dy <= radiusSquared) {
          const index = py * this.width + px;
          this.data[index] = label;
          this.painted[index] = 1;
        }
      }
    }
    return this;
  }

  paintSolidLine(x0, y0, x1, y1, radius, label) {
    const dx = x1 - x0;
    const dy = y1 - y0;
    const steps = Math.max(1, Math.ceil(Math.sqrt(dx * dx + dy * dy) / Math.max(1, radius * 0.6)));
    for (let step = 0; step <= steps; step += 1) {
      const progress = step / steps;
      this.paintSolidCircle(x0 + dx * progress, y0 + dy * progress, radius, label);
    }
    return this;
  }

  paintCircle(x, y, radius, label, softness = 0) {
    const safeSoftness = clampSoftness(softness);
    if (label === LABELS.UNKNOWN || safeSoftness === 0) {
      return this.paintSolidCircle(x, y, radius, label);
    }
    const safeRadius = Math.max(0, Number(radius) || 0);
    const coreRadius = Math.max(0.75, safeRadius * (1 - safeSoftness));
    this.paintSolidCircle(x, y, safeRadius, LABELS.UNKNOWN);
    return this.paintSolidCircle(x, y, coreRadius, label);
  }

  paintLine(x0, y0, x1, y1, radius, label, softness = 0) {
    const safeSoftness = clampSoftness(softness);
    if (label === LABELS.UNKNOWN || safeSoftness === 0) {
      return this.paintSolidLine(x0, y0, x1, y1, radius, label);
    }
    const safeRadius = Math.max(0, Number(radius) || 0);
    const coreRadius = Math.max(0.75, safeRadius * (1 - safeSoftness));
    this.paintSolidLine(x0, y0, x1, y1, safeRadius, LABELS.UNKNOWN);
    return this.paintSolidLine(x0, y0, x1, y1, coreRadius, label);
  }

  count(label) {
    let result = 0;
    for (const value of this.data) {
      if (value === label) result += 1;
    }
    return result;
  }
}

module.exports = { LABELS, TrimapRaster, clampSoftness };
