function normalizeWheelDirection(event) {
  const deltaY = Number(event && event.deltaY);
  if (Number.isFinite(deltaY) && deltaY !== 0) return deltaY < 0 ? -1 : 1;
  const wheelDelta = Number(event && event.wheelDelta);
  if (Number.isFinite(wheelDelta) && wheelDelta !== 0) return wheelDelta > 0 ? -1 : 1;
  const detail = Number(event && event.detail);
  if (Number.isFinite(detail) && detail !== 0) return detail < 0 ? -1 : 1;
  return 0;
}

function hasNoPressedButtons(event) {
  return Boolean(event && event.buttons !== undefined && Number(event.buttons) === 0);
}

function createWheelInputRouter({ onWheel, isActive = () => true, now = Date.now, dedupeMs = 24 } = {}) {
  let lastEvent = null;
  let lastType = null;
  let lastDirection = 0;
  let lastTime = -Infinity;

  function handle(event) {
    if (!event || !isActive()) return false;
    const direction = normalizeWheelDirection(event);
    if (direction === 0) return false;
    if (event === lastEvent) return false;
    const time = Number(now());
    const type = String(event.type || "unknown");
    const pairedDuplicate = type !== lastType && direction === lastDirection && time - lastTime < dedupeMs;
    if (pairedDuplicate) {
      if (typeof event.preventDefault === "function") event.preventDefault();
      lastEvent = event;
      return false;
    }
    lastEvent = event;
    lastType = type;
    lastDirection = direction;
    lastTime = time;
    if (typeof onWheel === "function") onWheel(event);
    return true;
  }

  return Object.freeze({
    handleDocument: handle,
    handleSurface: handle
  });
}

module.exports = { createWheelInputRouter, hasNoPressedButtons, normalizeWheelDirection };
