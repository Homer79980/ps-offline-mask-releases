const { runStepsAsync } = require("./stepRunner");

const BACKGROUND_ALPHA_MAX = 8;
const LOW_ALPHA_MAX = 1;
const MIN_REFERENCE_ALPHA = 64;
const MAX_REFERENCE_DISTANCE = 16;
const NO_REFERENCE = 255;

function assertByteColor(color, name = "background color") {
  if (!Array.isArray(color) || color.length !== 3
    || !color.every((value) => Number.isInteger(value) && value >= 0 && value <= 255)) {
    throw new TypeError(`${name} must contain three bytes`);
  }
  return color.slice();
}

function validateInput({ pixels, width, height, components, alpha }) {
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1) {
    throw new TypeError("Foreground dimensions must be positive integers");
  }
  if (components !== 3 && components !== 4) {
    throw new TypeError("Foreground input must be RGB or RGBA");
  }
  const pixelCount = width * height;
  if (!Number.isSafeInteger(pixelCount)) throw new RangeError("Foreground dimensions are too large");
  if (!(pixels instanceof Uint8Array) || pixels.length !== pixelCount * components) {
    throw new TypeError("Foreground pixel buffer dimensions do not match the image");
  }
  if (!(alpha instanceof Uint8Array) || alpha.length !== pixelCount) {
    throw new TypeError("Foreground alpha dimensions do not match the image");
  }
  return pixelCount;
}

function histogramMedian(histogram, count) {
  const midpoint = Math.floor((count - 1) / 2);
  let accumulated = 0;
  for (let value = 0; value < histogram.length; value += 1) {
    accumulated += histogram[value];
    if (accumulated > midpoint) return value;
  }
  return 0;
}

function estimateSolidBackground(request) {
  const pixelCount = validateInput(request);
  const { pixels, components, alpha } = request;
  const histograms = [new Uint32Array(256), new Uint32Array(256), new Uint32Array(256)];
  let samples = 0;
  for (let index = 0; index < pixelCount; index += 1) {
    if (alpha[index] > BACKGROUND_ALPHA_MAX) continue;
    const offset = index * components;
    histograms[0][pixels[offset]] += 1;
    histograms[1][pixels[offset + 1]] += 1;
    histograms[2][pixels[offset + 2]] += 1;
    samples += 1;
  }
  if (samples === 0) {
    const error = new Error("No reliable background samples are available for RGB correction");
    error.code = "foreground-background-unavailable";
    throw error;
  }
  return histograms.map((histogram) => histogramMedian(histogram, samples));
}

function resolveBackground(request) {
  const configured = request.background && request.background.color;
  return configured === undefined
    ? estimateSolidBackground(request)
    : assertByteColor(configured);
}

function colorDistanceSquared(pixels, offset, background) {
  const red = pixels[offset] - background[0];
  const green = pixels[offset + 1] - background[1];
  const blue = pixels[offset + 2] - background[2];
  return red * red + green * green + blue * blue;
}

function copyReference(foreground, distances, target, source, distance) {
  if (distance > MAX_REFERENCE_DISTANCE || distance >= distances[target]) return;
  const sourceOffset = source * 3;
  const targetOffset = target * 3;
  foreground[targetOffset] = foreground[sourceOffset];
  foreground[targetOffset + 1] = foreground[sourceOffset + 1];
  foreground[targetOffset + 2] = foreground[sourceOffset + 2];
  distances[target] = distance;
}

function* decontaminateSteps(request, background) {
  const pixelCount = validateInput(request);
  const { pixels, width, height, components, alpha } = request;
  const foreground = new Uint8Array(pixelCount * 3);
  const referenceDistances = new Uint8Array(pixelCount);
  referenceDistances.fill(NO_REFERENCE);
  const backgroundSpread = Number(request.background && request.background.spread) || 0;
  const minimumSignal = Math.max(40, Math.min(96, backgroundSpread * 4 + 24));
  const minimumSignalSquared = minimumSignal * minimumSignal;
  let clampedChannels = 0;
  const chunkPixels = 0x4000;
  for (let start = 0; start < pixelCount; start += chunkPixels) {
    const end = Math.min(pixelCount, start + chunkPixels);
    for (let index = start; index < end; index += 1) {
      const sourceOffset = index * components;
      const targetOffset = index * 3;
      const alphaByte = alpha[index];
      if (alphaByte <= LOW_ALPHA_MAX || alphaByte === 255) {
        foreground[targetOffset] = pixels[sourceOffset];
        foreground[targetOffset + 1] = pixels[sourceOffset + 1];
        foreground[targetOffset + 2] = pixels[sourceOffset + 2];
      } else {
        const opacity = alphaByte / 255;
        for (let component = 0; component < 3; component += 1) {
          const estimated = (pixels[sourceOffset + component]
            - (1 - opacity) * background[component]) / opacity;
          const bounded = Math.max(0, Math.min(255, estimated));
          if (bounded !== estimated) clampedChannels += 1;
          foreground[targetOffset + component] = Math.round(bounded);
        }
      }
      if (alphaByte >= MIN_REFERENCE_ALPHA
        && colorDistanceSquared(foreground, targetOffset, background) >= minimumSignalSquared) {
        referenceDistances[index] = 0;
      }
    }
    yield { completed: end, total: pixelCount, phase: "foreground" };
  }

  let completed = 0;
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const index = y * width + x;
      if (alpha[index] > LOW_ALPHA_MAX
        && alpha[index] < MIN_REFERENCE_ALPHA
        && referenceDistances[index] !== 0) {
        if (x > 0 && referenceDistances[index - 1] !== NO_REFERENCE) {
          copyReference(foreground, referenceDistances, index, index - 1, referenceDistances[index - 1] + 1);
        }
        if (y > 0 && referenceDistances[index - width] !== NO_REFERENCE) {
          copyReference(foreground, referenceDistances, index, index - width, referenceDistances[index - width] + 1);
        }
      }
      completed += 1;
      if (completed % chunkPixels === 0) {
        yield { completed, total: pixelCount * 2, phase: "foreground-reference" };
      }
    }
  }

  for (let y = height - 1; y >= 0; y -= 1) {
    for (let x = width - 1; x >= 0; x -= 1) {
      const index = y * width + x;
      if (alpha[index] > LOW_ALPHA_MAX
        && alpha[index] < MIN_REFERENCE_ALPHA
        && referenceDistances[index] !== 0) {
        if (x + 1 < width && referenceDistances[index + 1] !== NO_REFERENCE) {
          copyReference(foreground, referenceDistances, index, index + 1, referenceDistances[index + 1] + 1);
        }
        if (y + 1 < height && referenceDistances[index + width] !== NO_REFERENCE) {
          copyReference(foreground, referenceDistances, index, index + width, referenceDistances[index + width] + 1);
        }
      }
      completed += 1;
      if (completed % chunkPixels === 0) {
        yield { completed, total: pixelCount * 2, phase: "foreground-reference" };
      }
    }
  }

  let extendedPixels = 0;
  let unresolvedPixels = 0;
  for (let index = 0; index < pixelCount; index += 1) {
    if (referenceDistances[index] > 0 && referenceDistances[index] <= MAX_REFERENCE_DISTANCE) {
      extendedPixels += 1;
    } else if (alpha[index] > LOW_ALPHA_MAX
      && alpha[index] < MIN_REFERENCE_ALPHA
      && referenceDistances[index] === NO_REFERENCE) {
      unresolvedPixels += 1;
    }
    if ((index + 1) % chunkPixels === 0) {
      yield { completed: index + 1, total: pixelCount, phase: "foreground-diagnostics" };
    }
  }
  return {
    foreground,
    diagnostics: {
      background: background.slice(),
      fringeMode: "foreground-corrected",
      clampedChannels,
      extendedPixels,
      unresolvedPixels
    }
  };
}

function runSteps(iterator) {
  let next = iterator.next();
  while (!next.done) next = iterator.next();
  return next.value;
}

function decontaminateForeground(request = {}) {
  const background = resolveBackground(request);
  return runSteps(decontaminateSteps(request, background));
}

async function decontaminateForegroundAsync(request = {}) {
  const background = resolveBackground(request);
  return runStepsAsync(decontaminateSteps(request, background), request.signal, request.onProgress);
}

module.exports = {
  BACKGROUND_ALPHA_MAX,
  decontaminateForeground,
  decontaminateForegroundAsync,
  estimateSolidBackground
};
