function cloneSnapshot(value) {
  if (value instanceof Uint8Array) return new Uint8Array(value);
  if (value && value.data instanceof Uint8Array
    && Number.isInteger(value.width) && Number.isInteger(value.height)) {
    const copy = new value.constructor(value.width, value.height, value.data);
    if (copy.painted instanceof Uint8Array && value.painted instanceof Uint8Array) {
      copy.painted.set(value.painted);
    }
    return copy;
  }
  throw new TypeError("Trimap history requires a Uint8Array or Trimap raster");
}

function createTrimapHistory(initial, options = {}) {
  const clone = typeof options.clone === "function" ? options.clone : cloneSnapshot;
  const requestedLimit = Math.max(1, Math.floor(Number(options.limit) || 50));
  const snapshotBytes = initial instanceof Uint8Array
    ? initial.byteLength
    : Number(initial && initial.data && initial.data.byteLength || 0)
      + Number(initial && initial.painted && initial.painted.byteLength || 0);
  const maxBytes = Math.max(snapshotBytes * 2, Math.floor(Number(options.maxBytes) || 64 * 1024 * 1024));
  const memoryLimit = snapshotBytes > 0 ? Math.max(1, Math.floor(maxBytes / snapshotBytes) - 1) : requestedLimit;
  const limit = Math.min(requestedLimit, memoryLimit);
  const origin = clone(initial);
  let entries = [clone(origin)];
  let cursor = 0;
  let settledCursor = 0;

  function currentSnapshot() {
    return entries[cursor];
  }

  function beginStroke() {
    return clone(currentSnapshot());
  }

  function commitStroke(next) {
    entries = entries.slice(0, cursor + 1);
    if (settledCursor >= entries.length) settledCursor = -1;
    entries.push(clone(next));
    if (entries.length > limit + 1) {
      entries.shift();
      if (settledCursor >= 0) settledCursor -= 1;
    }
    cursor = entries.length - 1;
    return clone(currentSnapshot());
  }

  function undo() {
    if (cursor === 0) return null;
    cursor -= 1;
    return clone(currentSnapshot());
  }

  function redo() {
    if (cursor >= entries.length - 1) return null;
    cursor += 1;
    return clone(currentSnapshot());
  }

  function clearPending() {
    settledCursor = cursor;
    return clone(currentSnapshot());
  }

  function reset(next = origin) {
    entries = [clone(next)];
    cursor = 0;
    settledCursor = 0;
    return clone(currentSnapshot());
  }

  return Object.freeze({
    beginStroke,
    clearPending,
    commitStroke,
    reset,
    undo,
    redo,
    get canUndo() { return cursor > 0; },
    get canRedo() { return cursor < entries.length - 1; },
    get capacity() { return limit; },
    get current() { return clone(currentSnapshot()); },
    get pendingCount() {
      return settledCursor >= 0 ? Math.abs(cursor - settledCursor) : cursor + 1;
    }
  });
}

module.exports = { createTrimapHistory };
