const { runStepsAsync, runStepsSync } = require("./stepRunner");
const { LABELS, TrimapRaster } = require("./trimap");

const YIELD_INTERVAL = 4096;

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function median(values) {
  const sorted = values.slice().sort((left, right) => left - right);
  if (sorted.length === 0) return 0;
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0 ? (sorted[middle - 1] + sorted[middle]) / 2 : sorted[middle];
}

function borderIndices(width, height) {
  const indices = [];
  const step = Math.max(1, Math.floor(Math.max(width, height) / 64));
  for (let x = 0; x < width; x += step) indices.push(x, (height - 1) * width + x);
  for (let y = 0; y < height; y += step) indices.push(y * width, y * width + width - 1);
  return indices;
}

function colorDistance(pixels, components, index, background) {
  const offset = index * components;
  const dr = (pixels[offset] || 0) - background[0];
  const dg = (pixels[offset + 1] || 0) - background[1];
  const db = (pixels[offset + 2] || 0) - background[2];
  return Math.sqrt(dr * dr + dg * dg + db * db);
}

function colorChroma(pixels, components, index) {
  const offset = index * components;
  const red = pixels[offset] || 0;
  const green = pixels[offset + 1] || 0;
  const blue = pixels[offset + 2] || 0;
  return Math.max(red, green, blue) - Math.min(red, green, blue);
}

function colorDirectionSimilarity(pixels, components, index, background) {
  const offset = index * components;
  const red = pixels[offset] || 0;
  const green = pixels[offset + 1] || 0;
  const blue = pixels[offset + 2] || 0;
  const pixelLength = Math.sqrt(red * red + green * green + blue * blue);
  const backgroundLength = Math.sqrt(
    background[0] * background[0]
      + background[1] * background[1]
      + background[2] * background[2]
  );
  if (pixelLength < 1 || backgroundLength < 1) return 0;
  return (red * background[0] + green * background[1] + blue * background[2])
    / (pixelLength * backgroundLength);
}

function isSaturatedBackgroundShade(pixels, components, index, background) {
  const backgroundChroma = Math.max(...background) - Math.min(...background);
  if (backgroundChroma < 32) return false;

  const offset = index * components;
  const red = pixels[offset] || 0;
  const green = pixels[offset + 1] || 0;
  const blue = pixels[offset + 2] || 0;
  const pixelChroma = Math.max(red, green, blue) - Math.min(red, green, blue);
  if (pixelChroma < Math.max(8, backgroundChroma * 0.08)) return false;

  const backgroundLengthSquared = background[0] * background[0]
    + background[1] * background[1]
    + background[2] * background[2];
  if (backgroundLengthSquared < 1) return false;
  const scale = (red * background[0] + green * background[1] + blue * background[2])
    / backgroundLengthSquared;
  return scale >= 0.05
    && scale <= 1.05
    && colorDirectionSimilarity(pixels, components, index, background) >= 0.97;
}

function hasCutNeighbor(cut, width, height, index) {
  const x = index % width;
  const y = Math.floor(index / width);
  for (let offsetY = -1; offsetY <= 1; offsetY += 1) {
    const nextY = y + offsetY;
    if (nextY < 0 || nextY >= height) continue;
    for (let offsetX = -1; offsetX <= 1; offsetX += 1) {
      const nextX = x + offsetX;
      if (nextX < 0 || nextX >= width || (offsetX === 0 && offsetY === 0)) continue;
      if (cut[nextY * width + nextX]) return true;
    }
  }
  return false;
}

function distancePercentileAbove(distances, minimum, percentile) {
  const histogram = new Uint32Array(443);
  let count = 0;
  for (const distance of distances) {
    if (distance <= minimum) continue;
    histogram[Math.min(histogram.length - 1, Math.round(distance))] += 1;
    count += 1;
  }
  if (count === 0) return 0;
  const target = Math.max(1, Math.ceil(count * percentile));
  let cumulative = 0;
  for (let bin = 0; bin < histogram.length; bin += 1) {
    cumulative += histogram[bin];
    if (cumulative >= target) return bin;
  }
  return histogram.length - 1;
}

function alphaAt(pixels, components, index) {
  return components >= 4 ? pixels[index * components + 3] : 255;
}

function mark(trimap, index, label) {
  trimap.data[index] = label;
  trimap.painted[index] = 1;
}

function* backgroundRegionsSteps(width, height, distances, threshold) {
  const size = width * height;
  // Tiny enclosed regions that match the border are often subject details
  // (eyes, gems, UI marks), not true background holes. Require a meaningful
  // image-relative area before automatically cutting an interior region.
  // Ignore only isolated exact-background specks. This is deliberately much
  // smaller than the protected-detail threshold below so real holes remain cut.
  const minimumHoleArea = Math.max(17, Math.round(size * 0.00005));
  const visited = new Uint8Array(size);
  const cut = new Uint8Array(size);
  const borderCut = new Uint8Array(size);
  const preservedInterior = new Uint8Array(size);
  const queue = new Int32Array(size);
  const holeAreas = [];
  const preservedInteriorAreas = [];
  const progressTotal = size * 3;
  let completed = 0;

  for (let seed = 0; seed < size; seed += 1) {
    completed += 1;
    if (completed % YIELD_INTERVAL === 0) {
      yield { phase: "auto-regions", completed, total: progressTotal };
    }
    if (visited[seed] || distances[seed] > threshold) continue;

    let head = 0;
    let tail = 0;
    let touchesBorder = false;
    const enqueue = (nextIndex) => {
      if (visited[nextIndex] || distances[nextIndex] > threshold) return;
      visited[nextIndex] = 1;
      queue[tail] = nextIndex;
      tail += 1;
    };
    enqueue(seed);

    while (head < tail) {
      const index = queue[head];
      head += 1;
      const x = index % width;
      const y = Math.floor(index / width);
      if (x === 0 || y === 0 || x === width - 1 || y === height - 1) touchesBorder = true;

      if (x > 0) enqueue(index - 1);
      if (x + 1 < width) enqueue(index + 1);
      if (y > 0) enqueue(index - width);
      if (y + 1 < height) enqueue(index + width);
      completed += 1;
      if (completed % YIELD_INTERVAL === 0) {
        yield { phase: "auto-regions", completed, total: progressTotal };
      }
    }

    const acceptedHole = !touchesBorder && tail >= minimumHoleArea;
    if (touchesBorder || acceptedHole) {
      for (let index = 0; index < tail; index += 1) {
        const regionIndex = queue[index];
        cut[regionIndex] = 1;
        if (touchesBorder) borderCut[regionIndex] = 1;
        completed += 1;
        if (completed % YIELD_INTERVAL === 0) {
          yield { phase: "auto-regions", completed, total: progressTotal };
        }
      }
      if (acceptedHole) holeAreas.push(tail);
    } else {
      preservedInteriorAreas.push(tail);
      for (let index = 0; index < tail; index += 1) preservedInterior[queue[index]] = 1;
    }
  }

  return {
    borderCut,
    cut,
    holeAreas,
    minimumHoleArea,
    preservedInterior,
    preservedInteriorAreas
  };
}

function connectedBorderBackground(width, height, distances, threshold) {
  return runStepsSync(backgroundRegionsSteps(width, height, distances, threshold)).borderCut;
}

function* offToneHoleSteps({
  width,
  height,
  pixels,
  components,
  distances,
  cut,
  borderCut,
  preservedInterior,
  cutThreshold,
  minimumHoleArea,
  background
}) {
  const size = width * height;
  const nearBackgroundThreshold = Math.min(48, cutThreshold + 18);
  const backgroundChroma = Math.max(...background) - Math.min(...background);
  const visited = new Uint8Array(size);
  const enclosedCandidates = new Uint8Array(size);
  const interiorHoleSeeds = new Uint8Array(size);
  const borderReleased = new Uint8Array(size);
  const queue = new Int32Array(size);
  const holeAreas = [];
  let holePixels = 0;
  let fragmentCleanupPixels = 0;
  let borderConnectedReleasePixels = 0;
  let completed = 0;
  const isCandidate = (index) => distances[index] <= nearBackgroundThreshold
    && Math.abs(colorChroma(pixels, components, index) - backgroundChroma) <= 8;

  for (let index = 0; index < size; index += 1) {
    if (cut[index] && !borderCut[index]) interiorHoleSeeds[index] = 1;
  }

  for (let seed = 0; seed < size; seed += 1) {
    if (visited[seed] || !isCandidate(seed)) continue;
    let head = 0;
    let tail = 0;
    let touchesBorder = false;
    let hasOffTonePixels = false;
    let containsExistingHole = false;
    const enqueue = (index) => {
      if (visited[index] || !isCandidate(index)) return;
      visited[index] = 1;
      queue[tail] = index;
      tail += 1;
    };
    enqueue(seed);

    while (head < tail) {
      const index = queue[head];
      head += 1;
      const x = index % width;
      const y = Math.floor(index / width);
      if (x === 0 || y === 0 || x === width - 1 || y === height - 1) touchesBorder = true;
      if (distances[index] > cutThreshold) hasOffTonePixels = true;
      if (cut[index] && !borderCut[index]) containsExistingHole = true;
      if (x > 0) enqueue(index - 1);
      if (x + 1 < width) enqueue(index + 1);
      if (y > 0) enqueue(index - width);
      if (y + 1 < height) enqueue(index + width);
      completed += 1;
      if (completed % YIELD_INTERVAL === 0) {
        yield { phase: "auto-off-tone-holes", completed, total: size };
      }
    }

    if (touchesBorder) {
      for (let index = 0; index < tail; index += 1) {
        const regionIndex = queue[index];
        if (preservedInterior[regionIndex]) borderConnectedReleasePixels += 1;
        preservedInterior[regionIndex] = 0;
        borderReleased[regionIndex] = 1;
      }
    } else if (!containsExistingHole && hasOffTonePixels && tail >= minimumHoleArea) {
      holeAreas.push(tail);
      holePixels += tail;
      for (let index = 0; index < tail; index += 1) {
        const regionIndex = queue[index];
        cut[regionIndex] = 1;
        preservedInterior[regionIndex] = 0;
        interiorHoleSeeds[regionIndex] = 1;
      }
    } else if (!touchesBorder && !containsExistingHole) {
      for (let index = 0; index < tail; index += 1) {
        enclosedCandidates[queue[index]] = 1;
      }
    }
  }

  // Reuse the component queue as a flood frontier. Only enclosed small
  // components are eligible, so this cannot cross a thin subject edge into
  // the border-connected background. A two-pixel neighborhood reconnects
  // checkerboard/compression fragments that belong to an accepted hole.
  const absorbCandidates = (seeds) => {
    let absorbed = 0;
    let head = 0;
    let tail = 0;
    for (let index = 0; index < size; index += 1) {
      if (!seeds[index]) continue;
      queue[tail] = index;
      tail += 1;
    }
    while (head < tail) {
      const index = queue[head];
      head += 1;
      const x = index % width;
      const y = Math.floor(index / width);
      for (let offsetY = -2; offsetY <= 2; offsetY += 1) {
        const neighborY = y + offsetY;
        if (neighborY < 0 || neighborY >= height) continue;
        for (let offsetX = -2; offsetX <= 2; offsetX += 1) {
          if (offsetX === 0 && offsetY === 0) continue;
          const neighborX = x + offsetX;
          if (neighborX < 0 || neighborX >= width) continue;
          const neighbor = neighborY * width + neighborX;
          if (!enclosedCandidates[neighbor]) continue;
          enclosedCandidates[neighbor] = 0;
          cut[neighbor] = 1;
          preservedInterior[neighbor] = 0;
          seeds[neighbor] = 1;
          queue[tail] = neighbor;
          tail += 1;
          absorbed += 1;
        }
      }
    }
    return absorbed;
  };
  const releaseBorderFringe = () => {
    let head = 0;
    let tail = 0;
    for (let index = 0; index < size; index += 1) {
      if (!borderReleased[index]) continue;
      queue[tail] = index;
      tail += 1;
    }
    const inspect = (neighbor) => {
      if (borderReleased[neighbor] || cut[neighbor]) return;
      if (distances[neighbor] > 80
        || Math.abs(colorChroma(pixels, components, neighbor) - backgroundChroma) > 16) return;
      borderReleased[neighbor] = 1;
      enclosedCandidates[neighbor] = 0;
      if (preservedInterior[neighbor]) borderConnectedReleasePixels += 1;
      preservedInterior[neighbor] = 0;
      queue[tail] = neighbor;
      tail += 1;
    };
    while (head < tail) {
      const index = queue[head];
      head += 1;
      const x = index % width;
      const y = Math.floor(index / width);
      if (x > 0) inspect(index - 1);
      if (x + 1 < width) inspect(index + 1);
      if (y > 0) inspect(index - width);
      if (y + 1 < height) inspect(index + width);
    }
  };
  releaseBorderFringe();
  fragmentCleanupPixels = absorbCandidates(interiorHoleSeeds);

  return {
    holeAreas,
    holePixels,
    fragmentCleanupPixels,
    borderConnectedReleasePixels,
    borderReleased,
    nearBackgroundThreshold
  };
}

function* preserveEnclosedUnknownSteps({
  trimap,
  width,
  height,
  pixels: sourcePixels,
  components,
  background
}) {
  const size = width * height;
  const visited = new Uint8Array(size);
  const queue = new Int32Array(size);
  const areas = [];
  const ambiguousShadeAreas = [];
  const protectedDetailAreas = [];
  // Small deep same-hue components can be eyes or line art rather than holes.
  // Scale by image area so the decision remains stable across resolutions.
  const protectedDetailLimit = Math.max(24, Math.round(size * 0.002));
  let pixels = 0;
  let ambiguousShadePixels = 0;
  let protectedDetailPixels = 0;
  let completed = 0;

  for (let seed = 0; seed < size; seed += 1) {
    if (visited[seed] || trimap.data[seed] !== LABELS.UNKNOWN) continue;
    let head = 0;
    let tail = 0;
    let touchesCut = false;
    const enqueue = (index) => {
      if (visited[index] || trimap.data[index] !== LABELS.UNKNOWN) return;
      visited[index] = 1;
      queue[tail] = index;
      tail += 1;
    };
    const inspect = (index) => {
      if (trimap.data[index] === LABELS.CUT) touchesCut = true;
      else enqueue(index);
    };
    enqueue(seed);

    while (head < tail) {
      const index = queue[head];
      head += 1;
      const x = index % width;
      const y = Math.floor(index / width);
      if (x > 0) inspect(index - 1);
      if (x + 1 < width) inspect(index + 1);
      if (y > 0) inspect(index - width);
      if (y + 1 < height) inspect(index + width);
      completed += 1;
      if (completed % YIELD_INTERVAL === 0) {
        yield { phase: "auto-enclosed-texture", completed, total: size };
      }
    }

    if (!touchesCut) {
      let promoted = 0;
      let shadePixels = 0;
      const protectSmallDetail = tail <= protectedDetailLimit;
      for (let index = 0; index < tail; index += 1) {
        const regionIndex = queue[index];
        if (!protectSmallDetail
          && isSaturatedBackgroundShade(sourcePixels, components, regionIndex, background)) {
          shadePixels += 1;
          continue;
        }
        mark(trimap, regionIndex, LABELS.KEEP);
        promoted += 1;
      }
      if (protectSmallDetail && promoted > 0) {
        protectedDetailAreas.push(promoted);
        protectedDetailPixels += promoted;
      }
      if (promoted > 0) areas.push(promoted);
      if (shadePixels > 0) ambiguousShadeAreas.push(shadePixels);
      pixels += promoted;
      ambiguousShadePixels += shadePixels;
    }
  }
  return {
    areas,
    pixels,
    ambiguousShadeAreas,
    ambiguousShadePixels,
    protectedDetailAreas,
    protectedDetailLimit,
    protectedDetailPixels
  };
}

function* autoTrimapSteps({ pixels, width, height, components = 3 }) {
  const total = width * height;
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1
    || (components !== 3 && components !== 4)
    || !(pixels instanceof Uint8Array) || pixels.length < total * components) {
    throw new TypeError("Auto trimap requires an RGB/RGBA Uint8Array");
  }
  const trimap = new TrimapRaster(width, height);
  const border = borderIndices(width, height);
  const transparentBorder = components >= 4 && median(border.map((index) => alphaAt(pixels, components, index))) < 32;

  if (transparentBorder) {
    let keepPixels = 0;
    let cutPixels = 0;
    for (let index = 0; index < total; index += 1) {
      const alpha = alphaAt(pixels, components, index);
      if (alpha <= 8) {
        mark(trimap, index, LABELS.CUT);
        cutPixels += 1;
      } else if (alpha >= 248) {
        mark(trimap, index, LABELS.KEEP);
        keepPixels += 1;
      }
      if ((index + 1) % YIELD_INTERVAL === 0) yield { phase: "auto-alpha", completed: index + 1, total };
    }
    return {
      trimap,
      diagnostics: {
        mode: "transparent-channel",
        confidence: keepPixels > 0 ? 0.95 : 0.35,
        keepPixels,
        cutPixels,
        unknownPixels: total - keepPixels - cutPixels,
        holeCount: 0,
        holePixels: 0,
        holeAreas: [],
        warnings: []
      }
    };
  }

  const background = [
    median(border.map((index) => pixels[index * components] || 0)),
    median(border.map((index) => pixels[index * components + 1] || 0)),
    median(border.map((index) => pixels[index * components + 2] || 0))
  ];
  const distances = new Float32Array(total);
  for (let index = 0; index < total; index += 1) {
    distances[index] = colorDistance(pixels, components, index, background);
    if ((index + 1) % YIELD_INTERVAL === 0) yield { phase: "auto-distance", completed: index + 1, total };
  }
  const borderDistances = border.map((index) => distances[index]);
  const borderMedian = median(borderDistances);
  const spread = median(borderDistances.map((value) => Math.abs(value - borderMedian)));
  const cutThreshold = clamp(6 + spread * 3, 6, 48);
  const backgroundBorderInlierRatio = borderDistances.filter((value) => value <= cutThreshold).length
    / Math.max(1, borderDistances.length);
  const backgroundRegions = yield* backgroundRegionsSteps(width, height, distances, cutThreshold);
  const {
    cut,
    minimumHoleArea,
    preservedInterior,
    preservedInteriorAreas
  } = backgroundRegions;
  const offToneHoles = yield* offToneHoleSteps({
    width,
    height,
    pixels,
    components,
    distances,
    cut,
    borderCut: backgroundRegions.borderCut,
    preservedInterior,
    cutThreshold,
    minimumHoleArea,
    background
  });
  const holeAreas = backgroundRegions.holeAreas.concat(offToneHoles.holeAreas);
  const holeCount = holeAreas.length;
  const holePixels = backgroundRegions.holeAreas.reduce((sum, area) => sum + area, 0)
    + offToneHoles.holePixels;
  const preservedInteriorPixels = preservedInteriorAreas.reduce((sum, area) => sum + area, 0);
  const foregroundScale = distancePercentileAbove(distances, cutThreshold, 0.9);
  const reliableContrast = foregroundScale >= Math.max(36, cutThreshold * 1.9);
  const keepThreshold = reliableContrast
    ? Math.max(cutThreshold * 1.65, foregroundScale * 0.96)
    : Number.POSITIVE_INFINITY;
  let keepPixels = 0;
  let cutPixels = 0;
  let chromaticInteriorPixels = 0;

  for (let index = 0; index < total; index += 1) {
    if (cut[index]) {
      mark(trimap, index, LABELS.CUT);
      cutPixels += 1;
    } else if (preservedInterior[index]) {
      mark(trimap, index, LABELS.KEEP);
      keepPixels += 1;
    } else if (distances[index] >= keepThreshold
      && !isSaturatedBackgroundShade(pixels, components, index, background)) {
      mark(trimap, index, LABELS.KEEP);
      keepPixels += 1;
    } else if (distances[index] > cutThreshold
      && colorChroma(pixels, components, index) >= 10
      && !isSaturatedBackgroundShade(pixels, components, index, background)
      && !offToneHoles.borderReleased[index]
      && !hasCutNeighbor(cut, width, height, index)) {
      mark(trimap, index, LABELS.KEEP);
      keepPixels += 1;
      chromaticInteriorPixels += 1;
    }
    if ((index + 1) % YIELD_INTERVAL === 0) yield { phase: "auto-classify", completed: index + 1, total };
  }

  const enclosedTextures = yield* preserveEnclosedUnknownSteps({
    trimap,
    width,
    height,
    pixels,
    components,
    background
  });
  keepPixels += enclosedTextures.pixels;

  const keepRatio = keepPixels / total;
  const cutRatio = cutPixels / total;
  const unknownPixels = total - keepPixels - cutPixels;
  const unknownRatio = unknownPixels / total;
  const warnings = [];
  let confidence = keepPixels > 0 && cutPixels > 0 ? 0.62 : 0.3;
  if (keepRatio < 0.01 || keepRatio > 0.85) confidence -= 0.18;
  if (cutRatio < 0.05 || cutRatio > 0.95) confidence -= 0.12;
  if (!reliableContrast || unknownRatio > 0.05 || keepPixels === 0 || cutPixels === 0) {
    warnings.push("ambiguous-foreground-background");
    confidence = Math.min(confidence, 0.49);
  }
  const ambiguousShadeLimit = Math.max(16, Math.round(total * 0.0005));
  const ambiguousShadeLargestArea = enclosedTextures.ambiguousShadeAreas.reduce(
    (largest, area) => Math.max(largest, area),
    0
  );
  if (ambiguousShadeLargestArea >= ambiguousShadeLimit) {
    warnings.push("ambiguous-enclosed-background-shade");
    confidence = Math.min(confidence, 0.49);
  }
  if (backgroundBorderInlierRatio < 0.8) {
    warnings.push("non-uniform-background-border");
    confidence = Math.min(confidence, 0.35);
  }
  return {
    trimap,
    diagnostics: {
      mode: "border-color",
      confidence: clamp(confidence, 0.05, 0.85),
      background,
      backgroundSpread: spread,
      backgroundBorderInlierRatio,
      foregroundScale,
      keepPixels,
      cutPixels,
      unknownPixels,
      holeCount,
      holePixels,
      holeAreas,
      minimumHoleArea,
      offToneHoleCount: offToneHoles.holeAreas.length,
      offToneHolePixels: offToneHoles.holePixels,
      fragmentCleanupPixels: offToneHoles.fragmentCleanupPixels,
      borderConnectedReleasePixels: offToneHoles.borderConnectedReleasePixels,
      nearBackgroundThreshold: offToneHoles.nearBackgroundThreshold,
      preservedInteriorCount: preservedInteriorAreas.length,
      preservedInteriorPixels,
      enclosedTextureCount: enclosedTextures.areas.length,
      enclosedTexturePixels: enclosedTextures.pixels,
      ambiguousEnclosedShadeCount: enclosedTextures.ambiguousShadeAreas.length,
      ambiguousEnclosedShadePixels: enclosedTextures.ambiguousShadePixels,
      ambiguousEnclosedShadeLargestArea: ambiguousShadeLargestArea,
      ambiguousEnclosedShadeLimit: ambiguousShadeLimit,
      protectedEnclosedDetailCount: enclosedTextures.protectedDetailAreas.length,
      protectedEnclosedDetailPixels: enclosedTextures.protectedDetailPixels,
      protectedEnclosedDetailLimit: enclosedTextures.protectedDetailLimit,
      chromaticInteriorPixels,
      warnings
    }
  };
}

function autoTrimap(request) {
  return runStepsSync(autoTrimapSteps(request));
}

function autoTrimapAsync(request) {
  return runStepsAsync(autoTrimapSteps(request), request.signal, request.onProgress);
}

function assertAutoTrimapUsable(result) {
  const diagnostics = result && result.diagnostics;
  const keepPixels = Number(diagnostics && diagnostics.keepPixels);
  const cutPixels = Number(diagnostics && diagnostics.cutPixels);
  const warnings = Array.isArray(diagnostics && diagnostics.warnings) ? diagnostics.warnings : [];
  if (warnings.includes("non-uniform-background-border")) {
    const error = new Error("图像边缘不是一致的纯色背景，请使用抠图精修或视觉模型 API。");
    error.code = "non-uniform-background-border";
    error.diagnostics = diagnostics || null;
    throw error;
  }
  if (warnings.includes("ambiguous-enclosed-background-shade")) {
    const error = new Error(
      "检测到主体内部存在与背景同色的连续区域，纯算法无法判断它是孔洞还是前景细节。请打开抠图精修标记，或改用视觉模型 API。"
    );
    error.code = "ambiguous-enclosed-background-shade";
    error.diagnostics = diagnostics || null;
    throw error;
  }
  if (warnings.includes("ambiguous-foreground-background")) {
    const error = new Error(
      "前景与背景颜色过于接近，纯算法无法可靠区分。请打开抠图精修标记，或改用视觉模型 API。"
    );
    error.code = "ambiguous-foreground-background";
    error.diagnostics = diagnostics || null;
    throw error;
  }
  if (!Number.isFinite(keepPixels) || !Number.isFinite(cutPixels) || keepPixels < 1 || cutPixels < 1) {
    const error = new Error("自动抠图无法可靠区分前景和背景，请改用标记精修。");
    error.code = "ambiguous-foreground-background";
    error.diagnostics = diagnostics || null;
    throw error;
  }
  return result;
}

function prepareAutoTrimapForEngine(result, engineMode) {
  try {
    return assertAutoTrimapUsable(result);
  } catch (error) {
    if (engineMode !== "vision-api" || !result || !result.trimap) throw error;
    const neutral = new TrimapRaster(result.trimap.width, result.trimap.height);
    const diagnostics = result.diagnostics && typeof result.diagnostics === "object"
      ? result.diagnostics
      : {};
    const warnings = Array.isArray(diagnostics.warnings) ? diagnostics.warnings.slice() : [];
    if (!warnings.includes("local-trimap-bypassed-for-vision")) {
      warnings.push("local-trimap-bypassed-for-vision");
    }
    return {
      trimap: neutral,
      diagnostics: {
        ...diagnostics,
        mode: "vision-neutral",
        confidence: 0,
        keepPixels: 0,
        cutPixels: 0,
        unknownPixels: neutral.data.length,
        warnings
      }
    };
  }
}

module.exports = {
  assertAutoTrimapUsable,
  autoTrimap,
  autoTrimapAsync,
  borderIndices,
  connectedBorderBackground,
  prepareAutoTrimapForEngine
};
