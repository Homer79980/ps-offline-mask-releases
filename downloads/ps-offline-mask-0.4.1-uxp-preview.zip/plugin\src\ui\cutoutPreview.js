const NAMED_BACKGROUNDS = Object.freeze({
  black: [0, 0, 0],
  white: [255, 255, 255],
  gray: [128, 128, 128]
});

function validateInput(source, alpha, foreground, foregroundUsable) {
  if (!source || !Number.isInteger(source.width) || !Number.isInteger(source.height)
    || source.width < 1 || source.height < 1
    || (source.components !== 3 && source.components !== 4)
    || !(source.pixels instanceof Uint8Array)) {
    throw new TypeError("Cutout preview requires an RGB or RGBA source");
  }
  const size = source.width * source.height;
  if (source.pixels.length !== size * source.components) {
    throw new RangeError("Source pixel length does not match dimensions");
  }
  if (!(alpha instanceof Uint8Array) || alpha.length !== size) {
    throw new RangeError("Alpha length does not match source dimensions");
  }
  if (foregroundUsable
    && (!(foreground instanceof Uint8Array) || foreground.length !== size * 3)) {
    throw new RangeError("Foreground length does not match source dimensions");
  }
  return size;
}

function resolveBackground(background) {
  if (background === undefined || background === null || background === "transparent") return null;
  if (typeof background === "string" && NAMED_BACKGROUNDS[background]) {
    return NAMED_BACKGROUNDS[background];
  }
  const color = Array.isArray(background)
    ? background
    : background && Array.isArray(background.color) ? background.color : null;
  if (!color || color.length !== 3 || color.some((value) => !Number.isFinite(Number(value))
    || Number(value) < 0 || Number(value) > 255)) {
    throw new RangeError("Background color must contain three RGB values from 0 to 255");
  }
  return color.map((value) => Math.round(Number(value)));
}

function createCutoutPreview({
  source,
  alpha,
  foreground,
  foregroundUsable = false,
  background = "transparent"
} = {}) {
  const size = validateInput(source, alpha, foreground, foregroundUsable);
  const backgroundColor = resolveBackground(background);
  const components = backgroundColor ? 3 : 4;
  const pixels = new Uint8Array(size * components);
  const colors = foregroundUsable && foreground instanceof Uint8Array
    ? foreground
    : source.pixels;
  const colorComponents = colors === foreground ? 3 : source.components;
  for (let index = 0; index < size; index += 1) {
    const sourceOffset = index * colorComponents;
    const targetOffset = index * components;
    if (backgroundColor) {
      const opacity = alpha[index];
      const inverse = 255 - opacity;
      for (let channel = 0; channel < 3; channel += 1) {
        pixels[targetOffset + channel] = Math.round(
          (colors[sourceOffset + channel] * opacity + backgroundColor[channel] * inverse) / 255
        );
      }
    } else {
      pixels[targetOffset] = colors[sourceOffset];
      pixels[targetOffset + 1] = colors[sourceOffset + 1];
      pixels[targetOffset + 2] = colors[sourceOffset + 2];
      pixels[targetOffset + 3] = alpha[index];
    }
  }
  return { width: source.width, height: source.height, components, pixels };
}

module.exports = { createCutoutPreview };
