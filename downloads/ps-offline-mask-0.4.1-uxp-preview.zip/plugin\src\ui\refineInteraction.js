function isPrimaryButton(event) {
  return !event || event.button === undefined || Number(event.button) === 0;
}

function eventPoint(event) {
  return {
    x: Number(event && event.clientX) || 0,
    y: Number(event && event.clientY) || 0
  };
}

function eventFamily(event) {
  const type = String(event && event.type || "").toLowerCase();
  if (type.startsWith("pointer")) return "pointer";
  if (type.startsWith("mouse")) return "mouse";
  return null;
}

function createRefineInteraction() {
  let spacePressed = false;
  let mode = "idle";
  let pointerId;
  let activeFamily = null;
  let lastPoint = null;

  function setSpacePressed(value) {
    const next = Boolean(value);
    if (next === spacePressed) return false;
    spacePressed = next;
    return true;
  }

  function begin(event) {
    if (mode !== "idle" || !isPrimaryButton(event)) return null;
    pointerId = event && event.pointerId;
    activeFamily = eventFamily(event);
    lastPoint = eventPoint(event);
    mode = spacePressed ? "pan" : "paint";
    return { kind: `${mode}-start`, point: { ...lastPoint } };
  }

  function matchesPointer(event) {
    const family = eventFamily(event);
    if (activeFamily && family && activeFamily !== family) return false;
    return pointerId === undefined || !event || event.pointerId === undefined || event.pointerId === pointerId;
  }

  function move(event) {
    if (mode === "idle" || !matchesPointer(event)) return null;
    const point = eventPoint(event);
    if (mode === "pan") {
      const action = {
        kind: "pan",
        scrollDeltaX: lastPoint.x - point.x,
        scrollDeltaY: lastPoint.y - point.y
      };
      lastPoint = point;
      return action;
    }
    const action = { kind: "paint", from: { ...lastPoint }, to: { ...point } };
    lastPoint = point;
    return action;
  }

  function end(event) {
    if (mode === "idle" || !matchesPointer(event)) return null;
    const endedMode = mode;
    mode = "idle";
    pointerId = undefined;
    activeFamily = null;
    lastPoint = null;
    return { kind: `${endedMode}-end` };
  }

  function reset() {
    const changed = mode !== "idle" || spacePressed;
    mode = "idle";
    pointerId = undefined;
    activeFamily = null;
    lastPoint = null;
    spacePressed = false;
    return changed;
  }

  return Object.freeze({
    begin,
    end,
    move,
    reset,
    setSpacePressed,
    get mode() { return mode; },
    get spacePressed() { return spacePressed; }
  });
}

module.exports = { createRefineInteraction, eventFamily, isPrimaryButton };
