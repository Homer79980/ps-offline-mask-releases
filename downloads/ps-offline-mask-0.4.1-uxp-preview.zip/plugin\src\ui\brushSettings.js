const MIN_BRUSH_SIZE = 2;
const MAX_BRUSH_SIZE = 160;
const BRUSH_STEP = 4;

function clampBrushSize(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return MIN_BRUSH_SIZE;
  return Math.min(MAX_BRUSH_SIZE, Math.max(MIN_BRUSH_SIZE, Math.round(numeric)));
}

function brushSizeFromKeyboard(event, currentSize) {
  const key = event && event.key;
  const code = event && event.code;
  const legacyCode = Number(event && (event.keyCode ?? event.which));
  if (key === "[" || code === "BracketLeft" || legacyCode === 219) {
    return clampBrushSize(Number(currentSize) - BRUSH_STEP);
  }
  if (key === "]" || code === "BracketRight" || legacyCode === 221) {
    return clampBrushSize(Number(currentSize) + BRUSH_STEP);
  }
  return null;
}

function brushRingGeometry({ brushSize, softness = 0, scale = 1 } = {}) {
  const safeSize = clampBrushSize(brushSize);
  const numericScale = Number(scale);
  const safeScale = Number.isFinite(numericScale) && numericScale > 0 ? numericScale : 1;
  const numericSoftness = Number(softness);
  const safeSoftness = Number.isFinite(numericSoftness)
    ? Math.min(1, Math.max(0, numericSoftness))
    : 0;
  const outerDiameter = Math.max(4, safeSize * safeScale);

  return {
    outerDiameter,
    coreDiameter: Math.max(2, outerDiameter * (1 - safeSoftness))
  };
}

module.exports = {
  BRUSH_STEP,
  MAX_BRUSH_SIZE,
  MIN_BRUSH_SIZE,
  brushRingGeometry,
  brushSizeFromKeyboard,
  clampBrushSize
};
