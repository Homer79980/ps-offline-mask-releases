const REQUIRED_INPUTS = Object.freeze([
  "down",
  "move",
  "up",
  "wheel",
  "bracket-left",
  "bracket-right"
]);

const INPUT_LABELS = Object.freeze({
  down: "按下事件",
  move: "移动事件",
  up: "释放事件",
  wheel: "滚轮事件",
  "bracket-left": "左方括号快捷键",
  "bracket-right": "右方括号快捷键"
});

function eventKind(event) {
  const type = String(event && event.type || "").toLowerCase();
  if (type === "pointerdown" || type === "mousedown") return "down";
  if (type === "pointermove" || type === "mousemove") return "move";
  if (type === "pointerup" || type === "mouseup") return "up";
  if (type === "wheel" || type === "mousewheel" || type === "dommousescroll") return "wheel";
  if (type !== "keydown") return null;

  const key = String(event.key || "");
  const code = String(event.code || "");
  const legacyCode = Number(event.keyCode ?? event.which);
  if (key === "[" || code === "BracketLeft" || legacyCode === 219) return "bracket-left";
  if (key === "]" || code === "BracketRight" || legacyCode === 221) return "bracket-right";
  return null;
}

function point(value, label) {
  const x = Number(value && value.x);
  const y = Number(value && value.y);
  if (!Number.isFinite(x) || !Number.isFinite(y)) {
    throw new TypeError(`${label} must contain finite x and y coordinates`);
  }
  return { x, y };
}

function rounded(value) {
  return Math.round(value * 1e6) / 1e6;
}

function createUxpInputProbe(options = {}) {
  const mappingTolerance = Number(options.mappingTolerance ?? 1);
  if (!Number.isFinite(mappingTolerance) || mappingTolerance < 0) {
    throw new TypeError("mappingTolerance must be a non-negative finite number");
  }

  const observed = new Set();
  let trustedEvents = 0;
  let untrustedEvents = 0;
  let mappingSamples = 0;
  let maxMappingError = 0;

  function recordEvent(event) {
    const kind = eventKind(event);
    if (!kind) return false;
    // UXP omits isTrusted on some native mouse and keyboard events. Only an
    // explicit false means the event is synthetic and should be rejected.
    if (!event || event.isTrusted === false) {
      untrustedEvents += 1;
      return false;
    }
    observed.add(kind);
    trustedEvents += 1;
    return true;
  }

  function recordMapping(sample) {
    if (!sample || sample.isTrusted === false) {
      untrustedEvents += 1;
      return false;
    }
    const expected = point(sample.expected, "expected");
    const actual = point(sample.actual, "actual");
    const error = Math.hypot(actual.x - expected.x, actual.y - expected.y);
    mappingSamples += 1;
    maxMappingError = Math.max(maxMappingError, error);
    return true;
  }

  function result() {
    const missing = REQUIRED_INPUTS.filter((kind) => !observed.has(kind));
    const failures = missing.map((kind) => `未检测到受信的${INPUT_LABELS[kind]}。`);
    if (mappingSamples === 0) {
      failures.push("未检测到受信的坐标映射样本。");
    } else if (maxMappingError > mappingTolerance) {
      failures.push(`坐标映射误差 ${maxMappingError.toFixed(2)} px 超过允许的 ${mappingTolerance.toFixed(2)} px。`);
    }
    const warnings = untrustedEvents > 0 ? [`忽略了 ${untrustedEvents} 个非受信事件。`] : [];
    const passed = failures.length === 0;
    return {
      passed,
      status: passed ? "passed" : "failed",
      missing,
      failures,
      warnings,
      metrics: {
        trustedEvents,
        untrustedEvents,
        mappingSamples,
        maxMappingError: rounded(maxMappingError),
        mappingTolerance
      }
    };
  }

  return Object.freeze({ recordEvent, recordMapping, result });
}

module.exports = { REQUIRED_INPUTS, createUxpInputProbe, eventKind };
