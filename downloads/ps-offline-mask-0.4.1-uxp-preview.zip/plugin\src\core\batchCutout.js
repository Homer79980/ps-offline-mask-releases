function isCanceled(signal, error) {
  return Boolean(signal && signal.aborted)
    || Boolean(error && (error.name === "AbortError" || error.code === "canceled"));
}

function assertFunction(value, name) {
  if (typeof value !== "function") throw new TypeError(`${name} must be a function`);
}

function describeFailure(error) {
  if (typeof error === "string" || typeof error === "number" || typeof error === "boolean") {
    const value = String(error).trim();
    if (value) return value;
  }
  if (error && typeof error === "object") {
    const values = [error.message, error.description, error.reason, error.code, error.number, error.result];
    const value = values.find((candidate) => candidate !== undefined && candidate !== null && String(candidate).trim());
    if (value !== undefined) return String(value).trim();
  }
  return "Photoshop 未返回详细错误";
}

function normalizeFailure(error) {
  if (error instanceof Error && String(error.message || "").trim()) return error;
  const normalized = new Error(describeFailure(error));
  normalized.originalError = error;
  return normalized;
}

async function runBatchCutout({
  layers,
  processLayer,
  saveOriginalMask,
  applyMask,
  applyResult,
  restoreOriginalMask,
  signal,
  onProgress
} = {}) {
  if (!Array.isArray(layers) || layers.length === 0) throw new Error("请至少选择一个像素图层。");
  assertFunction(processLayer, "processLayer");
  assertFunction(saveOriginalMask, "saveOriginalMask");
  if (typeof applyResult !== "function") assertFunction(applyMask, "applyMask");
  assertFunction(restoreOriginalMask, "restoreOriginalMask");

  const result = { succeeded: [], failed: [], canceled: false, total: layers.length };
  const report = (event) => {
    if (typeof onProgress === "function") onProgress({ total: layers.length, ...event });
  };

  for (let index = 0; index < layers.length; index += 1) {
    if (signal && signal.aborted) {
      result.canceled = true;
      break;
    }
    const layer = layers[index];
    report({ phase: "processing", index, completed: index, layer });
    let snapshot = null;
    let processed = null;
    try {
      processed = await processLayer(layer, { signal, index, total: layers.length });
      if (signal && signal.aborted) {
        result.canceled = true;
        break;
      }
      if (!processed || !(processed.alpha instanceof Uint8Array)) {
        throw new Error("批量算法没有返回有效蒙版。");
      }
      const hasForeground = processed.foreground instanceof Uint8Array;
      if (processed.foreground !== undefined && !hasForeground) {
        throw new Error("批量算法返回的校正前景无效。");
      }
      if (!hasForeground) snapshot = await saveOriginalMask(layer);
      // Once the reversible snapshot exists, finish the current layer write.
      // Cancellation takes effect before the next layer.
      report({ phase: "applying", index, completed: index, layer });
      if (typeof applyResult === "function") await applyResult(layer, processed);
      else await applyMask(layer, processed.alpha);
      result.succeeded.push({ layer, diagnostics: processed.diagnostics || null });
    } catch (error) {
      if (isCanceled(signal, error)) {
        result.canceled = true;
        break;
      }
      const failure = normalizeFailure(error);
      let rollbackFailed = false;
      if (processed && processed.foreground instanceof Uint8Array
        && failure.rollbackCompleted !== true) {
        rollbackFailed = true;
      }
      if (snapshot && failure.rollbackCompleted !== true) {
        try {
          await restoreOriginalMask(layer, snapshot);
          failure.rollbackCompleted = true;
        } catch (restoreError) {
          failure.restoreError = normalizeFailure(restoreError);
          failure.rollbackCompleted = false;
          rollbackFailed = true;
        }
      }
      result.failed.push({ layer, error: failure });
      if (rollbackFailed) {
        result.canceled = true;
        break;
      }
    }
    report({ phase: "completed", index, completed: index + 1, layer });
  }

  return result;
}

module.exports = { runBatchCutout };
