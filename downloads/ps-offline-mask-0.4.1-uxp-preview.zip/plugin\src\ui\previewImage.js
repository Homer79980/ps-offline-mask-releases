const { bytesToBase64 } = require("../core/visionApi");

const MAX_STORED_BLOCK = 65_535;

function writeUint32LE(target, offset, value) {
  target[offset] = value & 0xff;
  target[offset + 1] = (value >>> 8) & 0xff;
  target[offset + 2] = (value >>> 16) & 0xff;
  target[offset + 3] = (value >>> 24) & 0xff;
}

function writeUint32BE(target, offset, value) {
  target[offset] = (value >>> 24) & 0xff;
  target[offset + 1] = (value >>> 16) & 0xff;
  target[offset + 2] = (value >>> 8) & 0xff;
  target[offset + 3] = value & 0xff;
}

function concatBytes(parts) {
  const total = parts.reduce((sum, part) => sum + part.length, 0);
  const result = new Uint8Array(total);
  let offset = 0;
  parts.forEach((part) => {
    result.set(part, offset);
    offset += part.length;
  });
  return result;
}

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let index = 0; index < table.length; index += 1) {
    let value = index;
    for (let bit = 0; bit < 8; bit += 1) value = (value & 1) ? (0xedb88320 ^ (value >>> 1)) : (value >>> 1);
    table[index] = value >>> 0;
  }
  return table;
})();

function crc32(bytes) {
  let value = 0xffffffff;
  for (const byte of bytes) value = CRC_TABLE[(value ^ byte) & 0xff] ^ (value >>> 8);
  return (value ^ 0xffffffff) >>> 0;
}

function pngChunk(type, payload) {
  const typeBytes = new Uint8Array(type.length);
  for (let index = 0; index < type.length; index += 1) typeBytes[index] = type.charCodeAt(index);
  const crcInput = concatBytes([typeBytes, payload]);
  const chunk = new Uint8Array(12 + payload.length);
  writeUint32BE(chunk, 0, payload.length);
  chunk.set(typeBytes, 4);
  chunk.set(payload, 8);
  writeUint32BE(chunk, 8 + payload.length, crc32(crcInput));
  return chunk;
}

function adler32(bytes) {
  let a = 1;
  let b = 0;
  for (const byte of bytes) {
    a = (a + byte) % 65521;
    b = (b + a) % 65521;
  }
  return (((b << 16) | a) >>> 0);
}

function createStoredZlib(bytes) {
  const blockCount = Math.max(1, Math.ceil(bytes.length / MAX_STORED_BLOCK));
  const result = new Uint8Array(2 + bytes.length + blockCount * 5 + 4);
  result[0] = 0x78;
  result[1] = 0x01;
  let offset = 2;
  for (let start = 0; start < bytes.length || (bytes.length === 0 && start === 0); start += MAX_STORED_BLOCK) {
    const end = Math.min(bytes.length, start + MAX_STORED_BLOCK);
    const length = end - start;
    const finalBlock = end === bytes.length;
    result[offset] = finalBlock ? 1 : 0;
    offset += 1;
    result[offset] = length & 0xff;
    result[offset + 1] = (length >>> 8) & 0xff;
    result[offset + 2] = (~length) & 0xff;
    result[offset + 3] = (~length >>> 8) & 0xff;
    offset += 4;
    result.set(bytes.subarray(start, end), offset);
    offset += length;
    if (bytes.length === 0) break;
  }
  writeUint32LE(result, offset, adler32(bytes));
  return result;
}

function normalizePreviewPixels({ pixels, width, height, components } = {}) {
  if (!(pixels instanceof Uint8Array) || !Number.isInteger(width) || !Number.isInteger(height)) {
    throw new TypeError("Preview pixels must be a Uint8Array with integer dimensions");
  }
  if (width < 1 || height < 1 || (components !== 3 && components !== 4)) {
    throw new RangeError("Preview pixels must be RGB or RGBA");
  }
  const expectedLength = width * height * components;
  if (pixels.length !== expectedLength) throw new RangeError("Preview pixel length does not match dimensions");
  return { pixels, width, height, components };
}

function scalePreviewPixels({ pixels, width, height, components } = {}, maxDimension = 2048) {
  if (!(pixels instanceof Uint8Array) || !Number.isInteger(width) || !Number.isInteger(height)
    || !Number.isInteger(components) || components < 1 || components > 4
    || width < 1 || height < 1 || pixels.length !== width * height * components) {
    throw new TypeError("Preview plane dimensions do not match its pixels");
  }
  const limit = Math.max(1, Math.floor(Number(maxDimension) || 2048));
  const scale = Math.min(1, limit / Math.max(width, height));
  if (scale === 1) return { pixels, width, height, components };
  const targetWidth = Math.max(1, Math.round(width * scale));
  const targetHeight = Math.max(1, Math.round(height * scale));
  const result = new Uint8Array(targetWidth * targetHeight * components);
  for (let y = 0; y < targetHeight; y += 1) {
    const sourceY = Math.min(height - 1, Math.floor(((y + 0.5) * height) / targetHeight));
    for (let x = 0; x < targetWidth; x += 1) {
      const sourceX = Math.min(width - 1, Math.floor(((x + 0.5) * width) / targetWidth));
      const sourceOffset = (sourceY * width + sourceX) * components;
      const targetOffset = (y * targetWidth + x) * components;
      for (let channel = 0; channel < components; channel += 1) {
        result[targetOffset + channel] = pixels[sourceOffset + channel];
      }
    }
  }
  return { pixels: result, width: targetWidth, height: targetHeight, components };
}

function encodePngDataUrl(options) {
  const { pixels, width, height, components } = normalizePreviewPixels(options);
  const rowLength = width * components;
  const scanlines = new Uint8Array(height * (rowLength + 1));
  for (let y = 0; y < height; y += 1) {
    const scanlineOffset = y * (rowLength + 1);
    scanlines[scanlineOffset] = 0;
    scanlines.set(pixels.subarray(y * rowLength, (y + 1) * rowLength), scanlineOffset + 1);
  }

  const header = new Uint8Array(13);
  writeUint32BE(header, 0, width);
  writeUint32BE(header, 4, height);
  header[8] = 8;
  header[9] = components === 4 ? 6 : 2;
  const signature = new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10]);
  const png = concatBytes([
    signature,
    pngChunk("IHDR", header),
    pngChunk("IDAT", createStoredZlib(scanlines)),
    pngChunk("IEND", new Uint8Array(0))
  ]);
  return `data:image/png;base64,${bytesToBase64(png)}`;
}

function createMaskPreviewPixels(alpha) {
  if (!(alpha instanceof Uint8Array)) throw new TypeError("Mask alpha must be a Uint8Array");
  const pixels = new Uint8Array(alpha.length * 3);
  for (let index = 0; index < alpha.length; index += 1) {
    const target = index * 3;
    pixels[target] = alpha[index];
    pixels[target + 1] = alpha[index];
    pixels[target + 2] = alpha[index];
  }
  return pixels;
}

module.exports = { createMaskPreviewPixels, encodePngDataUrl, scalePreviewPixels };
