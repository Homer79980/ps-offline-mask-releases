function createWorkspaceHistory(options = {}) {
  const limit = Math.max(1, Math.floor(Number(options.limit) || 50));
  let undoEntries = [];
  let redoEntries = [];

  function record(entry) {
    if (!entry || typeof entry !== "object") throw new TypeError("Workspace history entry is required");
    undoEntries.push(entry);
    if (undoEntries.length > limit) undoEntries.shift();
    redoEntries = [];
    return entry;
  }

  function undo() {
    const entry = undoEntries.pop() || null;
    if (entry) redoEntries.push(entry);
    return entry;
  }

  function redo() {
    const entry = redoEntries.pop() || null;
    if (entry) undoEntries.push(entry);
    return entry;
  }

  function clear() {
    undoEntries = [];
    redoEntries = [];
  }

  return Object.freeze({
    clear,
    record,
    redo,
    undo,
    get canUndo() { return undoEntries.length > 0; },
    get canRedo() { return redoEntries.length > 0; }
  });
}

module.exports = { createWorkspaceHistory };
