const SUPPORTED_SOURCE_EXTENSIONS = Object.freeze(new Set(["png", "jpg", "jpeg", "webp"]));
const FOLDER_BATCH_PRESETS = Object.freeze({
  "game-icon": Object.freeze({ edgeShift: -10, feather: 0, hardThreshold: 0, invert: false }),
  product: Object.freeze({ edgeShift: -10, feather: 25, hardThreshold: 0, invert: false }),
  "hard-edge": Object.freeze({ edgeShift: -10, feather: 0, hardThreshold: 128, invert: false })
});

function folderBatchOptionsForPreset(preset, current = {}) {
  const selected = String(preset || "current");
  if (selected === "current") return { ...current };
  const values = FOLDER_BATCH_PRESETS[selected];
  if (!values) throw new Error(`unknown folder batch preset: ${selected}`);
  return { ...current, ...values };
}

function splitExtension(name) {
  const value = String(name || "");
  const index = value.lastIndexOf(".");
  if (index <= 0 || index === value.length - 1) return { stem: value, extension: "" };
  return {
    stem: value.slice(0, index),
    extension: value.slice(index + 1).toLowerCase()
  };
}

function isSupportedSourceName(name) {
  return SUPPORTED_SOURCE_EXTENSIONS.has(splitExtension(name).extension);
}

function isGeneratedOutputName(name) {
  return /_cutout(?:_\d+)?\.png$/i.test(String(name || ""));
}

function isConfirmedGeneratedOutput(name, entries) {
  const match = /^(.*)_cutout(?:_\d+)?\.png$/i.exec(String(name || ""));
  if (!match) return false;
  const expectedStem = match[1].toLocaleLowerCase("en-US");
  return entries.some((entry) => {
    if (!entry || entry.isFile !== true || String(entry.name || "") === String(name || "")) return false;
    const source = splitExtension(entry.name);
    return SUPPORTED_SOURCE_EXTENSIONS.has(source.extension)
      && source.stem.toLocaleLowerCase("en-US") === expectedStem;
  });
}

function transparentPngName(sourceName, sequence = 1) {
  const { stem } = splitExtension(sourceName);
  const number = Math.max(1, Math.trunc(Number(sequence) || 1));
  return `${stem}_cutout${number === 1 ? "" : `_${number}`}.png`;
}

function stableEntryCompare(left, right) {
  const leftFolded = String(left && left.name || "").normalize("NFC").toLocaleLowerCase("en-US");
  const rightFolded = String(right && right.name || "").normalize("NFC").toLocaleLowerCase("en-US");
  if (leftFolded < rightFolded) return -1;
  if (leftFolded > rightFolded) return 1;
  const leftName = String(left && left.name || "");
  const rightName = String(right && right.name || "");
  return leftName < rightName ? -1 : leftName > rightName ? 1 : 0;
}

function canonicalEntryPath(entry, platform) {
  let value = String(entry && (entry.nativePath || entry.url) || "").replace(/\\/g, "/");
  while (value.length > 1 && value.endsWith("/")) value = value.slice(0, -1);
  const windowsPath = platform === "win32" || /^[a-z]:\//i.test(value);
  return windowsPath ? value.toLocaleLowerCase("en-US") : value;
}

function folderBatchAbortError() {
  const error = new Error("folder batch canceled");
  error.name = "AbortError";
  error.code = "canceled";
  return error;
}

function assertScanActive(signal) {
  if (signal && signal.aborted) throw folderBatchAbortError();
}

async function scanSourceFolder({ sourceFolder, outputFolder, recursive = false, platform, signal } = {}) {
  if (!sourceFolder || sourceFolder.isFolder !== true || typeof sourceFolder.getEntries !== "function") {
    throw new TypeError("sourceFolder must be a readable UXP folder entry");
  }
  if (!outputFolder || outputFolder.isFolder !== true) {
    throw new TypeError("outputFolder must be a UXP folder entry");
  }
  const items = [];
  const skipped = [];
  const outputPath = canonicalEntryPath(outputFolder, platform);
  const sourcePath = canonicalEntryPath(sourceFolder, platform);
  const sameRoot = Boolean(sourcePath && outputPath && sourcePath === outputPath);

  async function visit(currentFolder, relativeDirectories) {
    assertScanActive(signal);
    const entries = [...await currentFolder.getEntries()].sort(stableEntryCompare);
    assertScanActive(signal);
    for (const entry of entries) {
      assertScanActive(signal);
      if (!entry) continue;
      if (entry.isFolder === true) {
        if (!recursive) continue;
        if (!sameRoot && canonicalEntryPath(entry, platform) === outputPath) continue;
        await visit(entry, [...relativeDirectories, String(entry.name || "")]);
        continue;
      }
      if (entry.isFile !== true) continue;
      const name = String(entry.name || "");
      const relativePath = [...relativeDirectories, name].join("/");
      if (sameRoot && isConfirmedGeneratedOutput(name, entries)) {
        skipped.push({ relativePath, reason: "generated-output" });
      } else if (isSupportedSourceName(name)) {
        items.push({ sourceEntry: entry, relativeDirectories: [...relativeDirectories], relativePath });
      } else {
        skipped.push({ relativePath, reason: "unsupported-format" });
      }
    }
  }

  await visit(sourceFolder, []);
  return { items, skipped };
}

async function createNumberedOutputFile(outputFolder, sourceName) {
  if (!outputFolder || outputFolder.isFolder !== true
    || typeof outputFolder.getEntries !== "function"
    || typeof outputFolder.createFile !== "function") {
    throw new TypeError("outputFolder must be a writable UXP folder entry");
  }
  let minimumSequence = 1;
  for (let attempt = 0; attempt < 10_000; attempt += 1) {
    const existing = new Set((await outputFolder.getEntries())
      .map((entry) => String(entry && entry.name || "").toLocaleLowerCase("en-US")));
    let sequence = minimumSequence;
    let name = transparentPngName(sourceName, sequence);
    while (existing.has(name.toLocaleLowerCase("en-US"))) {
      sequence += 1;
      name = transparentPngName(sourceName, sequence);
    }
    try {
      return await outputFolder.createFile(name, { overwrite: false });
    } catch (error) {
      const detail = `${String(error && error.name || "")} ${String(error && error.code || "")} ${String(error && error.message || "")}`;
      if (!/entryexists|already exists|alreadyexists/i.test(detail)) throw error;
      minimumSequence = sequence + 1;
    }
  }
  throw new Error("could not reserve a unique output filename");
}

async function ensureOutputFolder(outputRoot, relativeDirectories = []) {
  if (!outputRoot || outputRoot.isFolder !== true || typeof outputRoot.getEntries !== "function") {
    throw new TypeError("outputRoot must be a writable UXP folder entry");
  }
  let current = outputRoot;
  for (const rawSegment of relativeDirectories) {
    const segment = String(rawSegment || "").trim();
    if (!segment || segment === "." || segment === ".." || /[\\/]/.test(segment)) {
      throw new Error("relative output directory contains an unsafe segment");
    }
    const entries = await current.getEntries();
    const existing = entries.find((entry) => String(entry && entry.name || "")
      .toLocaleLowerCase("en-US") === segment.toLocaleLowerCase("en-US"));
    if (existing) {
      if (existing.isFolder !== true) throw new Error(`output path is occupied by a file: ${segment}`);
      current = existing;
    } else {
      if (typeof current.createFolder !== "function") {
        throw new Error("output folder cannot create child directories");
      }
      current = await current.createFolder(segment);
    }
  }
  return current;
}

function errorMessage(error) {
  if (error && typeof error === "object") {
    for (const value of [error.message, error.description, error.reason, error.code]) {
      if (value !== undefined && value !== null && String(value).trim()) return String(value).trim();
    }
  }
  if (error !== undefined && error !== null && String(error).trim()) return String(error).trim();
  return "unknown-error";
}

function isAbort(error, signal) {
  return Boolean(signal && signal.aborted)
    || Boolean(error && (error.name === "AbortError" || error.code === "canceled"));
}

function redactLocalPaths(value) {
  let text = String(value || "");
  text = text.replace(/[a-z]:[\\/][^\r\n]*/gi, "[local-path]");
  text = text.replace(/\\\\[^\s\\/]+[\\/][^\r\n]*/g, "[local-path]");
  text = text.replace(/(^|\s)\/(?:[^\s/]+\/)*[^\s/]+/g, "$1[local-path]");
  return text;
}

async function runFolderBatch({
  items,
  skipped = [],
  processItem,
  signal,
  onProgress,
  now = Date.now
} = {}) {
  if (!Array.isArray(items)) throw new TypeError("items must be an array");
  if (!Array.isArray(skipped)) throw new TypeError("skipped must be an array");
  if (typeof processItem !== "function") throw new TypeError("processItem must be a function");
  if (typeof now !== "function") throw new TypeError("now must be a function");
  const startedAt = Number(now());
  const result = {
    total: items.length + skipped.length,
    processableTotal: items.length,
    succeeded: [],
    failed: [],
    canceledItems: [],
    skipped: skipped.map((item) => ({
      relativePath: String(item.relativePath || ""),
      reason: String(item.reason || "skipped")
    })),
    canceled: false,
    startedAt,
    finishedAt: startedAt,
    durationMs: 0
  };
  const report = (event) => {
    if (typeof onProgress === "function") {
      onProgress({
        total: items.length,
        succeeded: result.succeeded.length,
        failed: result.failed.length,
        skipped: result.skipped.length,
        canceled: result.canceledItems.length,
        ...event
      });
    }
  };

  let canceledFrom = items.length;
  for (let index = 0; index < items.length; index += 1) {
    if (signal && signal.aborted) {
      result.canceled = true;
      canceledFrom = index;
      break;
    }
    const item = items[index];
    const itemStartedAt = Number(now());
    report({ phase: "processing", index, completed: index, item });
    try {
      const processed = await processItem(item, { index, total: items.length, signal });
      const itemFinishedAt = Number(now());
      result.succeeded.push({
        relativePath: String(item.relativePath || ""),
        outputRelativePath: String(processed && processed.outputRelativePath || ""),
        engine: String(processed && processed.engine || "local-algorithm"),
        warnings: Array.isArray(processed && processed.warnings)
          ? processed.warnings.map((value) => String(value))
          : [],
        durationMs: Math.max(0, itemFinishedAt - itemStartedAt)
      });
      report({ phase: "completed", index, completed: index + 1, item });
    } catch (error) {
      if (isAbort(error, signal)) {
        result.canceled = true;
        canceledFrom = index;
        break;
      }
      const itemFinishedAt = Number(now());
      result.failed.push({
        relativePath: String(item && item.relativePath || ""),
        stage: String(error && error.stage || "process"),
        reason: errorMessage(error),
        durationMs: Math.max(0, itemFinishedAt - itemStartedAt)
      });
      report({ phase: "failed", index, completed: index + 1, item });
    }
  }

  if (result.canceled) {
    result.canceledItems = items.slice(canceledFrom).map((item) => ({
      relativePath: String(item && item.relativePath || ""),
      reason: "canceled"
    }));
  }

  result.finishedAt = Number(now());
  result.durationMs = Math.max(0, result.finishedAt - result.startedAt);
  return result;
}

function buildFolderBatchReport(result) {
  if (!result || typeof result !== "object") throw new TypeError("result is required");
  return {
    schemaVersion: 2,
    summary: {
      total: Number(result.total) || 0,
      succeeded: Array.isArray(result.succeeded) ? result.succeeded.length : 0,
      failed: Array.isArray(result.failed) ? result.failed.length : 0,
      skipped: Array.isArray(result.skipped) ? result.skipped.length : 0,
      canceled: Array.isArray(result.canceledItems) ? result.canceledItems.length : 0,
      stopped: Boolean(result.canceled),
      durationMs: Math.max(0, Number(result.durationMs) || 0)
    },
    outputPolicy: {
      format: "transparent-png",
      colorSpace: "RGB",
      colorProfile: "preserve-source-when-available",
      dimensions: "preserve-source-pixels",
      resolution: "preserve-source-when-available",
      metadata: "other-source-metadata-not-copied"
    },
    files: [
      ...(result.succeeded || []).map((item) => ({
        input: String(item.relativePath || ""),
        output: String(item.outputRelativePath || ""),
        result: "succeeded",
        engine: String(item.engine || "local-algorithm"),
        warnings: Array.isArray(item.warnings) ? item.warnings.map(redactLocalPaths) : [],
        durationMs: Math.max(0, Number(item.durationMs) || 0)
      })),
      ...(result.failed || []).map((item) => ({
        input: String(item.relativePath || ""),
        output: "",
        result: "failed",
        stage: String(item.stage || "process"),
        reason: redactLocalPaths(item.reason || "unknown-error"),
        durationMs: Math.max(0, Number(item.durationMs) || 0)
      })),
      ...(result.skipped || []).map((item) => ({
        input: String(item.relativePath || ""),
        output: "",
        result: "skipped",
        reason: redactLocalPaths(item.reason || "skipped"),
        durationMs: 0
      })),
      ...(result.canceledItems || []).map((item) => ({
        input: String(item.relativePath || ""),
        output: "",
        result: "canceled",
        reason: "canceled",
        durationMs: 0
      }))
    ]
  };
}

module.exports = {
  SUPPORTED_SOURCE_EXTENSIONS,
  buildFolderBatchReport,
  createNumberedOutputFile,
  ensureOutputFolder,
  folderBatchOptionsForPreset,
  isGeneratedOutputName,
  isSupportedSourceName,
  runFolderBatch,
  scanSourceFolder,
  transparentPngName
};
