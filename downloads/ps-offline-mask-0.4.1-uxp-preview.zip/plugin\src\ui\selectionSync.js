function createSelectionSync({
  inspectSelection,
  shouldBlock = () => false,
  getLoadedKey = () => null,
  load,
  onSelection = () => {},
  onBlocked = () => {},
  onError = () => {},
  delay = 220,
  retryDelay = 480,
  maxDeferredRetries = 1,
  setTimer = setTimeout,
  clearTimer = clearTimeout
} = {}) {
  if (typeof inspectSelection !== "function" || typeof load !== "function") {
    throw new TypeError("selection sync requires inspectSelection and load");
  }
  let disposed = false;
  let pending = false;
  let timer = null;
  let token = 0;
  let deferredKey = null;
  let deferredRetries = 0;

  function resetDeferredRetry() {
    deferredKey = null;
    deferredRetries = 0;
  }

  function scheduleDeferredRetry(key, reason) {
    if (key !== deferredKey) {
      deferredKey = key;
      deferredRetries = 0;
    }
    const limit = Math.max(0, Number(maxDeferredRetries) || 0);
    if (deferredRetries >= limit) return false;
    deferredRetries += 1;
    return queue(`retry after ${reason}`, retryDelay, false);
  }

  function queue(reason, wait, resetRetry) {
    if (disposed) return false;
    if (resetRetry) resetDeferredRetry();
    token += 1;
    pending = true;
    if (timer !== null) clearTimer(timer);
    timer = setTimer(
      () => reconcile(reason).catch((error) => {
        pending = false;
        onError(error);
        return { status: "error", error };
      }),
      Math.max(0, Number(wait) || 0)
    );
    return true;
  }

  async function reconcile(reason = "manual") {
    timer = null;
    if (disposed) return { status: "disposed" };
    const currentToken = ++token;
    let inspection;
    try {
      inspection = await inspectSelection();
    } catch (error) {
      inspection = { status: "unavailable", error };
    }
    if (disposed || currentToken !== token) return { status: "stale" };
    onSelection(inspection);
    if (!inspection || inspection.status !== "ready") {
      const unavailable = !inspection || inspection.status === "unavailable";
      pending = unavailable && scheduleDeferredRetry("unavailable", reason);
      if (!pending) resetDeferredRetry();
      return inspection || { status: "unavailable" };
    }
    if (shouldBlock(inspection)) {
      pending = true;
      onBlocked(inspection);
      return { status: "blocked" };
    }

    pending = false;
    if (inspection.key === getLoadedKey()) {
      resetDeferredRetry();
      return { ...inspection, status: "current" };
    }

    const loaded = await load(inspection.layer, { automatic: true, reason, expectedKey: inspection.key });
    if (disposed || currentToken !== token) return { status: "stale" };
    if (loaded === false) {
      pending = scheduleDeferredRetry(inspection.key, reason);
      if (!pending) resetDeferredRetry();
      return { ...inspection, status: pending ? "deferred" : "failed" };
    }
    resetDeferredRetry();
    return { ...inspection, status: "loaded" };
  }

  function schedule(reason = "notification", wait = delay) {
    return queue(reason, wait, true);
  }

  function flush() {
    if (disposed || !pending) return Promise.resolve({ status: disposed ? "disposed" : "idle" });
    if (timer !== null) clearTimer(timer);
    timer = null;
    return reconcile("flush");
  }

  function invalidate() {
    token += 1;
  }

  function dispose() {
    disposed = true;
    pending = false;
    resetDeferredRetry();
    invalidate();
    if (timer !== null) clearTimer(timer);
    timer = null;
  }

  return Object.freeze({
    dispose,
    flush,
    invalidate,
    reconcile,
    schedule,
    get pending() { return pending; }
  });
}

module.exports = { createSelectionSync };
