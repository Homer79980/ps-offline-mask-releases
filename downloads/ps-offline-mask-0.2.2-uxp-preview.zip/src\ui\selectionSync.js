function createSelectionSync({
  inspectSelection,
  shouldBlock = () => false,
  getLoadedKey = () => null,
  load,
  onSelection = () => {},
  delay = 220,
  setTimer = setTimeout,
  clearTimer = clearTimeout
} = {}) {
  if (typeof inspectSelection !== "function" || typeof load !== "function") {
    throw new TypeError("selection sync requires inspectSelection and load");
  }
  let disposed = false;
  let pending = false;
  let timer = null;
  let token = 0;

  async function reconcile(reason = "manual") {
    timer = null;
    if (disposed) return { status: "disposed" };
    if (shouldBlock()) {
      pending = true;
      return { status: "blocked" };
    }

    pending = false;
    const currentToken = ++token;
    let inspection;
    try {
      inspection = await inspectSelection();
    } catch (error) {
      inspection = { status: "unavailable", error };
    }
    if (disposed || currentToken !== token) return { status: "stale" };
    onSelection(inspection);
    if (!inspection || inspection.status !== "ready") return inspection || { status: "unavailable" };
    if (inspection.key === getLoadedKey()) return { ...inspection, status: "current" };

    await load(inspection.layer, { automatic: true, reason, expectedKey: inspection.key });
    if (disposed || currentToken !== token) return { status: "stale" };
    return { ...inspection, status: "loaded" };
  }

  function schedule(reason = "notification", wait = delay) {
    if (disposed) return false;
    token += 1;
    pending = true;
    if (timer !== null) clearTimer(timer);
    timer = setTimer(
      () => reconcile(reason).catch((error) => ({ status: "error", error })),
      Math.max(0, Number(wait) || 0)
    );
    return true;
  }

  function flush() {
    if (disposed || !pending) return Promise.resolve({ status: disposed ? "disposed" : "idle" });
    if (timer !== null) clearTimer(timer);
    timer = null;
    return reconcile("flush");
  }

  function invalidate() {
    token += 1;
  }

  function dispose() {
    disposed = true;
    pending = false;
    invalidate();
    if (timer !== null) clearTimer(timer);
    timer = null;
  }

  return Object.freeze({
    dispose,
    flush,
    invalidate,
    reconcile,
    schedule,
    get pending() { return pending; }
  });
}

module.exports = { createSelectionSync };
